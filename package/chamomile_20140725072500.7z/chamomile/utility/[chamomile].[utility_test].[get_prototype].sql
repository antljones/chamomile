use [chamomile];
go
begin
    declare @object_fqn [nvarchar](max)
            , @prefix   [nvarchar](max) = N'[chamomile].[utility].[test_'
            , @suffix   [nvarchar](max) = N'].[stack].[prototype]'
            , @random   [sysname] = cast(round(rand()*100000, -1) as [sysname])
              + N'_'
              + cast(datepart(millisecond, current_timestamp) as [sysname])
            , @stack    xml([chamomile].[xsc]) = [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]');
    set @object_fqn = @prefix + @random + @suffix;
    select @object_fqn;
    begin
        begin transaction utility_test_get_meta_data;
        select [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]');
        select [utility].[get_prototype](N'[chamomile].[utility].[error_suite].[stack].[prototype]');
        select [data]
        from   [repository].[get] (null, @object_fqn)
        rollback transaction utility_test_get_meta_data;
    end;
end; 
