use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[set_meta_data]', N'P') is not null
  drop procedure [utility].[set_meta_data];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
	todo -- allow setting of persistent meta data

	declare @stack xml([chamomile].[xsc]);

	execute [utility].[set_meta_data]
	  @object_fqn         =N'[chamomile].[return_code].[test1]'
	  , @value      =N'test test'
	  , @description=N'test test.'
	  , @stack      =@stack output;

	select @stack; 


	select [utility].[get_meta_data](N'[chamomile].[return_code].[test1]');

	select *
	from   [repository].[get_list] (null, N'[chamomile].[return_code].[code_65]'); 


*/
create procedure [utility].[set_meta_data]
  @object_fqn    [nvarchar](max)
  , @value       [nvarchar](max) = null
  , @prototype   [xml] = null
  , @constraint  [nvarchar](max) = null
  , @description [nvarchar](max)
  , @stack       xml([chamomile].[xsc]) = null output
as
  begin
      declare @subject_fqn           [nvarchar](1000)
              , @message             [nvarchar](max)
              , @return_code         [int]
              , @builder             [xml]
              , @entry_builder       [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get] (null, N'[chamomile].[xsc].[stack].[prototype]'))
              , @meta_data_stack     [xml] = (select [data]
                 from   [repository].[get] (null, N'[chamomile].[utility].[meta_data].[stack].[prototype]'))
              , @object_type         [sysname] = N'meta_data'
              , @subject_description [nvarchar](max)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126);
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @subject_description = N'Created by ' + @subject_fqn + N'.';
      --
      -------------------------------------------
      if @constraint is not null
        if patindex (N'|%' + @value + N'|%', isnull(@constraint, N'|%' + @value + N'|%')) < 1
          begin
              set @message = N'error: "[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]" - in: '
                             + @subject_fqn;
              set @return_code =cast ([utility].[get_meta_data](N'[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]') as [int]);
              raiserror(@message,1,1);
              return @return_code;
          end;
      --
      -------------------------------------------
      if @constraint is not null
        set @meta_data_stack.modify(N'replace value of (/*/constraint/text())[1] with sql:variable("@constraint")');
      else
        set @meta_data_stack.modify('delete (/*/constraint/text())[1]');
      set @meta_data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
      if @value is not null
        set @meta_data_stack.modify(N'replace value of (/*/value/text())[1] with sql:variable("@value")');
      if @description is not null
        set @meta_data_stack.modify(N'replace value of (/*/*/text())[1] with sql:variable("@description")');
      --
      -------------------------------------------
      set @entry_builder.modify(N'insert sql:variable("@meta_data_stack") as last into (/*/object)[1]');
      set @object_fqn=lower(@object_fqn);
      execute [repository].[set]
        @stack=@entry_builder output;
      set @stack = @entry_builder;
  end
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [nvarchar] (1000) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@value'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@value';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@value] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@value';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@constraint'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@constraint';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@constraint] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@constraint';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@description'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@description';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@description] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@description';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
