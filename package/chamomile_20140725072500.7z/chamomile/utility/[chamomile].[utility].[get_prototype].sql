use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[get_prototype]', N'FN') is not null
  drop function [utility].[get_prototype];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	select [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]');
	select [utility].[get_prototype](N'[chamomile].[utility].[error_suite].[stack].[prototype]');
*/
create function [utility].[get_prototype] (
  @object_fqn [nvarchar](max))
returns [xml]
as
  begin
      declare @value [xml];
      if @object_fqn = N'[chamomile].[xsc].[stack].[prototype]'
        set @value = (select [data].query(N'/*/*[2]')
                      from   [repository].[get] (null, @object_fqn));
      else
        set @value = (select [data]
                      from   [repository].[get] (null, @object_fqn));
      return @value;
  end
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype'
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'function', N'get_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype'
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'function', N'get_prototype', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_prototype'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [nvarchar] (1000) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_prototype'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn'; 
