use [chamomile];
go
if object_id(N'[utility].[set_prototype]', N'P') is not null
  drop procedure [utility].[set_prototype];
go
/*
	execute [utility].[set_prototype] @object_fqn = N'[test].[test].[test]', @prototype = N'<test stuff="stuff"/>', @description=N'test description';

	select [utility].[get_prototype](N'[chamomile].[data].[stack].[prototype]');
*/
create procedure [utility].[set_prototype]
  @object_fqn    [nvarchar](max)
  , @prototype   [xml]
  , @description [nvarchar](max)
  , @delete      [bit] = 0
as
  begin
      declare @timestamp             [sysname] = convert([sysname], current_timestamp, 126)
              , @server_information  [xml]
              , @subject_fqn         [nvarchar](max)
              , @data_stack          [xml] = [utility].[get_prototype](N'[chamomile].[data].[stack].[prototype]')
              , @subject_description [nvarchar](max)
              , @builder             [xml] = [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]')
              , @stack               xml([chamomile].[xsc]);
      --
      ---------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@server_information output;
      set @subject_fqn = @server_information.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      set @subject_description = N'created by ' + @subject_fqn;
      --
      ---------------------------
      set @data_stack.modify(N'insert sql:variable("@prototype") as last into (/*)[1]');
      set @data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
      set @data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
      set @builder.modify(N'replace value of (/*/subject/@fqn)[1] with sql:variable("@subject_fqn")')
      set @builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")')
      set @builder.modify(N'replace value of (/*/subject/description/text())[1] with sql:variable("@subject_description")');
      set @builder.modify(N'insert sql:variable("@data_stack") as last into (/*/object)[1]');
      select @builder;
  /* insert into [repository_secure].[data]
              ([entry])
  values      (@stack);*/
  end;
go 
