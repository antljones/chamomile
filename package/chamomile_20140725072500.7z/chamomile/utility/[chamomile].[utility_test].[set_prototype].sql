/*

*/
begin transaction;
begin
    execute [utility].[set_prototype]
      @object_fqn   = N'[test].[test].[test]'
      , @prototype  = N'<test stuff="stuff"/>'
      , @description=N'test description';
    select [utility].[get_prototype](N'[test].[test].[test]');
    select [data]
    from   [repository].[get] (null, N'[chamomile].[documentation].[html].[prototype]')
end;
rollback; 
