use [chamomile];
go
begin
    begin transaction utility_test_get_meta_data;
    declare @stack    xml([chamomile].[xsc])
            , @random [sysname] = cast(round(rand()*100000, -1) as [sysname])
              + N'_'
              + cast(datepart(millisecond, current_timestamp) as [sysname]);
    declare @object_fqn [nvarchar](max) = N'[chamomile].[return_code].[test1_'
      + @random + N']';
    execute [utility].[set_meta_data]
      @object_fqn   =@object_fqn
      , @value      =@random
      , @description=N'test description.'
      , @stack      =@stack output;
    select @stack;
    if (select [utility].[get_meta_data](@object_fqn))
       = @random
      select N'pass'
    else
      select N'fail'
    rollback transaction utility_test_get_meta_data;
end; 
