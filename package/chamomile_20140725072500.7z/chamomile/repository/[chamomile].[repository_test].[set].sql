use [chamomile];
go
if schema_id(N'repository_test') is null
  execute (N'create schema repository_test');
go
if object_id(N'[repository_test].[set]', N'P') is not null
  drop procedure [repository_test].[set];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository_test'
            , @object [sysname] = N'set';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object; 
*/
create procedure [repository_test].[set]
  @stack xml ([chamomile].[xsc]) output
as
  begin
      set nocount on;
      declare @return_code     [int]
              , @subject_fqn   [nvarchar](1000)
              , @stack_builder [xml]
              , @description   [nvarchar](max) = N'facade method for accessor ([repository_test].[get]), as accessor uses both set and get, allows programmatic testing by individual name.';
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@stack_builder output;
      set @subject_fqn = @stack_builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @stack_builder=null;
      execute @return_code = [repository_test].[get]
        @stack=@stack_builder output;
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/@name)[1] with sql:variable("@subject_fqn")');
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/description/text())[1] with sql:variable("@description")');
      set @stack=@stack_builder;
      return @return_code;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'repository_test', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml ([chamomile].[xsc]), @return_code [int];
	execute @return_code = [repository_test].[set] @stack=@stack output;
	select @stack as [@stack], @return_code as [@return_code];'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'repository_test', N'procedure', N'set', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
