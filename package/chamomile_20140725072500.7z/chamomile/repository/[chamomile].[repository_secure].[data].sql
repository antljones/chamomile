use [chamomile];

go

if schema_id(N'repository_secure') is null
  execute (N'create schema repository_secure');

go

/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository_secure'
            , @object [sysname] = N'data';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
    
*/
if exists (select *
           from   dbo.sysobjects
           where  id = object_id(N'[repository_secure].[repository_secure.data.id.default]')
                  and type = 'D')
  begin
      alter table [repository_secure].[data]
        drop constraint [repository_secure.data.id.default]
  end

go 

if exists
   (select *
    from   sys.indexes
    where  object_id = object_id(N'[repository_secure].[data]')
           and name = N'repository_secure.data.entry.xml_index_property')
  drop index [repository_secure.data.entry.xml_index_property] on [repository_secure].[data]

go

if exists
   (select *
    from   sys.indexes
    where  object_id = object_id(N'[repository_secure].[data]')
           and name = N'repository_secure.data.entry.xml_index')
  drop index [repository_secure.data.entry.xml_index] on [repository_secure].[data]

go

if exists
   (select [tables].[is_tracked_by_cdc]
    from   [sys].[tables] as [tables]
    where  [tables].[name] = N'data'
           and [is_tracked_by_cdc] = 1)
  execute [sys].sp_cdc_disable_table
    @source_schema      = N'repository_secure'
    , @source_name      = N'data'
    , @capture_instance = N'repository_secure.data';

go
if exists
   (select *
    from   sys.objects
    where  object_id = object_id(N'[repository_secure].[data]')
           and type in (N'U'))
  drop table [repository_secure].[data]

go

set ansi_nulls on

go

set quoted_identifier on

go

if not exists
       (select *
        from   sys.objects
        where  object_id = object_id(N'[repository_secure].[data]')
               and type in (N'U'))
      create table [repository_secure].[data](
        [id]        [uniqueidentifier] not null,
        [entry] xml([chamomile].[xsc]) not null,
        constraint [repository_secure.data.id.clustered_primary_key] primary key clustered ([id] asc));

go


if not exists (select *
               from   dbo.sysobjects
               where  id = object_id(N'[repository_secure].[repository_secure.data.id.default]')
                      and type = 'D')
      alter table [repository_secure].[data]
        add constraint [repository_secure.data.id.default] default (newsequentialid()) for [id];

go

exec [sys].sp_cdc_enable_table
  @source_schema          = N'repository_secure'
  , @source_name          = N'data'
  , @role_name            = null
  , @capture_instance     =N'repository_secure.data'
  , @supports_net_changes = 1

go
set arithabort on
set concat_null_yields_null on
set quoted_identifier on
set ansi_nulls on
set ansi_padding on
set ansi_warnings on
set numeric_roundabort off

go

if not exists
       (select *
        from   sys.indexes
        where  object_id = object_id(N'[repository_secure].[data]')
               and name = N'repository_secure.data.entry.xml_index')
  create primary xml index [repository_secure.data.entry.xml_index] on [repository_secure].[data] ( [entry] )with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on)

go

if not exists
       (select *
        from   sys.indexes
        where  object_id = object_id(N'[repository_secure].[data]')
               and name = N'repository_secure.data.entry.xml_index_property')
  create xml index [repository_secure.data.entry.xml_index_property] on [repository_secure].[data] ( [entry] ) using xml index [repository_secure.data.entry.xml_index] for property with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on)
go 


if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     N'COLUMN',
                                     N'id'))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'id'

go

  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N''
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'
    , @level2type=N'COLUMN'
    , @level2name=N'id'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     N'COLUMN',
                                     N'entry'))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'entry'

go
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'Primary store for [chamomile].[repository].'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'
    , @level2type=N'COLUMN'
    , @level2name=N'entry'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     null,
                                     null))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data'

go
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'Stores for typed data.'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140706',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     null,
                                     null))
  exec sys.sp_dropextendedproperty
    @name      =N'revision_20140706',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data'

go

  exec sys.sp_addextendedproperty
    @name        =N'revision_20140706'
    , @value     =N'Katherine E. Lightsey - created.'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go 

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'TABLE'
                                            , N'data'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'TABLE'
  , @level1name=N'data'

go
if exists (select *
           from   ::fn_listextendedproperty(N'release_00.92.00'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'TABLE'
                                            , N'data'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.92.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go

exec sys.sp_addextendedproperty
  @name        =N'release_00.92.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'TABLE'
  , @level1name=N'data';

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'license',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                             null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data';

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](null, N''[chamomile].[documentation].[license]'');',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data';

go