
	--
	-- create text documentation
	---------------------------------------------
	declare @stack        xml
            , @object_fqn [nvarchar](max)=N'[chamomile].[documentation].[get].[test_01]';
    declare @documentation [nvarchar](max) = N'test documentation for ' + @object_fqn;
    --
    -- delete existing documentation
    ---------------------------------------------
    execute [chamomile].[documentation].[set]
      @object_fqn =@object_fqn
      , @delete   = 2;
    --
    ---------------------------------------------
    execute [chamomile].[documentation].[set]
      @object_fqn      =@object_fqn
      , @documentation =@documentation
      , @type          =N'text'
      , @stack         =@stack output;
    --
    ---------------------------------------------
    select @stack                                as [@stack output]
           , [documentation].[get] (@object_fqn) as [documentation];
    if(select [documentation].[get] (@object_fqn)) is null
      select N'fail';
    else
      select N'pass';
    --
    -- delete test documentation
    ---------------------------------------------
    execute [chamomile].[documentation].[set]
      @object_fqn =@object_fqn
      , @delete   = 2; 
    
    
    
    
    
    

	--
	-- create html documentation
	---------------------------------------------
	declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_01]'
      , @documentation =N'<ol><li><b>test</b> modified documentation for</li><li>[chamomile].[documentation].[get].[test_01].</li></ol>'
      , @type          =N'html'
      , @sequence      = 33
      , @stack         =@stack output;
    select @stack as N'@stack output';
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_01]'); 
    
	
	--
	-- delete documentation
	---------------------------------------------
    execute [chamomile].[documentation].[set]
      @object_fqn =N'[chamomile].[documentation].[get].[test_01]'
      , @delete   = 2;
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_01]'); 
    

	
	--
	-- delete a specific documentation sequence
	---------------------------------------------
	declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_01]'
      , @documentation =N'test modified documentation for [chamomile].[documentation].[get].[test_01].'
      , @type          =N'text'
      , @sequence      = 12
      , @stack         =@stack output;
    select @stack as N'@stack output';
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_01]'); 

	declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_01]'
      , @documentation =N'test modified documentation for [chamomile].[documentation].[get].[test_01].'
      , @type          =N'text'
      , @delete        = 1
      , @sequence      = 12
      , @stack         =@stack output;
    select @stack as N'@stack output';
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_01]'); 
    
	--
	-- automatically increment sequence
	---------------------------------------------
	declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_02]'
      , @documentation =N'<ol><li><b>test</b> modified documentation for</li><li>[chamomile].[documentation].[get].[test_02].</li></ol>'
      , @type          =N'html'
      , @stack         =@stack output;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_02]'
      , @documentation =N'second sequence'
      , @type          =N'text'
      , @stack         =@stack output;
    select @stack as N'@stack output';
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_02]'); 

	--
	-- delete documentation
	---------------------------------------------
	execute [chamomile].[documentation].[set]
      @object_fqn =N'[chamomile].[documentation].[get].[test_02]'
      , @delete   = 2;
    select [documentation].[get] (N'[chamomile].[documentation].[get].[test_02]'); 
    
	
	
	
	
	
	
	
	
	     

