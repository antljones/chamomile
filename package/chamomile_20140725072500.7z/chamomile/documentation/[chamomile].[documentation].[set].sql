use [chamomile];
go
if schema_id(N'documentation') is null
  execute(N'create schema documentation');
go
if object_id(N'[documentation].[set]', N'P') is not null
  drop procedure [documentation].[set];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'documentation'
            , @object [sysname] = N'set';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
*/
create procedure [documentation].[set]
  @object_fqn      [nvarchar](max)
  , @documentation [nvarchar](max) = null
  , @type          [sysname] = N'text'
  , @sequence      [int] = 0
  , @delete        [int] = 0
  , @stack         xml([chamomile].[xsc]) = null output
as
  begin
      declare @stack_prototype  [nvarchar](max) = N'[chamomile].[xsc].[stack].[prototype]'
              , @text_prototype [nvarchar](max) = N'[chamomile].[documentation].[text].[prototype]'
              , @html_prototype [nvarchar](max) = N'[chamomile].[documentation].[html].[prototype]';
      declare @subject_fqn           [nvarchar](max)
              , @message             [nvarchar](max)
              , @builder             [xml]
              , @id                  [uniqueidentifier]
              , @entry_builder       [xml]= [utility].[get_prototype](@stack_prototype)
              , @text_type           [xml] = [utility].[get_prototype](@text_prototype)
              , @html_type           [xml] = [utility].[get_prototype](@html_prototype)
              , @subject_description [nvarchar](max)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126);
      --
      -------------------------------------------------
      set @message=null;
      with [invalid_data_finder]
           as (select [value]
                      , [prototype]
               from   ( values (@entry_builder
                      , @stack_prototype),
                               (cast(@text_type as [nvarchar](max))
                      , N'[chamomile].[documentation].[text].[prototype]'),
                               (cast(@html_type as [nvarchar](max))
                      , N'[chamomile].[documentation].[html].[prototype]')) as [invalid_data] ([value], [prototype]))
      select @message = coalesce(@message, N'', N'') + [prototype]
                        + N', '
      from   [invalid_data_finder]
      where  [value] is null;
      if @message is not null
        if @message is not null
          begin
              set @message=left(@message, len(@message) - 1);
              raiserror (100066,1,1,@message,@subject_fqn);
              return 100066;
          end;
      set @object_fqn=lower(@object_fqn);
      --
      -------------------------------------------
      execute [dbo].[sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](max)');
      set @subject_description = N'Created by ' + @subject_fqn + N'.';
      --
      -------------------------------------------------
      set @entry_builder = (select [entry]
                            from   [repository].[get](null, @object_fqn));
      set @entry_builder = isnull(@entry_builder, [utility].[get_prototype](@stack_prototype));
      if @sequence = 0
        set @sequence = isnull(@entry_builder.value(N'max (/*/object/documentation/*/@sequence)[1]', N'[int]')
                               + 1, 1);
      --
      -------------------------------------------
      if @delete = 1
        begin
            set @entry_builder.modify('delete */object/documentation[text/@sequence=sql:variable("@sequence")]');
            set @stack = @entry_builder;
        end;
      else if @delete = 2
        begin
            set @id = (select [id]
                       from   [repository].[get] (null, @object_fqn));
            --
            -------------------------------------
            if @id is not null
              begin
                  execute [repository].[set]
                    @id       =@id
                    , @delete = 1;
                  --
                  -------------------------------------
                  if ( @entry_builder.value(N'count (/*/object/*)', N'[int]') = 0 )
                    set @id = (select [id]
                               from   [repository].[get] (null, @object_fqn));
                  execute [repository].[set]
                    @id       =@id
                    , @delete = 1;
              end;
            set @stack = (select [entry]
                          from   [repository].[get] (null, @object_fqn))
        end;
      --
      -------------------------------------------
      else
        begin
            if @documentation is null
              begin
                  begin
                      set @message= N'@documentation cannot be null unless @delete in {1|2}';
                      raiserror (100068,1,1,@message,@subject_fqn);
                      return 100068;
                  end;
              end;
            --
            -------------------------------------------
            if @entry_builder.exist(N'*/object/documentation[*/@sequence=sql:variable("@sequence")]') = 1
              set @entry_builder.modify('delete */object/documentation[*/@sequence=sql:variable("@sequence")]');
            --
            -------------------------------------------
            if @type = N'text'
              begin
                  set @text_type.modify(N'insert text {sql:variable("@documentation")} as last into (/*/text)[1]');
                  set @text_type.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
                  set @text_type.modify(N'replace value of (/*/*/@sequence)[1] with sql:variable("@sequence")');
                  set @entry_builder.modify(N'insert sql:variable("@text_type") as last into (/*/object)[1]');
              end;
            --
            -------------------------------------------
            else if @type = N'html'
              begin
                  set @html_type.modify(N'insert text {sql:variable("@documentation")} as last into (/*/html)[1]');
                  set @html_type.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
                  set @html_type.modify(N'replace value of (/*/*/@sequence)[1] with sql:variable("@sequence")');
                  set @entry_builder.modify(N'insert sql:variable("@html_type") as last into (/*/object)[1]');
              end;
            --
            -------------------------------------------
            execute [repository].[set]
              @stack=@entry_builder output;
            set @stack = @entry_builder;
        end;
  end
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](null, N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N''[chamomile].[documentation].[get].[test_01]''
      , @documentation =N''test documentation for [chamomile].[documentation].[get].[test_01].''
      , @type          =N''html''
      , @stack         =@stack output;
    select @stack, [documentation].[get] (N''[chamomile].[documentation].[get].[test_01]''); '
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@documentation';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@documentation] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@documentation';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@type'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@type';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@type] [sysname] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@type';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@sequence'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@sequence';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@sequence] [int] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@sequence';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@delete'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@delete';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@delete] [int] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@delete';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'set', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
