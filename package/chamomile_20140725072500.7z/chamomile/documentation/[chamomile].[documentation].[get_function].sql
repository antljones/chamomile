use [chamomile];
go
if object_id(N'[documentation].[get_function]', N'FN') is not null
  drop function [documentation].[get_function];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'documentation'
            , @object [sysname] = N'get_function';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;


	select [documentation].[get_function](N'[chamomile].[documentation].[get_job]');
*/
create function [documentation].[get_function](
  @object_fqn [sysname])
returns [nvarchar](max)
as
  begin
      declare @documentation             [nvarchar](max)
              , @function_details        [nvarchar](max)
              , @function_documentation  [nvarchar](max)
              , @parameter_documentation [nvarchar](max)
              , @definition              [nvarchar](max);
      declare @schema   [sysname] = parsename(@object_fqn, 2)
              , @object [sysname] = parsename(@object_fqn, 1);
      select @definition = (select OBJECT_DEFINITION (object_id(N'[repository].[get]')));
      --
      select @function_details = N'<div id="first_indent"><details><summary>function details</summary><ol><li>object_id {'
                                 + cast([object_id] as [sysname]) + N'}</li>'
                                 + N'<li>created {'
                                 + cast([create_date] as [sysname])
                                 + N'}</li>' + N'<li>modified {'
                                 + cast([modify_date] as [sysname])
                                 + N'}</li></details></div>'
      from   [sys].[objects] as [objects]
             left join [sys].[extended_properties] as [extended_properties]
                    on [extended_properties].[major_id] = [objects].[object_id]
                       and [extended_properties].[class] = 1
      where  object_schema_name([objects].[object_id]) = @schema
             and [objects].[name] = @object
             and [objects].[type] in ( N'FN', N'IF', N'TF' );
      --
      begin
          -- todo - handle TF
          select @parameter_documentation = coalesce(@parameter_documentation, N' ', N'')
                                            + N'<li>' + case
                                            --
                                            when [parameters].[name] is null or len([parameters].[name]) = 0then N'{returns} ' else [parameters].[name] end
                                            --
                                            + case
                                            --
                                            when type_name([parameters].[user_type_id]) like N'n%' and [parameters].[max_length]=-1 then N' [' + type_name([parameters].[user_type_id]) + N'](max)'
                                            --
                                            when type_name([parameters].[user_type_id]) like N'n%' then N' [' + type_name([parameters].[user_type_id]) + N'](' + cast ([parameters].[max_length]/2 as [sysname]) + N')'
                                            --
                                            else N' [' + type_name([parameters].[user_type_id]) + N']'
                                            --
                                            end
                                            + isnull(N' - ' + cast([extended_properties].[name] as [sysname]) + N' {' + cast([extended_properties].[value] as [nvarchar](max)) + N'}', N'')
                                            + N'</li>'
          from   [sys].[parameters] as [parameters]
                 join [sys].[objects] as [objects]
                   on [objects].[object_id] = [parameters].[object_id]
                 left join [sys].[extended_properties] as [extended_properties]
                        on [extended_properties].[major_id] = [objects].[object_id]
                           and [extended_properties].[class] != 1
          where  object_schema_name([objects].[object_id]) = @schema
                 and [objects].[name] = @object
                 and [objects].[type] in ( N'FN', N'IF', N'TF' );
          select @parameter_documentation = N'<div id="first_indent"><details><summary>parameter documentation</summary><ol>'
                                            + @parameter_documentation
                                            + N'</details></div>';
      end;
      --
      begin
          select @function_documentation = coalesce(@function_documentation, N' ', N'')
                                           + isnull(N'<li>' + cast([extended_properties].[name] as [sysname]) + N' {' + isnull(cast([extended_properties].[value] as [nvarchar](max)), N'') + N'}', N'')
          from   [sys].[objects] as [objects]
                 left join [sys].[extended_properties] as [extended_properties]
                        on [extended_properties].[major_id] = [objects].[object_id]
                           and [extended_properties].[class] = 1
          where  object_schema_name([objects].[object_id]) = @schema
                 and [objects].[name] = @object
                 and [objects].[type] in ( N'FN', N'IF', N'TF' );
          select @function_documentation = N'<div id="first_indent"><details><summary>function documentation</summary><ol>'
                                           + @function_documentation
                                           + N'</details></div>';
      end;
      set @documentation = N'<div id="first_indent"><details><summary>'
                           + @object_fqn + N'</summary><ol>'
                           + @function_documentation + @function_details
                           + @parameter_documentation
                           + N'</details></div>';;
      return @documentation;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function'
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'function', N'get_function', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function'
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'function', N'get_function', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get_function'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [sysname] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get_function'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn'; 
