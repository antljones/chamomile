use [chamomile];
go
if object_id(N'[documentation].[get]', N'FN') is not null
  drop function [documentation].[get];
go
/*
	declare @stack xml;
    execute [chamomile].[documentation].[set]
      @object_fqn      =N'[chamomile].[documentation].[get].[test_01]'
      , @documentation =N'test modified documentation for [chamomile].[documentation].[get].[test_01].'
      , @type          =N'text'
      , @stack         =@stack output;
    select @stack, [documentation].[get] (N'[chamomile].[documentation].[get].[test_01]'); 



	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'documentation'
            , @object [sysname] = N'get';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
*/
create function [documentation].[get] (
  @object_fqn [nvarchar](max))
returns [nvarchar](max)
as
  begin
      declare @value [nvarchar](max);
      declare @data xml = (select [entry]
         from   [repository].[get] (null, @object_fqn));
      declare @documentation as table (
        [sequence]        [int]
        , [documentation] [nvarchar](max)
        );
      --
      -------------------------------------------------
      insert into @documentation
                  ([sequence]
                   , [documentation])
        select t.c.value(N'./sequence[1]', N'[int]')
               , t.c.value(N'./text[1]', N'[nvarchar](max)')
        from   @data.nodes(N'for $d in /*/object/documentation order by $d/@sequence[1] ascending return $d') as t(c);
      insert into @documentation
                  ([sequence]
                   , [documentation])
        select t.c.value(N'./sequence[1]', N'[int]')
               , t.c.value(N'./html[1]', N'[nvarchar](max)')
        from   @data.nodes(N'for $d in /*/object/documentation order by $d/@sequence[1] ascending return $d') as t(c);
      select @value = coalesce(@value, N' ', N'') + [documentation]
      from   @documentation
      where  [documentation] is not null;
      --
      ---------------------------------------------
      return @value;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get'
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'function', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get'
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'function', N'get', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'function'
    , @level1name=N'get'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'function'
  , @level1name=N'get'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn'; 
