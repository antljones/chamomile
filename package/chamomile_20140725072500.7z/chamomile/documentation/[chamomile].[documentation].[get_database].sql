use [chamomile];
go
if object_id(N'[documentation].[get_database]', N'P') is not null
  drop procedure [documentation].[get_database];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'documentation'
            , @object [sysname] = N'get_database';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;


	declare @documentation [nvarchar](max)
            , @bcp_command [nvarchar](max);
    execute [documentation].[get_database]
      @object_fqn     = N'[chamomile]'
      , @status       = N'force_refresh'
      , @output_as    = N'html'
      , @bcp_command  =@bcp_command output
      , @documentation=@documentation output;
    select @bcp_command as N'@bcp_command', @documentation as N'@documentation'; 
     
*/
create procedure [documentation].[get_database]
  @object_fqn      [sysname]
  , @status        [sysname]= N'allow_stale'
  , @output_as     [sysname] = N'html'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @database                 [sysname] = parsename(@object_fqn, 1)
              , @function_documentation [nvarchar](max)
              , @schema_documentation   [nvarchar](max)
              , @server                 [sysname]
              , @start                  [datetime] = current_timestamp
              , @elapsed                [decimal](9, 4)
              , @builder                [xml]
              , @subject_fqn            [nvarchar](max)
              , @extended_properties    [nvarchar](max)
              , @object                 [nvarchar](max)
              , @command                [xml]
              , @job_documentation      [nvarchar](max)
              , @stack                  xml
              , @timestamp              [sysname] = convert([sysname], current_timestamp, 126);
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      -- extended properties
      ----------------------------------------------
      select @extended_properties = coalesce(@extended_properties, N' ', N'')
                                    + N'<li>' + [extended_properties].[name] + N' {'
                                    + cast([extended_properties].[value] as [nvarchar](max))
                                    + N'}</li>'
      from   [sys].[extended_properties] as [extended_properties]
      where  [extended_properties].[class_desc] = N'DATABASE';
      select @extended_properties = N'<extended_properties><div id="fourth_indent"><details><summary>extended properties</summary><ol>'
                                    + @extended_properties
                                    + N'</ol></details></div></extended_properties>';
      --
      -- schema documentation
      -- todo - use prototype
      ----------------------------------------------
      begin
          set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="'
                       + @timestamp
                       + N'">
			<subject fqn="[chamomile].[documentation].[get_schema_list]">
				<description>workflow for getting function documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_schema_list]" >		
					<description>get documentation for listed schema.</description>
					<command fqn="[all]" timestamp="'
                       + @timestamp + N'" >
						<description>get documentation for schema.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>'
          execute [documentation].[get_schema_list]
            @stack          =@stack
            , @status       =@status
            , @output_as    =N'html'
            , @documentation=@schema_documentation output;
          --
          ----------------------------------------------
          select @documentation = N'<database_documentation><div id="third_indent"><details><summary>'
                                  + @object_fqn + '</summary>'
                                  --
                                  + isnull(@extended_properties, N'')
                                  + isnull(@schema_documentation, N'')
                                  --
                                  + N'<p class="timestamp">built by {'
                                  + @subject_fqn + N'} timestamp {' + @timestamp
                                  + N'} elapsed_time(s) {'
                                  + cast(@elapsed as [sysname]) + N'}</p>'
                                  + N'</details></div></database_documentation>';
      end;
      --
      -------------------------------------------	
      execute [chamomile].[documentation].[set]
        @object_fqn      =@object_fqn
        , @documentation =@documentation
        , @type          = N'html'
        , @sequence      = 1
        , @stack         = @stack output;
      --
      -------------------------------------------
      if @output_as = N'html'
        set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                           + @object_fqn + N'''));" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N'  -t, -T -c -d ' + db_name() + N' -S '
                           + @server + N';';
      else if @output_as = N'xml'
        set @bcp_command = N'BCP "select [documentation].[get] ('''
                           + @object_fqn + N''');" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'procedure', N'get_database', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_database', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@object_fqn] [sysname] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_database', N'parameter', N'@status'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database'
    , @level2type=N'parameter'
    , @level2name=N'@status';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@status] [sysname] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
  , @level2type=N'parameter'
  , @level2name=N'@status';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_database', N'parameter', N'@output_as'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database'
    , @level2type=N'parameter'
    , @level2name=N'@output_as';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@output_as] [sysname] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
  , @level2type=N'parameter'
  , @level2name=N'@output_as';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_database', N'parameter', N'@bcp_command'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database'
    , @level2type=N'parameter'
    , @level2name=N'@bcp_command';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@bcp_command] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
  , @level2type=N'parameter'
  , @level2name=N'@bcp_command';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_database', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get_database'
    , @level2type=N'parameter'
    , @level2name=N'@documentation';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@documentation] [nvarchar] (0) - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get_database'
  , @level2type=N'parameter'
  , @level2name=N'@documentation'; 
