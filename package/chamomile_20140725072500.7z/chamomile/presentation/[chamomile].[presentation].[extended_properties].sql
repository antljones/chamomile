/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
	This presentation is intended to provide boilerplate code to be used for
	copy and paste into your own methods.

	Several methods are shown by which to both create and display extended
	properties. 

	All objects in [chamomile] are documented using extended properties. You
	will find many more samples there.

	samples here include dropping, adding, and listing extended properties for:
		database
			schema
				table
					column
					index
					constraint
				procedure				-- todo
					parameter			-- todo
				function				-- todo
					parameter			-- todo
				view					-- todo
					column				-- todo
				job						-- todo
					step				-- todo
				sysname
				xml schema collection

	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------
*/
--
-- code block begin
if db_id(N'extended_property_test') is not null
  drop database [extended_property_test];
if db_id(N'extended_property_test') is null
  create database extended_property_test;
go
use [extended_property_test];
go
if schema_id(N'unbreakable_code') is null
  execute (N'create schema unbreakable_code');
go
-- code block end
--
-- database properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    if exists
       (select *
        from   sys.fn_listextendedproperty(N'description', default, default, default, default, default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = null
        , @level0name = null
        , @level1type = null
        , @level1name = null
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'{todo - business description.}'
      , @level0type = null
      , @level0name = null
      , @level1type = null
      , @level1name = null
      , @level2type = null
      , @level2name =null;
    if exists
       (select *
        from   sys.fn_listextendedproperty(N'revision_20140528', default, default, default, default, default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'revision_20140528'
        , @level0type = null
        , @level0name = null
        , @level1type = null
        , @level1name = null
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'revision_20140528'
      , @value      = N'Katherine E. Lightsey - created.'
      , @level0type = null
      , @level0name = null
      , @level1type = null
      , @level1name = null
      , @level2type = null
      , @level2name =null;
    --
    ----------------------------------------------------------------------
    select [extended_properties].[name]
           , [extended_properties].[value]
    from   sys.fn_listextendedproperty(N'description', default, default, default, default, default, default) as [extended_properties];
    select [extended_properties].[name]
           , [extended_properties].[value]
    from   sys.fn_listextendedproperty(N'revision_20140528', default, default, default, default, default, default) as [extended_properties];
    select [extended_properties].[name]
           , [extended_properties].[value]
    from   sys.fn_listextendedproperty(default, default, default, default, default, default, default) as [extended_properties];
    select [extended_properties].[name]
           , [extended_properties].[value]
           , [extended_properties].[class]
           , [extended_properties].[class_desc]
           , [extended_properties].[major_id]
           , [extended_properties].[minor_id]
    from   [sys].[extended_properties] as [extended_properties]
    where  [extended_properties].[class_desc] = N'DATABASE';
end
--
-- schema level properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    if schema_id(N'workflow') is null
      execute('create schema workflow');
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'workflow', default, default, default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'workflow'
        , @level1type = null
        , @level1name = null
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'schema [workflow] contains objects specific to workflow including command objects.'
      , @level0type = N'SCHEMA'
      , @level0name = N'workflow'
      , @level1type = null
      , @level1name = null
      , @level2type = null
      , @level2name =null;
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', default, default, default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = null
        , @level1name = null
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'Schema [billing] is is a grouping of business objects that... business description stuff goes here...'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = null
      , @level1name = null
      , @level2type = null
      , @level2name =null;
    --
    ----------------------------------------------------------------------
    select [extended_properties].[name]
           , [extended_properties].[value]
    from   fn_listextendedproperty(default, N'SCHEMA', N'billing', default, default, default, default) as [extended_properties];
    select [extended_properties].[name]
           , [extended_properties].[value]
           , [extended_properties].[class]
           , [extended_properties].[class_desc]
           , [extended_properties].[major_id]
           , [extended_properties].[minor_id]
    from   [sys].[schemas] as [schemas]
           join [sys].[extended_properties] as [extended_properties]
             on [extended_properties].[major_id] = [schemas].[schema_id]
    where  [schemas].[name] = N'billing';
end
--
-- Table properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    if schema_id(N'billing') is null
      execute (N'create schema billing');
    if object_id(N'[billing].[reconciliation]') is not null
      drop table [billing].[reconciliation];
    create table [billing].[reconciliation] (
      [id]       [int] identity(1, 1) not null,
        constraint [billing.reconciliation.id.clustered_primary_key] primary key clustered ([id])
        , [amount] [money] not null
        , [type]   [sysname],
        constraint [billing.reconciliation.type.check] check (lower([type]) in (N'on_time', N'late', N'coerced'))
      , [added]  [datetime] not null
      );
    alter table [billing].[reconciliation]
      add constraint [billing.reconciliation.added.default] default (current_timestamp) for [added];
    insert into [billing].[reconciliation]
                ([amount],[type])
    values      (100.00,N'on_time');
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing reconciliation table.'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = null
      , @level2name =null;
    if exists
       (select *
        from   fn_listextendedproperty(N'revision_20140528', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', default, default))
      exec sys.sp_dropextendedproperty
        @name         = N'revision_20140528'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = null
        , @level2name =null;
    exec sys.sp_addextendedproperty
      @name         = N'revision_20140528'
      , @value      = N'Katherine E. Lightsey - created.'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = null
      , @level2name =null;
    --
    -- Update
    exec sp_updateextendedproperty
      @name         = N'description'
      , @value      = N'billing reconciliation table updated version.'
      , @level0type = N'Schema'
      , @level0name = N'billing'
      , @level1type = N'Table'
      , @level1name = N'reconciliation';
    --
    ----------------------------------------------------------------------
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', null, null);
end
--
-- column properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'id'))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = N'COLUMN'
        , @level2name =N'id';
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing id primary key column'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = N'COLUMN'
      , @level2name =N'id';
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'amount'))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = N'COLUMN'
        , @level2name =N'amount';
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing amount column.'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = N'COLUMN'
      , @level2name =N'amount';
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'added'))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = N'COLUMN'
        , @level2name =N'added';
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing added Timestamp'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = N'COLUMN'
      , @level2name =N'added';
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'id');
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'amount');
    select [schemas].[name]
           , [tables].[name]
           , [columns].[name]
           , [extended_properties].*
    from   [sys].[columns] as [columns]
           join [sys].[extended_properties] as [extended_properties]
             on [extended_properties].[major_id] = [columns].[object_id]
                and [columns].column_id = [extended_properties].[minor_id]
           join [sys].[tables] as [tables]
             on [tables].[object_id] = [columns].[object_id]
           join [sys].[schemas] as [schemas]
             on [schemas].[schema_id] = [tables].[schema_id]
    where  [schemas].[name] = N'billing'
           and [tables].[name] = N'reconciliation';
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'COLUMN', N'id');
    select [schemas].[name]
           , [tables].[name]
           , [columns].[name]
           , [extended_properties].[name]
           , [extended_properties].[value]
    from   [sys].[tables] as [tables]
           join [sys].[columns] as [columns]
             on [tables].[object_id] = [columns].[object_id]
           join [sys].[schemas] as [schemas]
             on [schemas].[schema_id] = [tables].[schema_id]
           cross apply fn_listextendedproperty(null, N'SCHEMA', [schemas].[name], N'TABLE', [tables].[name], N'COLUMN', [columns].[name]) as [extended_properties];
end
--
-- Index properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    if indexproperty(object_id(N'[billing].[reconciliation]'), N'billing.reconciliation.amount.index', N'index_id') is not null
      drop index [billing.reconciliation.amount.index] on [billing].[reconciliation];
    create index [billing.reconciliation.amount.index]
      on [billing].[reconciliation]([amount]);
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'INDEX', N'billing.reconciliation.amount.index'))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = N'INDEX'
        , @level2name =N'billing.reconciliation.amount.index';
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing billing.reconciliation.amount.index Index.'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = N'INDEX'
      , @level2name =N'billing.reconciliation.amount.index';
    if indexproperty(object_id(N'[billing].[reconciliation]'), N'billing.reconciliation.added.index', N'index_id') is not null
      drop index [billing.reconciliation.added.index] on [billing].[reconciliation];
    create index [billing.reconciliation.added.index]
      on [billing].[reconciliation]([amount]);
    if exists
       (select *
        from   fn_listextendedproperty(N'description', N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'INDEX', N'billing.reconciliation.added.index'))
      exec sys.sp_dropextendedproperty
        @name         = N'description'
        , @level0type = N'SCHEMA'
        , @level0name = N'billing'
        , @level1type = N'TABLE'
        , @level1name = N'reconciliation'
        , @level2type = N'INDEX'
        , @level2name =N'billing.reconciliation.added.index';
    exec sys.sp_addextendedproperty
      @name         = N'description'
      , @value      = N'billing billing.reconciliation.added.index Index.'
      , @level0type = N'SCHEMA'
      , @level0name = N'billing'
      , @level1type = N'TABLE'
      , @level1name = N'reconciliation'
      , @level2type = N'INDEX'
      , @level2name =N'billing.reconciliation.added.index';
    --
    ----------------------------------------------------------------------
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'INDEX', N'billing.reconciliation.amount.index');
    select *
    from   fn_listextendedproperty(null, N'SCHEMA', N'billing', N'TABLE', N'reconciliation', N'INDEX', null);
end
--
-- constraint properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    with [get_constraints]
         as (select [check_constraints].[parent_object_id]
                    , [check_constraints].[object_id]
                    , [check_constraints].[name]
                    , [check_constraints].[type]
                    , [check_constraints].[type_desc]
                    , [check_constraints].[definition]
             from   [sys].[check_constraints] as [check_constraints]
                    join [sys].[columns] as [columns]
                      on [check_constraints].[parent_column_id] = [columns].column_id
                         and [check_constraints].[parent_object_id] = [columns].[object_id]
             where  [check_constraints].[schema_id] = schema_id(N'billing')
                    and [check_constraints].[parent_object_id] = object_id(N'[billing].[reconciliation]')
             union
             --
             --	Default Constraints
             select [default_constraints].[parent_object_id]
                    , [default_constraints].[object_id]
                    , [default_constraints].[name]
                    , [default_constraints].[type]
                    , [default_constraints].[type_desc]
                    , [default_constraints].[definition]
             from   [sys].[default_constraints] as [default_constraints]
             where  [default_constraints].[schema_id] = schema_id(N'billing')
                    and [default_constraints].[parent_object_id] = object_id(N'[billing].[reconciliation]')
             union
             --
             --	Key Constraints
             select [key_constraints].[parent_object_id]
                    , [key_constraints].[object_id]
                    , [key_constraints].[name]
                    , [key_constraints].[type]
                    , [key_constraints].[type_desc]
                    , null
             from   [sys].[key_constraints] as [key_constraints]
             where  [key_constraints].[schema_id] = schema_id(N'billing')
                    and [key_constraints].[parent_object_id] = object_id(N'[billing].[reconciliation]'))
    select [get_constraints].[object_id]
           , [get_constraints].[name]
           , [get_constraints].[type]
           , [get_constraints].[type_desc]
           , [get_constraints].[definition]
           , [extended_properties].[name]
           , [extended_properties].[value]
    from   [get_constraints] as [get_constraints]
           left join [sys].[extended_properties] as [extended_properties]
                  on [extended_properties].[major_id] = [get_constraints].[parent_object_id]
                     and [extended_properties].[minor_id] = [get_constraints].[object_id];
end
--
-- To get all properties associated with a table regardless of type
--------------------------------------------------------------------------
--------------------------------------------------------------------------
begin
    declare @schema  [sysname] = N'billing'
            , @table [sysname] = N'reconciliation';
    select [schemas].[name]  as N'schema'
           , [tables].[name] as N'table'
           , case [extended_properties].[class] when 1 then
                   case [extended_properties].[minor_id] when 0 then
                         N'table'
                   else
                         N'column'
                   end
                 when 7 then
                   N'index'
             end             as N'type'
           , [extended_properties].[name]
           , [extended_properties].[value]
    from   [sys].[tables] as [tables]
           join [sys].[schemas] as [schemas]
             on [schemas].[schema_id] = [tables].[schema_id]
           join [sys].[extended_properties] as [extended_properties]
             on [extended_properties].[major_id] = [tables].[object_id]
    where  [schemas].[name] = @schema
           and [tables].[name] = @table
    union
    select schema_name([tables].[schema_id])
           , [tables].[name]
           , [check_constraints].[type_desc]
           , [extended_properties].[name]
           , [extended_properties].[value]
    from   [sys].[check_constraints] as [check_constraints]
           join [sys].[tables] as [tables]
             on [tables].[object_id] = [check_constraints].[parent_object_id]
           join [sys].[extended_properties] as [extended_properties]
             on [extended_properties].[major_id] = [check_constraints].[object_id]
    where  schema_name([tables].[schema_id]) = @schema
           and [tables].[name] = @table;
end
--
-- procedure properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--
-- parameter properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--
-- view properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--
-- view column properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--
-- sysname properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if schema_id(N'utility') is null
  execute (N'create schema utility');
go
if schema_id(N'utility_secure') is null
  execute (N'create schema utility_secure');
go
if object_id(N'', N'U') is not null
  drop table [utility_secure].[test_table_01];
go
create table [utility_secure].[test_table_01] (
  [id]       [int] identity(1, 1) not null primary key clustered
  , [flower] [sysname]
  , [color]  [sysname]
  );
go
if exists
   (select *
    from   [sys].[synonyms]
    where  [name] = N'test_01'
           and schema_name([schema_id]) = N'utility')
  drop synonym [utility].[test_01];
go
create synonym [utility].[test_01] for [utility_secure].[test_table_01];
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'synonym', N'test_01', null, null))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'SCHEMA'
    , @level0name = N'utility'
    , @level1type = N'synonym'
    , @level1name = N'test_01'
    , @level2type = null
    , @level2name = null;
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'description for test synonym'
  , @level0type = N'SCHEMA'
  , @level0name = N'utility'
  , @level1type = N'synonym'
  , @level1name = N'test_01'
  , @level2type = null
  , @level2name = null;
--
-- to view documentation
-------------------------------------------------
select objtype
       , objname
       , name
       , value
from   fn_listextendedproperty (null, 'schema', 'utility', 'synonym', 'test_01', default, default);
--
-- xml schema collection properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if schema_id(N'utility') is null
  execute (N'create schema utility');
if exists
   (select xml_collection_id
    from   sys.xml_schema_collections as xsc
    where  xsc.name = 'test_xsc'
           and xsc.schema_id = schema_id(N'utility'))
  drop xml schema collection [utility].[test_xsc];
go
create xml schema collection [utility].[test_xsc] as N'<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:chamomile="http://www.katherinelightsey.com/" targetNamespace="http://www.katherinelightsey.com/">

    <xsd:element name="stack" type="chamomile:stack_type" />

    <xsd:complexType name="stack_type">
      <xsd:complexContent>
        <xsd:restriction base="xsd:anyType">
          <xsd:sequence>
			<xsd:element name="subject" type="xsd:string" minOccurs="1" maxOccurs="1" />
            <xsd:element name="object" type="xsd:string" minOccurs="1" maxOccurs="1" />
            <xsd:element name="result" type="xsd:string" minOccurs="0" maxOccurs="1" />
          </xsd:sequence>
          <xsd:attribute name="persistent" type="xsd:string" default="false" />
          <xsd:attribute name="timestamp" type="xsd:dateTime" use="required" />
		  <xsd:anyAttribute processContents="lax" />
        </xsd:restriction>
      </xsd:complexContent>
    </xsd:complexType>

</xsd:schema>';
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'xml schema collection', N'test_xsc', null, null))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'SCHEMA'
    , @level0name = N'utility'
    , @level1type = N'xml schema collection'
    , @level1name = N'test_xsc'
    , @level2type = null
    , @level2name = null;
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'description for test schema'
  , @level0type = N'SCHEMA'
  , @level0name = N'utility'
  , @level1type = N'xml schema collection'
  , @level1name = N'test_xsc'
  , @level2type = null
  , @level2name = null;
--
-- to view documentation
-------------------------------------------------
select objtype
       , objname
       , name
       , value
from   fn_listextendedproperty (null, 'schema', 'utility', 'xml schema collection', 'test_xsc', default, default);
--
-- note that this doesn't work
-------------------------------------------------
-------------------------------------------------
select objtype
       , objname
       , name
       , value
from   fn_listextendedproperty (null, 'schema', 'utility', 'xml schema collection', default, default, default);
--
-- sysjobs properties
--------------------------------------------------------------------------
--------------------------------------------------------------------------
--Add the 'Version' extended property to msdb.dbo.sysjobs.[version_number] column.
execute sp_addextendedproperty
  N'Version'
  , '1.0.0.0'
  , 'SCHEMA'
  , N'dbo'
  , 'TABLE'
  , N'sysjobs'
  , 'COLUMN'
  , N'version_number';
--Update the 'Version' extended property
execute sp_updateextendedproperty
  N'Version'
  , '1.0.0.2'
  , 'SCHEMA'
  , N'dbo'
  , 'TABLE'
  , N'sysjobs'
  , 'COLUMN'
  , N'version_number';
--View the current value of 'Version'
select objtype
       , objname
       , name
       , value
from   fn_listextendedproperty(N'Version', 'SCHEMA', N'dbo', 'TABLE', N'sysjobs', 'COLUMN', N'version_number');
--Drop the 'Version' extended property
execute sp_dropextendedproperty
  N'Version'
  , 'SCHEMA'
  , N'dbo'
  , 'TABLE'
  , N'sysjobs'
  , 'COLUMN'
  , N'version_number'; 
