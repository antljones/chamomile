
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository_secure'
            , @object [sysname] = N'data';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
*/
declare @stack xml([chamomile].[xsc])= N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-30T18:37:43.61">
    	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
    	  <object >
			<workflow xmlns:chamomile="http://www.katherinelightsey.com/" name="[computer_physical_netbios].[machine].[instance].[chamoile].[test].[run]" >
    				<command name="[repository_test].[get]" timestamp="2014-06-30T18:37:43.61"/>
					<command name="[repository_test].[set]" timestamp="2014-06-30T18:37:43.61"/>
    		</workflow>
    	  </object>
    	</chamomile:stack>';

execute [test].[run]
  @stack=@stack output;

select @stack as N'[test_suite]'; 
