use [chamomile];
go
if object_id(N'[documentation].[get_formatted_html]', N'FN') is not null
  drop function [documentation].[get_formatted_html];
go
/*
	select [documentation].[get_formatted_html] (N'[chamomile].[job].[get_change]');
*/
create function [documentation].[get_formatted_html] (
  @documentation [nvarchar](max))
returns [nvarchar](max)
as
  begin
      declare @head_fqn     [nvarchar](max) = N'[chamomile].[documentation].[html].[head]'
              , @footer_fqn [nvarchar](max) = N'[chamomile].[documentation].[html].[footer]'
              , @data       [xml]
              , @head       [nvarchar](max)
              , @footer     [nvarchar](max)
              , @value      [nvarchar](max);
      --
      ---------------------------------------------
      select @data = (select [data]
                      from   [repository].[get] (null, @head_fqn));
      select @head = @data.query(N'for $d in /*/html order by $d/@sequence[1] ascending return $d').value(N'.', N'[nvarchar](max)');
      --
      select @data = (select [data]
                      from   [repository].[get] (null, @footer_fqn));
      select @footer = @data.query(N'for $d in /*/html order by $d/@sequence[1] ascending return $d').value(N'.', N'[nvarchar](max)');
      --
      ---------------------------------------------
      set @value = @head
                   + @documentation
                   + @footer;
      return @value;
  end;
go 
