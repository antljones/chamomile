use [test_01]

GO

with [address_builder]
     as (select [address].[AddressID]                                as [address_id],
                [address_type].[AddressTypeName]                     as [address_type],
                [address].[StreetName]                               as [street1],
                convert([sysname], [address].[OutsideAddressNumber]) as [outside_address_number],
                convert([sysname], [address].[InsideAddressNumber])  as [inside_address_number],
                [address].[BetweenStreets]                           as [between_streets],
                [state].[StateCode]                                  as [state],
                [township].[TownshipName]                            as [township_name],
                [suburb].[SuburbName]                                as [suburb_name],
                [city].[CityName]                                    as [city],
                [postal_zone].[PostalZone]                           as [postal_code],
                [country].[MajorRegionCode]                          as [country]
         --[address_purpose_type].[AddressPurposeTypeName]
         --[address].[PartyID],
         --[address].[PartyRoleID],
         --[address].[PreferredMethodOfContact]
         from   [dbo].[Address] as [address]
                left join [dbo].[AddressType] as [address_type]
                       on [address_type].[AddressTypeID] = [address].[AddressTypeID]
                left join [dbo].[Country] as [country]
                       on [country].[ISOCountryCode] = [address].[CountryCode]
                left join [dbo].[State] as [state]
                       on [state].[StateID] = [address].[StateID]
                left join [dbo].[City] as [city]
                       on [city].[CityID] = [address].[CityID]
                left join [dbo].[PostalZone] as [postal_zone]
                       on [postal_zone].[PostalZoneID] = [address].[PostalZoneID]
                left join [dbo].[AddressPurposeType] as [address_purpose_type]
                       on [address_purpose_type].[AddressPurposeTypeID] = [address].[AddressPurposeTypeID]
                left join [dbo].[Township] as [township]
                       on [township].[TownshipID] = [address].[TownshipID]
                left join [dbo].[Suburb] as [suburb]
                       on [suburb].[SuburbID] = [address].[SuburbID])
insert into [Address__secure].[Data]
            ([ID],
             [Entry])
select [address_id] as [ID],
       case
         when ( [township_name] is null )
       --
--begin_no_format
       then convert([xml], N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="'
                           + isnull([address_type], N'') + N'" >'
                           + N'<street1>' + isnull([street1], N'') + N'</street1>'
						   + N'<quarter>' + isnull([township_name], N'') + N'</quarter>'
                           + N'<postal_code_locality_province>'
							   + isnull([postal_code] + N', ', N'')
							   + isnull([city] + N', ', N'')
							   + isnull([state], N'')
                           + N'</postal_code_locality_province>'
                           + N'<country>' + isnull([country], N'') + N'</country>'
                           + N'</noetic:address_mexico_01>')
         else convert([xml], N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="' + isnull([address_type], N'') + N'" >'
                             + N'<street1>' + isnull([street1], N'') + N'</street1>'
							 + N'<village>' + isnull([suburb_name], N'') + N'</village>'
                             + N'<postal_code_locality_province>'
								 + isnull([postal_code] + N', ', N'')
								 + isnull([city] + N', ', N'')
								 + isnull([state], N'')
                             + N'</postal_code_locality_province>'
                             + N'<country>' + isnull([country], N'') + N'</country>'
                             + N'</noetic:address_mexico_01>')
       end as [Entry]
	   --end_no_format

from   [address_builder];

/*
	Uri�n 30					street number and name 
	Col. Tlatilco				name of quarter (colonia) 
	02860 MEXICO, D.F.			postcode + locality name, province abbrev. 
	MEXICO

	Super Manzana 3 � 403		street number and name � apartment no. 
	Puerto Juarez				village 
	77520 CANCUN, Q. ROO		postcode + locality name, province abbrev. 
	MEXICO
*/
declare @example_01_pdf xml = N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="business" >
	<!-- street number and name -->
	<street1>Uri�n 30</street1>
	<!-- name of quarter (colonia) -->
	<quarter>Col. Tlatilco</quarter>
	<!-- postcode + locality name, province abbrev. -->
	<postal_code>77520 MEXICO, D.F.</postal_code>
	<country>MEXICO</country>
</noetic:address_mexico_01>';
declare @example_01_gbm xml = N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="business" >
</noetic:address_mexico_01>';
declare @example_02_pdf xml = N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="business" >
	<!-- street number and name � apartment no. -->
	<street1>Super Manzana 3 � 40</street1>
	<!-- village -->
	<village>Puerto Jaurez</village>
	<!-- postcode + locality name, province abbrev. -->
	<postal_code>77520 CANCUN, Q. ROO</postal_code>
	<country>Mexico</country>
</noetic:address_mexico_01>';
declare @example_02_gbm xml = N'<noetic:address_mexico_01 xmlns:noetic="http://www.noeticpartners.com/" address_type="business" >
</noetic:address_mexico_01>';

select @example_01_pdf,
       @example_02_pdf; 
