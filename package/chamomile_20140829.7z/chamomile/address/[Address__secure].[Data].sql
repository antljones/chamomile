use [test_02];

go

if schema_id(N'Address__secure') is null
  execute (N'create schema Address__secure');

go

if exists (select *
           from   [sys].[objects]
           where  [object_id] = object_id(N'[Address__secure].[Data]')
                  and [type] in ( N'U' ))
  drop table [Address__secure].[Data];

go

set ANSI_NULLS on

GO

set QUOTED_IDENTIFIER on

GO

if not exists (select *
               from   [sys].[objects]
               where  [object_id] = object_id(N'[Address__secure].[Data]')
                      and [type] in ( N'U' ))
  begin
      create table [Address__secure].[Data]
        (
           [ID]              [int] identity(1, 1) not null,
           [Entry]           xml ([Address__secure].[XSC]) not null,
           [BeginDate]       [date] not null,
           [BeginDateTime]   [datetimeoffset](7) not null,
           [EndDate]         [date] null,
           [EndDateTime]     [datetimeoffset](7) null,
           [CreatedBy]       [nvarchar](250) not null,
           [CreatedDateTime] [datetimeoffset](7) not null,
           constraint [Address__secure__Data__ID__primary_key] primary key ([ID])
        );
  end

go

grant execute on [Address__secure].[Data] to usrdesa;

go

if not exists (select *
               from   dbo.sysobjects
               where  id = OBJECT_ID(N'[dbo].[DF__Address__secure__Data__BeginDate]')
                      and type = 'D')
  begin
      alter table [Address__secure].[Data]
        add constraint [DF__Address__secure__Data__BeginDate] default (getdate()) for [BeginDate]
  end

GO

if not exists (select *
               from   dbo.sysobjects
               where  id = OBJECT_ID(N'[dbo].[DF__Address__secure__Data__BeginDateTime]')
                      and type = 'D')
  begin
      alter table [Address__secure].[Data]
        add constraint [DF__Address__secure__Data__BeginDateTime] default (getdate()) for [BeginDateTime]
  end

GO

if not exists (select *
               from   dbo.sysobjects
               where  id = OBJECT_ID(N'[dbo].[DF__Address__secure__Data__AddressCreatedBy]')
                      and type = 'D')
  begin
      alter table [Address__secure].[Data]
        add constraint [DF__Address__secure__Data__AddressCreatedBy] default (host_name()) for [CreatedBy]
  end

GO

if not exists (select *
               from   dbo.sysobjects
               where  id = OBJECT_ID(N'[dbo].[DF__Address__secure__Data__CreatedDateTime]')
                      and type = 'D')
  begin
      alter table [Address__secure].[Data]
        add constraint [DF__Address__secure__Data__CreatedDateTime] default (getdate()) for [CreatedDateTime]
  end

GO 

if exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Address__secure', null, null))
  exec sys.sp_dropextendedproperty
    @name=N'description',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=null,
    @level2name=null

GO

if not exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Data', null, null))
  exec sys.sp_addextendedproperty
    @name=N'description',
	@value=N'[Address__secure].[Data] - Primary store for addresses. Addresses are typed using XML Schema Collection [Address__secure].[XSC]. See XSC for examples.',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=null,
    @level2name=null

GO

if exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Address__secure', N'COLUMN', N'Entry'))
  exec sys.sp_dropextendedproperty
    @name=N'description',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=N'COLUMN',
    @level2name=N'Entry'

GO

if not exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Data', N'COLUMN', N'Entry'))
  exec sys.sp_addextendedproperty
    @name=N'description',
	@value=N'[Entry] xml ([Address__secure].[XSC]) not null - Data is typed using XML Schema Collection [Address__secure].[XSC]. See XSC for examples.',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=N'COLUMN',
    @level2name=N'Entry'

GO


if exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Address__secure', N'COLUMN', N'ID'))
  exec sys.sp_dropextendedproperty
    @name=N'description',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=N'COLUMN',
    @level2name=N'ID'

GO

if not exists (select *
           from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'Address__secure', N'TABLE', N'Data', N'COLUMN', N'ID'))
  exec sys.sp_addextendedproperty
    @name=N'description',
	@value=N'[ID] [int] identity(1, 1) not null - Identity column and primary key.',
    @level0type=N'SCHEMA',
    @level0name=N'Address__secure',
    @level1type=N'TABLE',
    @level1name=N'Data',
    @level2type=N'COLUMN',
    @level2name=N'ID'

GO
