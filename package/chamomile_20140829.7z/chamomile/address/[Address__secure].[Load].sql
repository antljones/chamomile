use [test_02];

go

if schema_id(N'Address__secure') is null
  execute (N'create schema Address__secure');

go

if object_id(N'[Address__secure].[Load]', N'P') is not null
  drop procedure [Address__secure].[Load];

go


/*
	Katherine E. Lightsey
	20140313

	Loads address data into [Address__secure].[Data]
*/
create procedure [Address__secure].[Load] @ID    [int] = null output,
                                          @Entry xml ([Address__secure].[XSC])
as
  begin
      declare @output as table
        (
           [action] [sysname],
           [id]     [int]
        );

      merge into [Address__secure].[Data] as target
      using (select @ID    as [id],
                    @Entry as [entry]) as source
      on target.[ID] = source.[id]
      when matched then
        update set target.[Entry] = source.[entry]
      when not matched then
        insert ([Entry])
        values ([entry])
      output $action,
             isnull(inserted.[ID], deleted.[ID])
      into @output ([action], [id]);

      set @ID = (select top(1) [id]
                 from   @output);
  end

go

grant execute on [Address__secure].[Load] to usrdesa;

go 
