/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
	  Identify worst performing queries. 

	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------

*/
-- 
-- Using cume_dist() and percent_rank()to identify worst performing queries 
--------------------------------------------------------------------------
select [text]
       , [total_elapsed_time]
       , cast(cume_dist()
                over (
                  order by [total_elapsed_time])as decimal (5, 2)) as [cumulative_distribution]
       , cast(percent_rank()
                over (
                  order by [total_elapsed_time])as decimal (5, 2)) as [percent_rank]
       , *
from   [sys].[dm_exec_query_stats]
       cross apply [sys].[dm_exec_sql_text](sql_handle)
order  by [cumulative_distribution] desc;