use [chamomile];
go
if object_id(N'[repository].[archive]', N'P') is not null
  drop procedure [repository].[archive];
go
/*
	

	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository_secure'
            , @object [sysname] = N'archive';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object; 
*/
create procedure [repository].[archive]
as
  begin
      set transaction isolation level serializable;
      declare @change [xml];
      while (select count(*)
             from   [chamomile].[cdc].[repository_secure.data_ct])
            > 0
        begin
            begin transaction archive;
            -- 
            -- todo - get standard records "__$..." then get all else as select *
            -- so the same "archive" method can be used for all tables and will always
            -- get all columns.
            -------------------------------------
            set @change = (select top(100) [__$start_lsn]     as N'@start_lsn'
                                           , [__$end_lsn]     as N'@end_lsn'
                                           , [__$seqval]      as N'@seqval'
                                           , [__$operation]   as N'@operation'
                                           , [__$update_mask] as N'@update_mask'
                                           , [id]             as N'change/@id'
                                           , [entry]          as N'change/entry'
                           from   [chamomile].[cdc].[repository_secure.data_ct]
                           order  by [__$start_lsn] desc
                           for xml path(N'change'), root(N'change_batch'));
            if @change is not null
              insert into [chamomile_change].[repository_secure].[change]
                          ([change])
              values      (@change);
            with [delete_set]
                 as (select top(100) *
                     from   [cdc].[repository_secure.data_ct]
                     order  by [__$start_lsn] desc)
            delete from [delete_set];
            commit transaction archive;
        end;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'medium'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140724', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140724'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140724'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_repository', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_repository'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_repository'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'repository', N'procedure', N'archive', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'archive';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'archive'
go 
