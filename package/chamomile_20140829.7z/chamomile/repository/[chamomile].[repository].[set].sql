use [chamomile];
go
if schema_id(N'repository') is null
  execute (N'create schema repository');
go
if object_id(N'[repository].[set]', N'P') is not null
  drop procedure [repository].[set];
go
/*

	declare @stack         xml ([chamomile].[xsc]) = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-24T12:01:54.347" id="">
							  <subject fqn="[chamomile].[xsc].[stack].[prototype]">
								<description>Description of subject</description>
							  </subject>
							  <object>
								<meta_data fqn="[chamomile].[utility].[meta_data].[stack].[prototype]">
								  <description>test test.</description>
								  <value>test test</value>
								  <constraint></constraint>
								</meta_data>
							  </object>
							  <result>
								<description>Description of result</description>
							  </result>
							</chamomile:stack>'
            , @return_code [int];
    execute @return_code = [repository].[set]
      @stack =@stack output;
    select *
    from   [repository].[get_list] (N'[chamomile].[test].[test_01]');
    execute @return_code = [repository].[set]
      @stack    =@stack output
      , @delete = 1;
    select @stack         as N'@stack output'
           , @return_code as N'@return_code';
      from   [repository].[get_list] (N'[chamomile].[test].[test_01]');
    
    
    

	select *
	from   [repository].[get] (N'D7DA6197-CB12-E411-A7DF-20689D66B6F7', null);

	select *
	from   [repository].[get] (null, N'[chamomile].[test].[test_01]');


	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository'
            , @object [sysname] = N'set';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
*/
create procedure [repository].[set]
  @id       [uniqueidentifier] = null
  , @stack  xml([chamomile].[xsc]) = null output
  , @update [bit] = 1
  , @delete [bit] = 0
as
  begin
      set nocount on;
      declare @object_fqn                         [nvarchar](1000)
              , @invalid_parameter_list_prototype [nvarchar](1000)= N'[chamomile].[return_code].[invalid_parameter_list]'
              , @false_prototype                  [nvarchar](1000)=N'[chamomile].[constant].[boolean].[default].[false]';
      declare @builder               [xml]
              , @stack_builder       [xml] = @stack
              , @false               [sysname] = [utility].[get_meta_data]( @false_prototype)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126)
              , @application_message [nvarchar](max)
              , @message             [nvarchar](max)
              , @subject_fqn         [nvarchar](1000)
              , @subject_description [nvarchar](1000)
              , @error_stack_builder [xml]
              , @return_code         [int]
              , @entry               xml([chamomile].[xsc]);
      declare @output as table (
        [action]  [sysname]
        , [id]    [uniqueidentifier]
        , [entry] [xml]
        );
      --
      -- validate meta data and prototypes
      --	this method allows validation to occur in the same construct as that of building
      --	a result set of invalid results.
      -------------------------------------------------
      begin
          set @message=null;
          with [invalid_data_finder]
               as (select [value]
                          , [prototype]
                   from   ( values (@false
                          , @false_prototype)) as [invalid_data] ([value], [prototype]))
          select @message = coalesce(@message, N'', N'') + [prototype]
                            + N', '
          from   [invalid_data_finder]
          where  [value] is null;
          if @message is not null
            if @message is not null
              begin
                  set @message=left(@message, len(@message) - 1);
                  raiserror (100066,1,1,@message);
                  return 100066;
              end;
      end;
      --
      ---------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      set @subject_description = N'created by ' + @subject_fqn;
      --
      ---------------------------
      if @stack_builder is null
         and @id is null
        begin
            set @message= N'@stack and @id both cannot be null values. Values can be retrieved from the repository either by [id] or @object_fqn.';
            raiserror (100068,1,1,@message);
            return 100068;
        end;
      --
      ---------------------------
      else if @stack_builder is not null
        begin
            set @object_fqn = @stack.value(N'data(/*/object/*/@fqn)[1]', N'[nvarchar](1000)');
            set @stack_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
            set @stack_builder.modify(N'replace value of (/*/subject/@fqn)[1] with sql:variable("@subject_fqn")');
            set @stack_builder.modify(N'replace value of (/*/subject/description/text())[1] with sql:variable("@subject_description")');
        end;
      --
      ---------------------------
      set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
											replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      --
      ---------------------------
      if @delete = 1
        begin
            if @id is null
              begin
                  set @id=(select [id]
                           from   [repository].[get_list](@object_fqn)
                           where  [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
                  												string(/*[1]/object[1]/*[1]/@fqn[1])[1]', N'nvarchar(max)') = @object_fqn
                                  and ( [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
                  												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)') = @false
                                         or [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
                  												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)') is null ));
                  delete from [repository_secure].[data]
                  where  [id] = @id;
              end;
            else
              begin
                  delete from [repository_secure].[data]
                  where  [id] = @id
                         and [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)') = @false;
              end;
        end;
      else
        begin
            if @id is not null
              begin
                  update [repository_secure].[data]
                  set    [entry] = @stack
                  where  [id] = @id;
              end;
            else
              begin
                  begin try
                      with [non_persistent]
                           as (select [id]
                                      , [entry]
                                      , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/object[1]/*[1]/@fqn[1])[1]', N'nvarchar(max)') as [name]
                                      , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)')         as [persistent]
                               from   [repository_secure].[data])
                      merge into [non_persistent] as target
                      using (values (@id
                            , @object_fqn
                            , @stack
                            , @false)) as source ([id], [name], [entry], [persistent])
                      on target.[entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/object[1]/*[1]/@fqn[1])[1]', N'nvarchar(max)') = source.[name]
                      --
                      ----------------------------------------------------------------
                      when matched and target.[persistent] = @false then
                        update set target.[entry] = source.[entry]
                      when not matched by target then
                        insert ([entry])
                        values (source.[entry])
                      output $action
                             , coalesce([inserted].[id], [deleted].[id])
                             , coalesce([inserted].[entry], [deleted].[entry])
                      into @output([action], [id], [entry]);
                  end try
                  begin catch
                      set @application_message=N'<application_message>error attempting to merge into repository</application_message>';
                      --
                      -----------------------------------
                      execute [utility].[handle_error]
                        @procedure_id         =@@procid
                        , @application_message=@application_message
                        , @stack              =@error_stack_builder output;
                      set @stack = @error_stack_builder;
                      --
                      -----------------------------------
                      return 1;
                  end catch;
              end;
            --
            ----------------------------------------------------------------
            set @id = coalesce((select [id]
                                from   @output
                                where  lower([action]) = N'insert'), (select [id]
                                                                      from   @output
                                                                      where  lower([action]) = N'update'), (select [id]
                                                                                                            from   @output
                                                                                                            where  lower([action]) = N'delete'));
            set @entry = @stack;
            set @entry.modify(N'declare namespace chamomile="http://www.katherinelightsey.com";
			insert attribute id {sql:variable("@id")} as last into (/*)[1]');
            set @stack = @entry;
        end;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'
			
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			
		'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'repository', N'procedure', N'set', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'repository', N'procedure', N'set', N'parameter', N'@id'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@id';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@id] [uniqueidentifier] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@id';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'repository', N'procedure', N'set', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@stack';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'repository', N'procedure', N'set', N'parameter', N'@delete'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'repository'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=N'parameter'
    , @level2name=N'@delete';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@delete] [bit] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'repository'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=N'parameter'
  , @level2name=N'@delete'; 
