use [chamomile];
go
if schema_id(N'repository_test') is null
  execute (N'create schema repository_test');
go
if object_id(N'[repository_test].[get]', N'P') is not null
  drop procedure [repository_test].[get];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
    -- to view documentation
    ----------------------------------------------------------------------
    declare @schema   [sysname] = N'repository_test'
            , @object [sysname] = N'get';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object; 
*/
create procedure [repository_test].[get]
  @stack xml ([chamomile].[xsc]) output
as
  begin
      set nocount on;
      set transaction isolation level serializable;
      --
      -------------------------------------------
      declare @test_builder                      [xml]
              , @error_stack                     [xml]
              , @sequence                        [int] = 0
              , @count                           [int] = 0
              , @return_code                     [int] = 0
              , @test_builder_result_description [nvarchar](max)
              , @id                              [uniqueidentifier]
              , @actual                          [sysname]
              , @object_fqn                      [nvarchar](1000)
              , @subject_fqn                     [nvarchar](1000)
              , @description                     [nvarchar](max)
              , @application_message             [nvarchar](max)
              , @message                         [nvarchar](max)
              , @expected                        [sysname]
              , @builder_02                      [xml];
      --
      -- meta data and prototype names, used both to get meta data and messages and in error messages (raiserror)
      -------------------------------------------
      declare @test_type_meta_data       [nvarchar](1000)= N'[chamomile].[constant].[test].[default].[test]'
              , @pass_meta_data          [nvarchar](1000)= N'[chamomile].[constant].[result].[default].[pass]'
              , @fail_meta_data          [nvarchar](1000)= N'[chamomile].[constant].[result].[default].[fail]'
              , @test_stack_prototype    [nvarchar](1000)= N'[chamomile].[test].[test_stack].[stack].[prototype]'
              , @data_stack_prototype    [nvarchar](1000)= N'[chamomile].[data].[stack].[prototype]'
              , @chamomile_xsc_prototype [nvarchar](1000)= N'[chamomile].[xsc].[stack].[prototype]'
              , @test_prototype          [nvarchar](1000)= N'[chamomile].[test].[test].[stack].[prototype]'
              , @prototype_not_found     [nvarchar](1000)= N'[chamomile].[constant].[return_code].[prototype_not_found]'
              , @meta_data_not_found     [nvarchar](1000)= N'[chamomile].[constant].[return_code].[meta_data_not_found]';
      --
      -------------------------------------------
      declare @type                  [sysname] = [utility].[get_meta_data](@test_type_meta_data)
              , @pass                [sysname] = [utility].[get_meta_data](@pass_meta_data)
              , @fail                [sysname]= [utility].[get_meta_data](@fail_meta_data)
              --
              -------------------------------------------
              , @test                [xml]= [utility].[get_prototype](@test_prototype) 
              , @stack_builder       [xml]= [utility].[get_prototype](@chamomile_xsc_prototype) 
              , @test_stack          [xml]= [utility].[get_prototype](@test_stack_prototype) 
              , @error_stack_builder [xml]= [utility].[get_prototype](@chamomile_xsc_prototype) 
              , @data_stack          [xml]= [utility].[get_prototype](@data_stack_prototype) 
              , @builder_01          [xml]= [utility].[get_prototype](@chamomile_xsc_prototype) ;
      --
      -------------------------------------------
      declare @test_object_description    [nvarchar](max) = N'the object that is constructed as a test.'
              , @test_result_description  [nvarchar](max) = N'the result of the test on the test object.'
              , @test_stack_description   [nvarchar](max) = N'the stack of all tests executed within this method, along with counts of all tests and results.'
              , @timestamp                [sysname] = convert([sysname], current_timestamp, 126)
              , @stack_result_description [nvarchar](max) = N'Individual results are contained within the tests. No aggregate result is expected for this stack.'
              , @transaction              [sysname] = N'repository_test_get_'
                + cast(round(rand()*100000, -1) as [nvarchar](1000))
                + N'_'
                + cast(datepart(millisecond, current_timestamp) as [sysname])
                + ']';
      --
      -- validate meta data and prototypes
      --	this method allows validation to occur in the same construct as that of building
      --	a result set of invalid results.
      -------------------------------------------------
      begin
          set @message=null;
          with [invalid_data_finder]
               as (select [value]
                          , [prototype]
                   from   ( values (@type
                          , @test_type_meta_data),
                                   (@pass
                          , @pass_meta_data),
                                   (@fail
                          , @fail_meta_data),
                                   (cast(@test as [nvarchar](max))
                          , @test_prototype),
                                   (cast(@stack_builder as [nvarchar](max))
                          , @chamomile_xsc_prototype),
                                   (cast(@test_stack as [nvarchar](max))
                          , @test_stack_prototype),
                                   (cast(@error_stack_builder as [nvarchar](max))
                          , @chamomile_xsc_prototype),
                                   (cast(@data_stack as [nvarchar](max))
                          , @data_stack_prototype),
                                   (cast(@builder_01 as [nvarchar](max))
                          , @chamomile_xsc_prototype) ) as [invalid_data] ([value], [prototype]))
          select @message = coalesce(@message, N'', N'') + [prototype]
                            + N', '
          from   [invalid_data_finder]
          where  [value] is null;
          if @message is not null
            if @message is not null
              begin
                  set @message=left(@message, len(@message) - 1);
                  raiserror (100066,1,1,@message);
                  return 100066;
              end;
      end;
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder_01 output;
      set @subject_fqn = @builder_01.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      -------------------------------------------
      set @test_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@subject_fqn")');
      set @test_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@test_stack_description")');
      set @test_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      --
      -------------------------------------------
      set @stack_builder.modify(N'replace value of (/*/subject/@fqn)[1] with sql:variable("@subject_fqn")');
      set @stack_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      set @stack_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@stack_result_description")');
      --
      -------------------------------------------
      begin
          begin
              --
              -- begin modify data
              -----------------------------------
              select @sequence = 1
                     , @object_fqn = N'[chamomile].[repository_test].[set].[retrieve_by_name_'
                                     + cast(round(rand()*100000, -1) as [sysname])
                                     + N'_'
                                     + cast(datepart(millisecond, current_timestamp) as [sysname])
                                     + ']'
                     , @expected = @pass
                     , @actual = @fail
                     , @description = N'Test for correctly retrieving a value from [repository_secure].[data] by [name].'
                     , @test_builder_result_description = N'The result stack is expected to have an "id" attribute with the [uniqueidentifier] of the inserted object from which the retrieve is tested.';
              -----------------------------------
              -- end modify data
              --
              --
              -----------------------------------
              set @data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @data_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              --
              ---------------------------------------
              set @test_builder = ( [utility].[get_prototype](@chamomile_xsc_prototype) );
              set @test_builder.modify(N'insert sql:variable("@data_stack") as last into (/*/object)[1]');
              set @test_builder.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@description")');
              set @test_builder.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@object_fqn")');
              set @test_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_builder_result_description")');
              set @test_builder.modify(N'replace value of (/*/object/@type)[1] with ("test")');
              --
              ---------------------------------------
              set @test = [utility].[get_prototype](@test_prototype) ;
              set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
              set @test.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              set @test.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');
              set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @test.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @test.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_result_description")');
              set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_object_description")');
              set @test.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/object)[1]');
              begin
                  begin transaction @transaction;
                  begin try
                      --
                      -- begin modify data
                      --   build appropriate test code
                      -------------------------------
                      execute [repository].[set]
                        @stack =@test_builder output;
                      if exists
                         (select *
                          from   [repository].[get] (null, @object_fqn))
                        set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@pass")');
                      -------------------------------
                      -- end modify data
                      --
                      --
                      -------------------------------
                      set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/result)[1]');
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end try
                  begin catch
                      set @application_message=N'Error in test; sequence="'
                                               + cast(@sequence as [sysname])
                                               + N'", name="' + @object_fqn + N'"';
                      execute [utility].[handle_error]
                        @stack                 = @error_stack output
                        , @procedure_id        =@@procid
                        , @application_message =@application_message;
                      set @test.modify(N'insert sql:variable("@error_stack") as last into (/*/result)[1]');
                      --
                      -------------------------------
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end catch;
              end;
              set @test_stack.modify(N'insert sql:variable("@test") as last into (/*)[1]');
          end;
          --
          ---------------------------------------
          begin
              --
              -- begin modify data
              ---------------------------------------
              select @sequence = 2
                     , @object_fqn = N'[chamomile].[repository_test].[set].[retrieve_by_id_'
                                     + cast(round(rand()*100000, -1) as [sysname])
                                     + N'_'
                                     + cast(datepart(millisecond, current_timestamp) as [sysname])
                                     + ']'
                     , @expected = @pass
                     , @actual = @fail
                     , @description = N'Test for correctly retrieving a value from [repository_secure].[data] by [id].'
                     , @test_builder_result_description = N'The result stack is expected to have an "id" attribute with the [uniqueidentifier] of the inserted object from which the retrieve is tested.';
              ---------------------------------------
              -- end modify data
              --
              --
              ---------------------------------------
              set @data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @data_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              --
              ---------------------------------------
              set @test_builder = [utility].[get_prototype](@chamomile_xsc_prototype);
              set @test_builder.modify(N'insert sql:variable("@data_stack") as last into (/*/object)[1]');
              set @test_builder.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@description")');
              set @test_builder.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@object_fqn")');
              set @test_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_builder_result_description")');
              set @test_builder.modify(N'replace value of (/*/object/@type)[1] with ("test")');
              --
              ---------------------------------------
              set @test = [utility].[get_prototype](@test_prototype) ;
              set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
              set @test.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              set @test.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');
              set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @test.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @test.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_result_description")');
              set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_object_description")');
              set @test.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/object)[1]');
              begin
                  if @@trancount = 0
                    begin transaction @transaction;
                  else
                    begin
                        set @message=N'unable to begin transaction ('
                                     + @transaction + N')';
                        raiserror (100067,1,1,@message);
                        return 100067;
                    end
                  begin try
                      --
                      -- begin modify data
                      --   build appropriate test code
                      -------------------------------
                      execute [repository].[set]
                        @stack =@test_builder output;
                      set @id = @test_builder.value(N'(/*/@id)[1]', N'[uniqueidentifier]');
                      if exists
                         (select *
                          from   [repository].[get] (@id, null))
                        set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@pass")');
                      -------------------------------
                      -- end modify data
                      --
                      --
                      -------------------------------
                      set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/result)[1]');
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end try
                  begin catch
                      set @application_message=N'Error in test; sequence="'
                                               + cast(@sequence as [sysname])
                                               + N'", name="' + @object_fqn + N'"';
                      execute [utility].[handle_error]
                        @stack                 = @error_stack output
                        , @procedure_id        =@@procid
                        , @application_message =@application_message;
                      set @test.modify(N'insert sql:variable("@error_stack") as last into (/*/result)[1]');
                      --
                      -------------------------------
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end catch;
              end;
              set @test_stack.modify(N'insert sql:variable("@test") as last into (/*)[1]');
          end;
          --
          ---------------------------------------
          begin
              --
              -- begin modify data
              -----------------------------------
              select @sequence = 3
                     , @object_fqn = N'[chamomile].[repository_test].[set].[delete_non_persistent_record_'
                                     + cast(round(rand()*100000, -1) as [sysname])
                                     + N'_'
                                     + cast(datepart(millisecond, current_timestamp) as [sysname])
                                     + ']'
                     , @expected = @pass
                     , @actual = @fail
                     , @description = N'Test for correctly deleting a record that is NOT marked as persistent.'
                     , @test_builder_result_description = N'The result stack is expected to have an "id" attribute with the [uniqueidentifier] of the inserted object from which the retrieve is tested.';
              ---------------------------------------
              -- end modify data
              --
              --
              ---------------------------------------
              set @data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @data_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              --
              ---------------------------------------
              set @test_builder = [utility].[get_prototype](@chamomile_xsc_prototype);
              set @test_builder.modify(N'insert sql:variable("@data_stack") as last into (/*/object)[1]');
              set @test_builder.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@description")');
              set @test_builder.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@object_fqn")');
              set @test_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_builder_result_description")');
              set @test_builder.modify(N'replace value of (/*/object/@type)[1] with ("test")');
              --
              ---------------------------------------
              set @test = [utility].[get_prototype](@test_prototype) ;
              set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
              set @test.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              set @test.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');
              set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @test.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @test.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_result_description")');
              set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_object_description")');
              set @test.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/object)[1]');
              begin
                  if @@trancount = 0
                    begin transaction @transaction;
                  else
                    begin
                        set @message=N'unable to begin transaction ('
                                     + @transaction + N')';
                        raiserror (100067,1,1,@message);
                        return 100067;
                    end
                  begin try
                      --
                      -- begin modify data
                      --   build appropriate test code
                      -------------------------------
                      execute @return_code = [repository].[set]
                        @stack =@test_builder output;
                      if @return_code != 0
                        return @return_code;
                      -------------------------------
                      execute @return_code = [repository].[set]
                        @stack    =@test_builder output
                        , @delete = 1;
                      if @return_code != 0
                        return @return_code;
                      set @id = @test_builder.value(N'(/*/@id)[1]', N'[uniqueidentifier]');
                      if not exists
                             (select *
                              from   [repository].[get] (@id, null))
                        set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@pass")');
                      -------------------------------
                      -- end modify data
                      --
                      --
                      -------------------------------
                      set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/result)[1]');
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end try
                  begin catch
                      set @application_message=N'Error in test; sequence="'
                                               + cast(@sequence as [sysname])
                                               + N'", name="' + @object_fqn + N'"';
                      execute [utility].[handle_error]
                        @stack                 = @error_stack output
                        , @procedure_id        =@@procid
                        , @application_message =@application_message;
                      set @test.modify(N'insert sql:variable("@error_stack") as last into (/*/result)[1]');
                      --
                      -------------------------------
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end catch;
              end;
              set @test_stack.modify(N'insert sql:variable("@test") as last into (/*)[1]');
          end;
          --
          ---------------------------------------
          begin
              --
              -- begin modify data
              ---------------------------------------
              select @sequence = 4
                     , @object_fqn = N'[chamomile].[repository_test].[set].[do_not_delete_persistent_record_'
                                     + cast(round(rand()*100000, -1) as [sysname])
                                     + N'_'
                                     + cast(datepart(millisecond, current_timestamp) as [sysname])
                                     + ']'
                     , @expected = @pass
                     , @actual = @fail
                     , @description = N'Test for correctly NOT deleted a record that is marked as persistent.'
                     , @test_builder_result_description = N'The result stack is expected to have an "id" attribute with the [uniqueidentifier] of the inserted object from which the retrieve is tested.';
              ---------------------------------------
              -- end modify data
              --
              --
              ---------------------------------------
              set @data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @data_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              --
              ---------------------------------------
              set @test_builder = [utility].[get_prototype](@chamomile_xsc_prototype);
              set @test_builder.modify(N'insert sql:variable("@data_stack") as last into (/*/object)[1]');
              set @test_builder.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@description")');
              set @test_builder.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@object_fqn")');
              set @test_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_builder_result_description")');
              set @test_builder.modify(N'replace value of (/*/object/@type)[1] with ("test")');
              set @test_builder.modify(N'replace value of (/*/@persistent)[1] with ("true")');
              --
              ---------------------------------------
              set @test = [utility].[get_prototype](@test_prototype) ;
              set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
              set @test.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
              set @test.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');
              set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @test.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
              set @test.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@test_result_description")');
              set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_object_description")');
              set @test.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
              set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/object)[1]');
              begin
                  if @@trancount = 0
                    begin transaction @transaction;
                  else
                    begin
                        set @message=N'unable to begin transaction ('
                                     + @transaction + N')';
                        raiserror (100067,1,1,@message);
                        return 100067;
                    end
                  begin try
                      --
                      -- begin modify data
                      --   build appropriate test code
                      -------------------------------
                      execute @return_code = [repository].[set]
                        @stack =@test_builder output;
                      if @return_code != 0
                        return @return_code;
                      -------------------------------
                      execute @return_code = [repository].[set]
                        @stack    =@test_builder output
                        , @delete = 1;
                      if @return_code != 0
                        return @return_code;
                      set @id = @test_builder.value(N'(/*/@id)[1]', N'[uniqueidentifier]');
                      if exists
                         (select *
                          from   [repository].[get] (@id, null))
                        set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@pass")');
                      -------------------------------
                      -- end modify data
                      --
                      --
                      -------------------------------
                      set @test.modify(N'insert sql:variable("@test_builder") as last into (/*/result)[1]');
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end try
                  begin catch
                      set @application_message=N'Error in test; sequence="'
                                               + cast(@sequence as [sysname])
                                               + N'", name="' + @object_fqn + N'"';
                      execute [utility].[handle_error]
                        @stack                 = @error_stack output
                        , @procedure_id        =@@procid
                        , @application_message =@application_message;
                      set @test.modify(N'insert sql:variable("@error_stack") as last into (/*/result)[1]');
                      --
                      -------------------------------
                      if exists
                         (select *
                          from   [sys].[dm_tran_active_transactions]
                          where  [name] = @transaction)
                        rollback transaction @transaction;
                  end catch;
              end;
              set @test_stack.modify(N'insert sql:variable("@test") as last into (/*)[1]');
          end;
      end;
      --
      -------------------------------------------
      set @stack_builder.modify(N'insert sql:variable("@test_stack") as last into (/*/object)[1]');
      --
      -- build totals
      -------------------------------------------
      set @count = @stack_builder.value(N'count (/*/object/test_stack/test)', N'[int]');
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/@test_count)[1] with sql:variable("@count")');
      set @count = @stack_builder.value(N'count (/*/object/test_stack/test[@actual="pass"])', N'[int]');
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/@pass_count)[1] with sql:variable("@count")');
      set @count = @stack_builder.value(N'count (/*/object/test_stack/test[@actual="fail"])', N'[int]');
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/@error_count)[1] with sql:variable("@count")');
      --
      -------------------------------------------
      set @stack = @stack_builder;
      return 0;
  end;
go
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'frequency', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'frequency'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'frequency'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'{todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_documentation', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_documentation'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_documentation'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get';
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'repository_test', N'procedure', N'get', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get';
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml ([chamomile].[xsc]), @return_code [int];
	execute @return_code = [repository_test].[get] @stack=@stack output;
	select @stack as [@stack], @return_code as [@return_code];'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'repository_test', N'procedure', N'get', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'repository_test'
    , @level1type=N'procedure'
    , @level1name=N'get'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
go
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'repository_test'
  , @level1type=N'procedure'
  , @level1name=N'get'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
