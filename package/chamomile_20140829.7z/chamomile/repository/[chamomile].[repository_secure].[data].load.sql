
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		preload data into [repository_secure].[data].

*/
use [chamomile];

go

set nocount on;

go

delete from [repository_secure].[data];

go

set nocount on;

declare @stack         xml([chamomile].[xsc])
        , @subject_fqn [nvarchar](1000) = N'[chamomile].[repository_secure].[data].[load.sql]'
        , @subject_descripton [nvarchar](max) = N'Data pre-load script.'
        , @object_fqn  [nvarchar](1000)
        , @object_type [sysname]
        , @timestamp   [sysname] = convert([sysname], current_timestamp, 126)
        , @builder     [xml];

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[xsc].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="'+@timestamp+N'">
				<subject fqn="[chamomile].[xsc].[stack].[prototype]" >
					<description>Description of subject</description>
				</subject>
				<object/>
				<result>
					<description>Description of result</description>
				</result>
			</chamomile:stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[log_stack].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<log_stack fqn="[chamomile].[log_stack].[stack].[prototype]" timestamp="'+@timestamp+N'" >	
				<description>prototype</description>
			</log_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[log].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<log sequence="0" timestamp="'+@timestamp+N'" >	
				<description>prototype</description>
			</log>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[data].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<data fqn="[chamomile].[data].[stack].[prototype]" error_count="0" timestamp="'+@timestamp+N'" >	
				<description>prototype</description>
			</data>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[error_suite].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<error_suite fqn="[chamomile].[utility].[error_suite].[stack].[prototype]" error_count="0" timestamp="'+@timestamp+N'" >	
				<description>prototype for [chamomile].[error_suite].[stack]</description>
			</error_suite>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
	
	
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[error_stack].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<error_stack fqn="[chamomile].[utility].[error_stack].[stack].[prototype]" error_count="0" timestamp="'+@timestamp+N'" >
				<description>prototype for [chamomile].[error_stack].[stack]</description>
			</error_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation].[html].[footer].[template]" >
		<description>prototype</description>
		<data>
			<html sequence="99999">
					<p class="footer">All content is copyright <a href="http://www.katherinelightsey.com" target="blank">Katherine Elizabeth Lightsey</a> 1959-2014 (aka; my life), all rights reserved. All software contained herein is licensed as <a href="http://www.katherinelightsey.com/#!chamomile/c1pl">[chamomile]</a> and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html">GNU Affero GPL</a>.</p>
			</html>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation].[html].[head].[template]" >
		<description>prototype</description>
		<data>
			<html sequence="0">
				<link rel="stylesheet" type="text/css" href="..\..\..\source\common.css" target="blank" />
				<p class="header">built on <a href="http://www.katherinelightsey.com" target="blank">[chamomile].[documentation]</a></p>
			</html>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation_stack].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<documentation_stack fqn="[chamomile].[documentation_stack].[stack].[prototype]" stale="false" timestamp="'+@timestamp+N'" >
			  <description>prototype</description>
			</documentation_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation].[html].[prototype]" >
		<description>prototype</description>
		<data>
			<documentation_stack fqn="[chamomile].[documentation].[html].[prototype]" stale="false" timestamp="'+@timestamp+N'" >
				<html sequence="0" />
			</documentation_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation].[text].[prototype]" >
		<description>prototype</description>
		<data>
			<documentation_stack fqn="[chamomile].[documentation].[text].[prototype]" stale="false" timestamp="'+@timestamp+N'" >
				<text sequence="0" />
			</documentation_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[error].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<error fqn="[chamomile].[utility].[error].[stack].[prototype]" schema="error_procedure_schema" error_procedure="error_procedure" error_number="0" error_line="0" error_severity="0" error_state="0" timestamp="'+@timestamp+N'">		
				<description>construct "error_message" is system generated; construct "application_message" is built by the application when it catches an error and before it calls [chamomile].[utility].[handle_error].</description>
				<error_message />
			</error>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[application_message].[prototype]" >
		<description>prototype</description>
		<data>
			<application_message fqn="[chamomile].[utility].[application_message].[prototype]" >
				<description />
			</application_message>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[command_stack].[stack].[prototype]">
		<description>prototype</description>
		<data>
			<command_stack fqn="[chamomile].[command_stack].[stack].[prototype]"  recursion_level="0">		
				<description>prototype for [chamomile].[command_stack].[stack]</description>
			</command_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[command].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<command fqn="[chamomile].[command].[stack].[prototype]" timestamp="'+@timestamp+N'" >
				<description>prototype for [chamomile].[command].[stack]</description>
			</command>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[test].[test_suite].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<test_suite fqn="[chamomile].[test].[test_suite].[stack].[prototype]" stack_count="0" test_count="0" error_count="0" pass_count="0" timestamp="'+@timestamp+N'" >	
				<description>prototype for [chamomile].[test].[test_suite]</description>
			</test_suite>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
	
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[test].[test_stack].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<test_stack fqn="[chamomile].[test].[test_stack].[stack].[prototype]" test_count="0" error_count="0" pass_count="0" timestamp="'+@timestamp+N'" >
				<description>prototype for [chamomile].[test].[test_stack]</description>
			</test_stack>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[test].[test].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<test sequence="1" fqn="[chamomile].[test].[test].[stack].[prototype]" expected="pass" actual="fail" timestamp="'+@timestamp+N'" >
				<description>prototype for [chamomile].[test].[test]</description>
				<object fqn="[chamomile].[test].[stack].[object]">
					<description>prototype for [chamomile].[test].[test]</description>
				</object>
				<result>
					<description>prototype for [chamomile].[test].[test]</description>
				</result>
			</test>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[meta_data].[value].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<meta_data fqn="[chamomile].[utility].[meta_data].[value].[stack].[prototype]" >
				<description>prototype for meta_data objects.</description>
				<value>value_1</value>
				<constraint>|value_1|value_2|</constraint>
			</meta_data>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[meta_data].[prototype].[stack].[prototype]" >
		<description>prototype</description>
		<data>
			<meta_data fqn="[chamomile].[utility].[meta_data].[prototype].[stack].[prototype]" >
				<description>prototype for meta_data objects.</description>
				<data />
			</meta_data>
		</data>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[test].[default].[suffix]" >
		<description>Default suffix for test schemas; for business schema [business_application_01] there should be a test schema [business_application_01_test].</description>
		<value>_test</value>
		<constraint>|_test|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[result].[default].[pass]">
		<description>Default text string to indicate "pass".</description>
		<value>pass</value>
		<constraint>|pass|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[result].[default].[fail]">
		<description>Default text string to indicate "fail".</description>
		<value>fail</value>
		<constraint>|fail|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[naming_convention].[default].[filter]" >
		<description>Default filter used for [chamomile] object naming as passed through [utility].[all_string]; allowed values.</description>
		<value>a-z0-9._</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[test].[default].[test]">
		<description>Test type.</description>
		<value>test</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[boolean].[default].[true]">
		<description>true</description>
		<value>true</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[boolean].[default].[false]">
		<description>false</description>
		<value>false</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[utility].[handle_error].[description]">
		<description>default description for error stack.</description>
		<value>error stack built by [chamomile].[utility].[handle_error].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[description].[default].[lock_test].[stack_subject]">
		<description>default stack subject for [chamomile].[lock_test]</description>
		<value>Tests generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[description].[default].[lock_test].[stack_result]">
		<description>default stack result for [chamomile].[lock_test]</description>
		<value>Result of tests generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[description].[default].[lock_test].[command_stack]">
		<description>default command_stack description for [chamomile].[lock_test]</description>
		<value>Test command_stack generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[constant].[description].[default].[lock_test].[command]">
		<description>default command description for [chamomile].[lock_test]</description>
		<value>Test command generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[license]">
		<description>Short text version of the [chamomile] license.</description>
		<value>
			<![CDATA[
				<p class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</p>
			]]>
		</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[license].[documentation]">
		<description>Text automatically appended to the footer of documentation generated by [chamomile].[documentation]</description>
		<value>
			<![CDATA[
				<p class="footer_append">
					Documentation generated programmatically using <a href="http://www.katherinelightsey.com/#!documentation/cr08" target="blank">[chamomile].[documentation].
				</p>
			]]>
		</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
-- meta data - imlemented as system messages - (re: [chamomile].[presentation].[sp_addmessage] - http://www.katherinelightsey.com/#!spaddmessage/czpx)
--------------------------------------------------------------------------
--------------------------------------------------------------------------

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100066)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100066;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100066
  , @severity=11
  , @msgtext = N'[chamomile].[constant].[return_code].[data_not_found] - meta_data or prototype was not found for the value of [sys].[messages].[message_id] provided (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100067)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100067;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100067
  , @severity=11
  , @msgtext = N'[chamomile].[constant].[error].[existing_transaction] - unable to continue due to an existing transaction (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100068)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100068;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100068
  , @severity=11
  , @msgtext = N'[chamomile].[constant].[error].[invalid_parameter_list] - the parameter list as entered is not valid (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go
