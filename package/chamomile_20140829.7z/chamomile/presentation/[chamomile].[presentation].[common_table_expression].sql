/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		COMMON TABLE EXPRESSION
			[ WITH <common_table_expression> [ ,...n ] ]

			<common_table_expression>::=
				expression_name [ ( column_name [ ,...n ] ) ]
				AS
				( CTE_query_definition )

			The following clauses cannot be used in the CTE_query_definition: 
				ORDER BY (except when a TOP clause is specified)
				INTO 
				OPTION clause with query hints
				FOR XML
				FOR BROWSE
			A common table expression (CTE) can be thought of as a temporary result set that is defined within the execution scope 
			of a single SELECT, INSERT, UPDATE, DELETE, or CREATE VIEW statement. A CTE is similar to a derived table in that 
			it is not stored as an object and lasts only for the duration of the query. Unlike a derived table, a CTE can be 
			self-referencing and can be referenced multiple times in the same query.
			Using a CTE offers the advantages of improved readability and ease in maintenance of complex queries. The query 
			can be divided into separate, simple, logical building blocks. These simple blocks can then be used to build 
			more complex, interim CTEs until the final result set is generated. 

			CTEs can be defined in user-defined routines, such as functions, stored procedures, triggers, or views.

	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------
		Recursive Queries Using Common Table Expressions: http://msdn.microsoft.com/en-us/library/ms186243.aspx
		WITH common_table_expression (Transact-SQL): http://msdn.microsoft.com/en-us/library/ms175972.aspx

*/
--
-- code block begin
--------------------------------------------
use [chamomile];
go
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
if object_id(N'tempdb..##flower', N'U') is not null
  drop table ##flower;
create table ##flower (
  [id]       int identity(1, 1)
  , [flower] nvarchar(250)
  , [color]  nvarchar(250)
  , [count]  int
  );
insert into ##flower
            ([flower],[color],[count])
values      (N'rose',N'red',5),
            (N'rose',N'red',3),
            (N'rose',N'red',2),
            (N'rose',N'red',1),
            (N'rose',N'red',9),
            (N'marigold',N'yellow',2),
            (N'marigold',N'yellow',9),
            (N'marigold',N'yellow',4),
            (N'marigold',N'yellow',6),
            (N'marigold',N'yellow',7);
--
select *
from   ##flower;
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
--
-- Select only those records from a table where the count is greater than the average count
-------------------------------------------------
with [grouper]
     as (select [color]
                , avg(cast([count] as decimal(5, 2))) as [average]
         from   ##flower
         group  by [color])
select [flower].[flower]
       , [flower].[color]
       , [flower].[count]
from   ##flower as [flower]
       join [grouper] as [grouper]
         on [grouper].[color] = [flower].[color]
where  [flower].[count] > [grouper].[average]
group  by [flower]
          , [flower].[color]
          , [flower].[count];
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
--
-- Using an alias list
with [alias_list] ([hue], [dog])
     as (select [color]
                , avg(cast([count] as decimal(5, 2))) as [average]
         from   ##flower
         group  by [color])
select [flower].[flower]    as [flower]
       , [alias_list].[hue] as [hue]
       , [flower].[count]   as [count]
from   ##flower as [flower]
       join [alias_list] as [alias_list]
         on [alias_list].[hue] = [flower].[color]
where  [flower].[count] > [alias_list].[dog]
group  by [flower]
          , [alias_list].[hue]
          , [flower].[count];
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
--	multiple cte's
--------------------------------------------
with [first_cte]
     as (select [flower]
                , [color]
                , count(*) as [count]
         from   ##flower
         where  [count] > 3
         group  by [flower]
                   , [color]),
     [second_cte]
     as (select [flower]
                , [color]
                , count(*) as [count]
         from   ##flower
         where  [count] < 4
         group  by [flower]
                   , [color])
--
select [flower]
       , [color]
       , [count]
from   [first_cte]
union
select [flower]
       , [color]
       , [count]
from   [second_cte]
order  by [flower]
          , [color];
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
--
-- Remove duplicates from a table
-- Note that the records are ONLY managed by the unique definition. Variations outside that are ignored.
-- Note that the records are deleted directly from the CTE rather than from the table!
-------------------------------------------------
-- many duplicates
select [flower]
       , [color]
from   ##flower;
--
-------------------------------------------------
with [duplicate_finder]([name], [color], [sequence])
     as (select [flower]
                , [color]
                , row_number()
                    over (
                      partition by [flower], [color]
                      order by [flower] desc) as [sequence]
         from   ##flower)
delete from [duplicate_finder]
where  [sequence] > 1;
--
-- no duplicates
-------------------------------------------------
select [flower]
       , [color]
from   ##flower;
--------------------------------------------
-- code block end
--
--
-- code block begin
--------------------------------------------
--
-- persistent records
-- note that the merge is directly into the cte!
-------------------------------------------------
if schema_id(N'fruit') is null
  execute('create schema fruit');
go
-------------------------------------------------
if object_id(N'[fruit].[data]', N'U') is not null
  drop table [fruit].[data];
go
create table [fruit].[data](
  [fruit]        [sysname] primary key clustered
  , [color]      [sysname]
  , [persistent] [sysname] default( N'false')
  );
-------------------------------------------------
insert into [fruit].[data]
            ([fruit],[color])
values      (N'apple',N'red'),
            (N'banana',N'yellow'),
            (N'orange',N'orange');
-------------------------------------------------
insert into [fruit].[data]
            ([fruit],[color],[persistent])
values      (N'pear',N'green',N'true');
-------------------------------------------------
select *
from   [fruit].[data];
go
-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
--
-- is not updated as pear is a persistent record
-------------------------------------------------
declare @fruit   [sysname] = N'pear'
        , @color [sysname] = N'orange'
        , @false [sysname] = N'false';
--
with [non_persistent]
     as (select [fruit]        as [fruit]
                , [color]      as [color]
                , [persistent] as [persistent]
         from   [fruit].[data])
merge into [non_persistent] as target
using (values (@fruit
      , @color)) as source ([fruit], [color])
on target.[fruit] = source.[fruit]
-- only match for an update when target.[persistent]=N'false'
when matched and target.[persistent]=@false then
  update set target.[color] = source.[color]
output $action
       , inserted.*
       , deleted.*;
--
select *
from   [fruit].[data];
go
-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
--
-- is updated as apple is not a persistent record
-------------------------------------------------
declare @fruit   [sysname] = N'apple'
        , @color [sysname] = N'red and white striped'
        , @false [sysname] = N'false';
--
with [non_persistent]
     as (select [fruit]        as [fruit]
                , [color]      as [color]
                , [persistent] as [persistent]
         from   [fruit].[data])
merge into [non_persistent] as target
using (values (@fruit
      , @color)) as source ([fruit], [color])
on target.[fruit] = source.[fruit]
-- only match for an update when target.[persistent]=N'false'
when matched and target.[persistent]=@false then
  update set target.[color] = source.[color]
output $action
       , inserted.*
       , deleted.*;
--
select *
from   [fruit].[data];
go
-------------------------------------------------
-- code block end
--
