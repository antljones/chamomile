/*

*/

begin transaction;
execute [utility].[set_prototype]
  @object_fqn   = N'[test_99].[test_99].[test_99]'
  , @prototype  = N'<test_99 stuff="stuff"/>'
  , @description=N'test_99 description';
select [utility].[get_prototype](N'[test_99].[test_99].[test_99]');
rollback; 
