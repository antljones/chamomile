use [chamomile];
go
if object_id(N'[utility].[set_prototype]', N'P') is not null
  drop procedure [utility].[set_prototype];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
			, @object [sysname] = N'split_string';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
*/
create procedure [utility].[set_prototype]
  @object_fqn    [nvarchar](max)
  , @prototype   [xml]
  , @description [nvarchar](max)
  , @delete      [bit] = 0
as
  begin
      declare @timestamp             [sysname] = convert([sysname], current_timestamp, 126)
              , @server_information  [xml]
              , @return_code         [int]
              , @subject_fqn         [nvarchar](max)
              , @meta_data_stack     [xml] = [utility].[get_prototype](N'[chamomile].[utility].[meta_data].[prototype].[stack].[prototype]')
              , @subject_description [nvarchar](max)
              , @builder             [xml] = [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]')
              , @stack               xml([chamomile].[xsc]);
      --
      ---------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@server_information output;
      set @subject_fqn = @server_information.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      set @subject_description = N'created by ' + @subject_fqn;
      --
      ---------------------------
      set @meta_data_stack.modify(N'insert sql:variable("@prototype") as last into (/*/data)[1]');
      set @meta_data_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@description")');
      set @meta_data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
      set @builder.modify(N'replace value of (/*/subject/@fqn)[1] with sql:variable("@subject_fqn")')
      set @builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")')
      set @builder.modify(N'replace value of (/*/subject/description/text())[1] with sql:variable("@subject_description")');
      set @builder.modify(N'insert sql:variable("@meta_data_stack") as last into (/*/object)[1]');
      set @stack = @builder;
      --
      ----------------------------------------------
      execute @return_code = [repository].[set]
        @stack =@stack output;
      return @return_code;
  end;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'inserts a prototype [xml] object into the repository.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_utility', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_utility'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_utility'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'procedure', N'set_prototype', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype';
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'execute [utility].[set_prototype] @object_fqn = N''[test].[test].[test]'', @prototype = N''<test stuff="stuff"/>'', @description=N''test description'';
	select [utility].[get_prototype](N''[chamomile].[data].[stack].[prototype]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype'
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_prototype', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@object_fqn [nvarchar](max) - the fully qualified name of the prototype object to insert in "[category].[class].[type].[prototype]" format.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_prototype', N'parameter', N'@prototype'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype'
    , @level2type=N'parameter'
    , @level2name=N'@prototype';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@prototype [xml] - the [xml] object to set as a prototype.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype'
  , @level2type=N'parameter'
  , @level2name=N'@prototype';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_prototype', N'parameter', N'@description'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype'
    , @level2type=N'parameter'
    , @level2name=N'@description';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@description [nvarchar] (max) - the business description / use for the prototype.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype'
  , @level2type=N'parameter'
  , @level2name=N'@description';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_prototype', N'parameter', N'@delete'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_prototype'
    , @level2type=N'parameter'
    , @level2name=N'@delete';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@delete [bit] - delete the prototype if set to 1.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_prototype'
  , @level2type=N'parameter'
  , @level2name=N'@delete'; 
