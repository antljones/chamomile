use [chamomile];
go
begin
    begin transaction utility_test_get_meta_data;
    declare @stack    xml([chamomile].[xsc])
            , @random [sysname] = cast(round(rand()*100000, -1) as [sysname])
              + N'_'
              + cast(datepart(millisecond, current_timestamp) as [sysname]);
    declare @object_fqn [nvarchar](max)
            , @prefix   [nvarchar](max) = N'[chamomile].[return_code].[test1_';
    --
    set @object_fqn = @prefix + @random + N'].[part1]';
    execute [utility].[set_meta_data]
      @object_fqn   =@object_fqn
      , @value      =@random
      , @description=N'test description.'
      , @stack      =@stack output;
    set @object_fqn = @prefix + @random + N'].[part2]';
    execute [utility].[set_meta_data]
      @object_fqn   =@object_fqn
      , @value      =@random
      , @description=N'test description.'
      , @stack      =@stack output;
    if (select count(*)
        from   [utility].[get_meta_data_list](@prefix))
       = 2
      select N'pass';
    else
      select N'fail';
    rollback transaction utility_test_get_meta_data;
end; 
