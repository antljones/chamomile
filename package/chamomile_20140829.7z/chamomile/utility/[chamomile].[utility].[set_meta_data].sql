use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[set_meta_data]', N'P') is not null
  drop procedure [utility].[set_meta_data];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
			, @object [sysname] = N'set_meta_data';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
*/
create procedure [utility].[set_meta_data]
  @object_fqn    [nvarchar](max)
  , @value       [nvarchar](max) = null
  , @constraint  [nvarchar](max) = null
  , @description [nvarchar](max)
  , @stack       xml([chamomile].[xsc]) = null output
as
  begin
      declare @subject_fqn           [nvarchar](1000)
              , @message             [nvarchar](max)
              , @return_code         [int]
              , @builder             [xml]
              , @entry_builder       [xml] = [utility].[get_prototype](N'[chamomile].[xsc].[stack].[prototype]')
              , @meta_data_stack     [xml] =[utility].[get_prototype](N'[chamomile].[utility].[meta_data].[value].[stack].[prototype]')
              , @object_type         [sysname] = N'meta_data'
              , @subject_description [nvarchar](max)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126);
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @subject_description = N'Created by ' + @subject_fqn + N'.';
      --
      -------------------------------------------
      if @constraint is not null
        if patindex (N'|%' + @value + N'|%', isnull(@constraint, N'|%' + @value + N'|%')) < 1
          begin
              set @message = N'error: "[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]" - in: '
                             + @subject_fqn;
              set @return_code =cast ([utility].[get_meta_data](N'[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]') as [int]);
              raiserror(@message,1,1);
              return @return_code;
          end;
      --
      -------------------------------------------
      if @constraint is not null
        set @meta_data_stack.modify(N'replace value of (/*/constraint/text())[1] with sql:variable("@constraint")');
      else
        set @meta_data_stack.modify('delete (/*/constraint/text())[1]');
      set @meta_data_stack.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
      if @value is not null
        set @meta_data_stack.modify(N'replace value of (/*/value/text())[1] with sql:variable("@value")');
      if @description is not null
        set @meta_data_stack.modify(N'replace value of (/*/*/text())[1] with sql:variable("@description")');
      --
      -------------------------------------------
      set @entry_builder.modify(N'insert sql:variable("@meta_data_stack") as last into (/*/object)[1]');
      set @object_fqn=lower(@object_fqn);
      execute [repository].[set]
        @stack=@entry_builder output;
      set @stack = @entry_builder;
  end
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'creates a meta data object in the repository.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml([chamomile].[xsc]);
execute [utility].[set_meta_data]
  @object_fqn   =N''[chamomile].[return_code].[test1]''
  , @value      =N''test test''
  , @description=N''test test.''
  , @stack      =@stack output;
select @stack;
select [utility].[get_meta_data](N''[chamomile].[return_code].[test1]'');
select *
from   [repository].[get_list] (N''[chamomile].[return_code].[code_65]''); '
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_utility', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_utility'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_utility'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'the fully qualified name of the meta data object to create in "[category].[class].[type]" format.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@value'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@value';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@value nvarchar (max) - the value to be returned when requesting the meta data object by fqn.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@value';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@constraint'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@constraint';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@constraint nvarchar (max) - the constraint to place on the @value, in pipe delimited format.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@constraint';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@description'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@description';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@description nvarchar (max) - the business description of the meta data including where and how it is to be used.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@description';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_meta_data', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@stack xml - the output stack of the mutated meta data object.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
