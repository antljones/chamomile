use [chamomile];
go
--
declare @stack           xml
        , @log_prototype [xml]=[utility].[get_prototype](N'[chamomile].[log].[stack].[prototype]')
        , @timestamp     [sysname] = convert([sysname], current_timestamp, 126)
        , @data          [xml] = N'<valid_xml>text</valid_xml>'
        , @description   [nvarchar](max) = N'test log entry'
        , @object_fqn    [nvarchar](max)=N'[test_01].[test_01].[test_01].[test_02]';
set @log_prototype.modify(N'replace value of (/log/@timestamp)[1] with sql:variable("@timestamp")');
set @log_prototype.modify(N'replace value of (/log/description/text())[1] with sql:variable("@description")');
set @log_prototype.modify(N'insert sql:variable("@data") as last into (/log)[1]');
--
begin transaction;
begin
    --
    -- create a new log node/sequence - automatically sequence
    -------------------------------------------------
    set @log_prototype.modify(N'replace value of (/log/description/text())[1] with "first log sequence"');
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description = @description
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'added first sequence';
    --
    --
    -- create a new log node/sequence - automatically sequence
    -------------------------------------------------
    set @log_prototype.modify(N'replace value of (/log/description/text())[1] with "second log sequence"');
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description = @description
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'added second sequence';
    --
    -- delete a specific node based on sequence number
    -------------------------------------------------
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description =@description
      , @delete      = 1
      , @sequence    = 2
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'deleted sequence 2';
    --
    --
    -- create a new log node/sequence - explicit sequence
    -------------------------------------------------
    set @log_prototype.modify(N'replace value of (/log/description/text())[1] with "log sequence 33"');
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description =@description
      , @sequence    = 33
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'created sequence 33';
    --
    -- update a log sequence
    -------------------------------------------------
    set @log_prototype.modify(N'replace value of (/log/description/text())[1] with "log sequence 33 updated"');
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description =@description
      , @sequence    = 33
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'updated sequence 33 with new text';
    --
    -- delete the complete log entry
    -------------------------------------------------
    execute [utility].[set_log]
      @object_fqn    = @object_fqn
      , @log         = @log_prototype
      , @description =@description
      , @delete      = 2
      , @stack       = @stack output;
    --
    select [utility].[get_log](@object_fqn) as N'entry was deleted';
end;
rollback;
go 
