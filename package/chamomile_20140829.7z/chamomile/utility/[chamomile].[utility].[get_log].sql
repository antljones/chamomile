use [chamomile];
go
if object_id(N'[utility].[get_log]', N'FN') is not null
  drop function [utility].[get_log];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
            , @object [sysname] = N'get_log';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object; 
    
*/
create function [utility].[get_log](
  @object_fqn [nvarchar](max))
returns [xml]
as
  begin
      declare @log [xml];
      set @log = (select [data]
                  from   [repository].[get] (null, @object_fqn));
      return @log;
  end;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'retrieves a log entry from the repository.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_log', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_log'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_log'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log'
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'function', N'get_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log';
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'select [utility].[get_log](N''[category].[class].[type]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log'
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'function', N'get_log', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'get_log'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@object_fqn [nvarchar] (max) - the fully qualified name of the log object to retrieve in "[category].[class].[type]" format.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'get_log'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn'; 
