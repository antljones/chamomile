use [chamomile];
go
if object_id(N'[utility].[set_log]', N'P') is not null
  drop procedure [utility].[set_log];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
            , @object [sysname] = N'set_log';
    select [schemas].[name]                as [schema]
           , [objects].[name]              as [object]
           , [extended_properties].[name]  as [property]
           , [extended_properties].[value] as [value]
    from   [sys].[extended_properties] as [extended_properties]
           join [sys].[objects] as [objects]
             on [objects].[object_id] = [extended_properties].[major_id]
           join [sys].[schemas] as [schemas]
             on [objects].[schema_id] = [schemas].[schema_id]
    where  [schemas].[name] = @schema
           and [objects].[name] = @object;
*/
create procedure [utility].[set_log]
  @object_fqn    [nvarchar](max)
  , @log         [xml] = null
  , @description [nvarchar](max) = null
  , @sequence    [int] = 0
  , @delete      [int] = 0
  , @stack       xml([chamomile].[xsc]) = null output
as
  begin
      declare @timestamp             [sysname] = convert([sysname], current_timestamp, 126)
              , @log_stack_prototype [xml] = [utility].[get_prototype](N'[chamomile].[log_stack].[stack].[prototype]')
              , @builder             [xml]
              , @subject_fqn         [nvarchar](max);
      --
      -------------------------------------------
      execute [dbo].[sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](max)');
      --
      -------------------------------------------
      set @log.modify(N'replace value of (/log/@timestamp)[1] with sql:variable("@timestamp")');
      set @description = coalesce(@description, @log.value(N'(/log/description/text())[1]', N'[nvarchar](max)'));
      --
      -------------------------------------------
      if @delete > 0
        execute [chamomile].[documentation].[set]
          @object_fqn =@object_fqn
          , @sequence =@sequence
          , @delete   =@delete
          , @stack    =@stack output;
      else
        execute [chamomile].[documentation].[set]
          @object_fqn  =@object_fqn
          , @prototype =@log_stack_prototype
          , @data      =@log
          , @sequence  =@sequence
          , @delete    =@delete
          , @stack     =@stack output;
  end;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'creates, updates, or deletes (mutates) a log entry in the repository.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'classification', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'classification'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'classification'
  , @value     =N'low'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140723', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140723'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'revision_20140723'
  , @value     =N'Katherine E. Lightsey'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_log', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_log'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_log'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.93.00', N'SCHEMA', N'utility', N'procedure', N'set_log', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.93.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log';
exec sys.sp_addextendedproperty
  @name        =N'release_00.93.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@object_fqn';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@object_fqn nvarchar (max) - the fully qualified name of the log object to be mutated in "[category].[class].[type]" format.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@object_fqn';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@log'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@log';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@log xml - the value to be inserted as a log entry.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@log';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@description'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@description';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@description nvarchar (max) - the business description of the log entry.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@description';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@sequence'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@sequence';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@sequence int - the sequence number of the log entry. If null, incremented to max + 1. If exists, the sequence is replaced.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@sequence';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@delete'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@delete';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@delete int - if 1, the specified sequence is deleted. If 2, the entire log entry is deleted.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@delete';
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'utility', N'procedure', N'set_log', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_log'
    , @level2type=N'parameter'
    , @level2name=N'@stack';
exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@stack xml - the output parameter as the full entry inserted into the repository.'
  , @level0type=N'schema'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_log'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
