use [chamomile];
go
if object_id(N'[documentation].[get]', N'FN') is not null
  drop function [documentation].[get];
go
/*
	select [documentation].[get_formatted_html] (N'[chamomile].[job].[get_change]');

	select [documentation].[get](N'[chamomile].[job].[get_change]');
	select [documentation].[get](N'[chamomile].[job].[get_change].[step_1]');
*/
create function [documentation].[get] (
  @fqn [nvarchar](max))
returns [nvarchar](max)
as
  begin
      declare @value [nvarchar](max);
      declare @data xml = (select [entry]
         from   [repository].[get] (null, @fqn));
      declare @documentation as table (
        [sequence]        [int]
        , [documentation] [nvarchar](max)
        );
      --
      -------------------------------------------------
      insert into @documentation
                  ([sequence],[documentation])
        select t.c.value(N'./sequence[1]', N'[int]')
               , t.c.value(N'./text[1]', N'[nvarchar](max)')
        from   @data.nodes(N'for $d in /*/object/documentation order by $d/@sequence[1] ascending return $d') as t(c);
      insert into @documentation
                  ([sequence],[documentation])
        select t.c.value(N'./sequence[1]', N'[int]')
               , t.c.value(N'./html[1]', N'[nvarchar](max)')
        from   @data.nodes(N'for $d in /*/object/documentation order by $d/@sequence[1] ascending return $d') as t(c);
      select @value = coalesce(@value, N' ', N'')
                      + [documentation]
      from   @documentation
      where  [documentation] is not null;
      --
      ---------------------------------------------
      return @value;
  end;
go 
