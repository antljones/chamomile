use [chamomile];
go
if object_id(N'[documentation].[get_function]', N'FN') is not null
  drop function [documentation].[get_function];
go
/*
	select [documentation].[get_function](N'[chamomile].[documentation].[get_job]');
*/
create function [documentation].[get_function](@fqn [sysname]) returns [nvarchar](max) as
begin
    declare @documentation           [nvarchar](max)
            , @function_details        [nvarchar](max)
            , @function_documentation  [nvarchar](max)
            , @parameter_documentation [nvarchar](max);
    declare @schema   [sysname] = parsename(@fqn, 2)
            , @object [sysname] = parsename(@fqn, 1);
    --
    select @function_details = N'<div id="first_indent"><details><summary>function details</summary><ol><li>object_id {'
                               + cast([object_id] as [sysname]) + N'}</li>'
                               + N'<li>created {'
                               + cast([create_date] as [sysname])
                               + N'}</li>' + N'<li>modified {'
                               + cast([modify_date] as [sysname])
                               + N'}</li></details></div>'
    from   [sys].[objects] as [objects]
           left join [sys].[extended_properties] as [extended_properties]
                  on [extended_properties].[major_id] = [objects].[object_id]
                     and [extended_properties].[class] = 1
    where  object_schema_name([objects].[object_id]) = @schema
           and [objects].[name] = @object
           and [objects].[type] in ( N'FN', N'IF', N'TF' );
    --
    begin
		-- todo - handle TF
        select @parameter_documentation = coalesce(@parameter_documentation, N' ', N'')
                                  + N'<li>' + case
                                  --
                                  when [parameters].[name] is null or len([parameters].[name]) = 0then N'{returns} ' else [parameters].[name] end
                                  --
                                  + case
                                  --
                                  when type_name([parameters].[user_type_id]) like N'n%' and [parameters].[max_length]=-1 then N' [' + type_name([parameters].[user_type_id]) + N'](max)'
                                  --
                                  when type_name([parameters].[user_type_id]) like N'n%' then N' [' + type_name([parameters].[user_type_id]) + N'](' + cast ([parameters].[max_length]/2 as [sysname]) + N')'
                                  --
                                  else N' [' + type_name([parameters].[user_type_id]) + N']'
                                  --
                                  end
                                  + isnull(N' - ' + cast([extended_properties].[name] as [sysname]) + N' {' + cast([extended_properties].[value] as [nvarchar](max)) + N'}', N'')
                                  + N'</li>'
from   [sys].[parameters] as [parameters]
       join [sys].[objects] as [objects]
         on [objects].[object_id] = [parameters].[object_id]
       left join [sys].[extended_properties] as [extended_properties]
              on [extended_properties].[major_id] = [objects].[object_id]
                 and [extended_properties].[class] != 1
        where  object_schema_name([objects].[object_id]) = @schema
               and [objects].[name] = @object
               and [objects].[type] in ( N'FN', N'IF', N'TF' );
        select @parameter_documentation = N'<div id="first_indent"><details><summary>parameter documentation</summary><ol>'
                                          + @parameter_documentation
                                          + N'</details></div>'; 
        
    end;
    --
    begin
        select @function_documentation =  coalesce(@function_documentation, N' ', N'')
                                          + isnull(N'<li>'
                                          + cast([extended_properties].[name] as [sysname])
                                          + N' {'
                                          + isnull(cast([extended_properties].[value] as [nvarchar](max)), N'')
                                          + N'}', N'')
        from   [sys].[objects] as [objects]
               left join [sys].[extended_properties] as [extended_properties]
                      on [extended_properties].[major_id] = [objects].[object_id]
                         and [extended_properties].[class] = 1
        where  object_schema_name([objects].[object_id]) = @schema
               and [objects].[name] = @object
               and [objects].[type] in ( N'FN', N'IF', N'TF' );
        select @function_documentation = N'<div id="first_indent"><details><summary>function documentation</summary><ol>'
                                         + @function_documentation
                                         + N'</details></div>';
    end;
	set @documentation = N'<div id="first_indent"><details><summary>'+@fqn+N'</summary><ol>'
                                         + @function_documentation
										 + @function_details
										 + @parameter_documentation
                                         + N'</details></div>';;
    return @documentation;
end;
go 
