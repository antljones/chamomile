use [chamomile];
go
if object_id(N'[documentation].[get_procedure_list]', N'P') is not null
  drop procedure [documentation].[get_procedure_list];
go
/*
	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126), @documentation [nvarchar](max), @bcp_command [nvarchar](max);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_procedure_list]">
				<description>workflow for getting procedure documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_procedure_list]" >		
					<description>get documentation for all procedures.</description>
					<command fqn="[all]" timestamp="' + @timestamp + N'" >
						<description>get documentation for procedure.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>';
	execute [documentation].[get_procedure_list] @stack=@stack, @status="force_refresh", @output_as=N'html', @bcp_command=@bcp_command output, @documentation=@documentation output;
	select @bcp_command;
	go
	
	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126), @documentation [nvarchar](max), @bcp_command [nvarchar](max);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_procedure_list]">
				<description>workflow for getting procedure documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_procedure_list]" >		
					<description>get documentation for all procedures.</description>
					<command fqn="[chamomile].[documentation].[get_procedure_list]" timestamp="' + @timestamp + N'" >
						<description>get documentation for procedure.</description>
					</command>
					<command fqn="[chamomile].[documentation].[get_procedure]" timestamp="' + @timestamp + N'" >
						<description>get documentation for procedure.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>';
	execute [documentation].[get_procedure_list] @stack=@stack, @status="force_refresh", @output_as=N'html', @bcp_command=@bcp_command output, @documentation=@documentation output;
	select @bcp_command;
	go
*/
create procedure [documentation].[get_procedure_list]
  @stack           [xml]
  , @status        [sysname]= N'allow_stale'
  , @output_as     [sysname] = N'html'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @procedure_name            [nvarchar](max)
              , @subject_fqn             [nvarchar](max)
              , @server                  [sysname]
              , @builder                 [xml]
              , @start                   [datetime] = current_timestamp
              , @elapsed            [decimal](9, 4)
              , @timestamp               [sysname] = convert([sysname], current_timestamp, 126)
              , @object_fqn              [nvarchar](max) = N'[chamomile].[documentation].[get_procedure_list]'
              , @procedure_documentation [nvarchar](max)
              , @stack_prototype         [xml] = [utility].[get_prototype](N'[utility].[xsc].[stack].[prototype]');
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      ------------------------------------------------
      if @stack.value(N'(/*/object/workflow/command/@fqn)[1]', N'[sysname]') = N'[all]'
        declare get_procedure_list_cursor cursor for
          select distinct N'[' + db_name() + N'].['
                          + object_schema_name([object_id]) + N'].['
                          + ltrim(rtrim([objects].[name])) + N']'
          from   [sys].[objects] as [objects]
          where  [objects].[type] in ( N'P' );
      else if @stack is not null
        declare get_procedure_list_cursor cursor for
          select t.c.value(N'./@fqn', N'[nvarchar](max)') as [procedure]
          from   @stack.nodes(N'/*/object/workflow/command') as t(c);
      begin
          open get_procedure_list_cursor;
          fetch next from get_procedure_list_cursor into @procedure_name;
          while @@fetch_status = 0
            if @procedure_name is not null
              begin
                  set @procedure_documentation = null;
                  execute [documentation].[get_procedure]
                    @object_fqn     = @procedure_name
                    , @status       = @status
                    , @documentation=@procedure_documentation output;
                  select @documentation = coalesce(@documentation, N'')
                                          + @procedure_documentation;
                  fetch next from get_procedure_list_cursor into @procedure_name;
              end;
          close get_procedure_list_cursor;
          deallocate get_procedure_list_cursor;
      end;
      --
      -------------------------------------------	
      set @documentation = N'<procedure_list><div id="fifth_indent"><details><summary><span id="fourth_list">[procedure_list]</span></h4></summary>'
                           + @documentation
                           --
                           + N'<p class="timestamp">built by {'
                           + @subject_fqn + N'} timestamp {' + @timestamp
                           + N'} elapsed_time(s) {'
                           + cast(@elapsed as [sysname])
                           + N'}</p>'
                           + N'</details></div></procedure_list>';

      --
      -------------------------------------------	
      execute [chamomile].[documentation].[set]
        @object_fqn      =@object_fqn
        , @documentation =@documentation
        , @type          = N'html'
        , @sequence      = 1
        , @stack         = @stack output;
      --
      -------------------------------------------	
      if @output_as = N'html'
        set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                           + @object_fqn + N'''));" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
      else if @output_as = N'xml'
        set @bcp_command = N'BCP "select [documentation].[get] ('''
                           + @object_fqn + N''');" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
  end;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure_list', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure_list'
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure_list'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure_list', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure_list'
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure_list'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140719', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure_list', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140719'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure_list'
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140719'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure_list'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_basic', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure_list', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure_list'
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure_list'
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure_list', default, default))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure_list'
    , @level2type = null
    , @level2name =null;
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'Builds documentation for a batch of procedures.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure_list'
  , @level2type = null
  , @level2name =null;
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure_list', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure_list'
    , @level2type = N'parameter'
    , @level2name =N'@documentation';
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'@status [sysname]= N''allow_stale'' - defaults to ''allow_stale''; default behavior is to accept and retrieve stale documentation. If ''force_refresh'' the documentation will be regenerated regardless of the stale state. If ''require_current'' stale documentation will be refreshed.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure_list'
  , @level2type = N'parameter'
  , @level2name =N'@documentation';
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure_list', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure_list'
    , @level2type = N'parameter'
    , @level2name =N'@documentation';
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'@documentation [nvarchar](max) output - will contain the output of the procedure.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure_list'
  , @level2type = N'parameter'
  , @level2name =N'@documentation';
go 
