use [chamomile];
go
if object_id(N'[documentation].[get_schema]', N'P') is not null
  drop procedure [documentation].[get_schema];
go
/*
	declare @documentation [nvarchar](max)
            , @bcp_command [nvarchar](max);
    execute [documentation].[get_schema]
      @object_fqn     = N'[chamomile].[documentation]'
      , @status       = N'force_refresh'
      , @output_as    = N'html'
      , @bcp_command  =@bcp_command output
      , @documentation=@documentation output;
    select @bcp_command as N'@bcp_command', @documentation as N'@documentation'; 
     
*/
create procedure [documentation].[get_schema]
  @object_fqn      [sysname]
  , @status        [sysname]= N'allow_stale'
  , @output_as     [sysname] = N'html'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @schema                    [sysname] = parsename(@object_fqn, 1)
              , @function_documentation  [nvarchar](max)
              , @procedure_documentation [nvarchar](max)
              , @server                  [sysname]
              , @start                   [datetime] = current_timestamp
              , @elapsed            [decimal](9, 4)
              , @builder                 [xml]
              , @subject_fqn             [nvarchar](max)
              , @extended_properties     [nvarchar](max)
              , @object                  [nvarchar](max)
              , @command                 [xml]
              , @job_documentation       [nvarchar](max)
              , @stack                   xml
              , @timestamp               [sysname] = convert([sysname], current_timestamp, 126);
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      -- extended properties
      ----------------------------------------------
      select @extended_properties = coalesce(@extended_properties, N' ', N'')
                                    + N'<li>' + [extended_properties].[name] + N' {'
                                    + cast([extended_properties].[value] as [nvarchar](max))
                                    + N'}</li>'
      from   [sys].[schemas] as [schemas]
             join [sys].[extended_properties] as [extended_properties]
               on [extended_properties].[major_id] = [schemas].[schema_id]
      where  [schemas].[name] = @schema;
      select @extended_properties = N'<extended_properties><div id="fifth_indent"><details><summary>extended properties</summary><ol>'
                                    + @extended_properties
                                    + N'</ol></details></div></extended_properties>';
      --
      -- procedure documentation
      -- todo - use prototype
      ----------------------------------------------
      begin
          set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="'
                       + @timestamp + N'">
			<subject fqn="[chamomile].[documentation].[get_procedure_list]">
				<description>workflow for getting procedure documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_procedure_list]" >		
					<description>get documentation for all procedures.</description>
				</workflow>
			</object>
		</chamomile:stack>';
          begin
              declare get_schema cursor for
                select N'[' + @schema + N'].[' + [name] + N']'
                from   [sys].[procedures]
                where  object_schema_name([object_id]) = @schema;
              open get_schema;
              fetch next from get_schema into @object;
              while @@fetch_status = 0
                begin
                    set @command = N'<command fqn="' + @object + N'" timestamp="'
                                   + @timestamp
                                   + N'" > <description>get documentation for procedure.</description></command>';
                    set @stack.modify(N'insert sql:variable("@command") as last into (/*/object/workflow)[1]');
                    fetch next from get_schema into @object;
                end;
              close get_schema;
              deallocate get_schema;
          end;
          --
          ----------------------------------------------
          execute [documentation].[get_procedure_list]
            @stack           = @stack
            , @status        =@status
            , @documentation = @procedure_documentation output;
          --
          ----------------------------------------------
          select @documentation = N'<schema_documentation><div id="fourth_indent"><details><summary>'
                                  + @object_fqn + '</summary>'
                                  --
                                  + isnull(@extended_properties, N'')
                                  + isnull(@procedure_documentation, N'')
                           --
                           + N'<p class="timestamp">built by {'
                           + @subject_fqn + N'} timestamp {' + @timestamp
                           + N'} elapsed_time(s) {'
                           + cast(@elapsed as [sysname])
                           + N'}</p>'
                                  + N'</details></div></schema_documentation>';
      end;
      --
      -------------------------------------------	
      execute [chamomile].[documentation].[set]
        @object_fqn      =@object_fqn
        , @documentation =@documentation
        , @type          = N'html'
        , @sequence      = 1
        , @stack         = @stack output;
      --
      -------------------------------------------
      if @output_as = N'html'
        set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                           + @object_fqn + N'''));" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N'  -t, -T -c -d ' + db_name() + N' -S '
                           + @server + N';';
      else if @output_as = N'xml'
        set @bcp_command = N'BCP "select [documentation].[get] ('''
                           + @object_fqn + N''');" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
  end;
go 
