use [chamomile];
go
if object_id(N'[documentation].[get_schema_list]', N'P') is not null
  drop procedure [documentation].[get_schema_list];
go
/*
	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126), @documentation [nvarchar](max), @bcp_command [nvarchar](max);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_schema_list]">
				<description>workflow for getting function documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_schema_list]" >		
					<description>get documentation for listed schema.</description>
					<command fqn="[chamomile].[utility]" timestamp="' + @timestamp + N'" >
						<description>get documentation for schema.</description>
					</command>
					<command fqn="[chamomile].[documentation]" timestamp="' + @timestamp + N'" >
						<description>get documentation for schema.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>'
	execute [documentation].[get_schema_list] @stack=@stack, @status="force_refresh", @output_as=N'html', @bcp_command=@bcp_command output, @documentation=@documentation output;
	select @bcp_command;
	go

	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126), @documentation [nvarchar](max), @bcp_command [nvarchar](max);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_schema_list]">
				<description>workflow for getting function documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_schema_list]" >		
					<description>get documentation for listed schema.</description>
					<command fqn="[all]" timestamp="' + @timestamp + N'" >
						<description>get documentation for schema.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>'
	execute [documentation].[get_schema_list] @stack=@stack, @status="force_refresh", @output_as=N'html', @bcp_command=@bcp_command output, @documentation=@documentation output;
	select @bcp_command;
	go
*/
create procedure [documentation].[get_schema_list]
  @stack           [xml]
  , @status        [sysname]= N'allow_stale'
  , @output_as     [sysname] = N'html'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @schema_name               [nvarchar](max)
              , @procedure_name          [nvarchar](max)
              , @subject_fqn             [nvarchar](max)
              , @schema_documentation    [nvarchar](max)
              , @server                  [sysname]
              , @start                   [datetime] = current_timestamp
              , @elapsed            [decimal](9, 4)
              , @timestamp               [sysname] = convert([sysname], current_timestamp, 126)
              , @builder                 [xml]
              , @object_fqn              [nvarchar](max) = N'[chamomile].[documentation].[get_procedure_list]'
              , @procedure_documentation [nvarchar](max)
              , @stack_prototype         [xml] = [utility].[get_prototype](N'[utility].[xsc].[stack].[prototype]');
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      ------------------------------------------------
      if @stack.value(N'(/*/object/workflow/command/@fqn)[1]', N'[sysname]') = N'[all]'
        declare get_schema_list_cursor cursor for
          select N'[' + db_name() + N'].[' + [objects].[name] + N']'
          from   [sys].[schemas] as [objects]
          where  [objects].[schema_id] between 5 and 16000;
      else if @stack is not null
        declare get_schema_list_cursor cursor for
          select t.c.value(N'./@fqn', N'[nvarchar](max)') as [function]
          from   @stack.nodes(N'/*/object/workflow/command') as t(c);
      begin
          open get_schema_list_cursor;
          fetch next from get_schema_list_cursor into @schema_name;
          while @@fetch_status = 0
            if @schema_name is not null
              begin
                  execute [documentation].[get_schema]
                    @object_fqn     = @schema_name
                    , @status       = @status
                    , @documentation=@schema_documentation output;
                  set @documentation = coalesce(@documentation, N' ', N'')
                                       + @schema_documentation;
                  fetch next from get_schema_list_cursor into @schema_name;
              end;
          close get_schema_list_cursor;
          deallocate get_schema_list_cursor;
      end;
      --
      -------------------------------------------	
      set @documentation = N'<schema_list><div id="third_indent"><details><summary><span id="third_list">[schema_list]</span></summary>'
                           + @documentation
                           --
                           + N'<p class="timestamp">built by {'
                           + @subject_fqn + N'} timestamp {' + @timestamp
                           + N'} elapsed_time(s) {'
                           + cast(@elapsed as [sysname])
                           + N'}</p>'
                           + N'</details></div></schema_list>';
      execute [chamomile].[documentation].[set]
        @object_fqn      =@object_fqn
        , @documentation =@documentation
        , @type          = N'html'
        , @sequence      = 1
        , @stack         = @stack output;
      --
      -------------------------------------------	
      if @output_as = N'html'
        set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                           + @object_fqn + N'''));" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
      else if @output_as = N'xml'
        set @bcp_command = N'BCP "select [documentation].[get] ('''
                           + @object_fqn + N''');" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
  end;
go 
