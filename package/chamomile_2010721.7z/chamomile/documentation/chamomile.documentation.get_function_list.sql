use [chamomile];
go
if object_id(N'[documentation].[get_function_list]', N'FN') is not null
  drop function [documentation].[get_function_list];
go
/*
declare @timestamp [sysname] = convert([sysname], current_timestamp, 126);
declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
		<subject fqn="[chamomile].[documentation].[get_function_list]">
			<description>workflow for getting function documentation</description>
		</subject>
		<object>
			<workflow fqn="[chamomile].[workflow].[get_function_list]" >		
				<description>get documentation for listed functions.</description>
				<command fqn="[chamomile].[utility].[get_prototype]" timestamp="' + @timestamp + N'" >
					<description>get documentation for function.</description>
				</command>
				<command fqn="[chamomile].[utility].[get_meta_data]" timestamp="' + @timestamp + N'" >
					<description>get documentation for function.</description>
				</command>
			</workflow>
		</object>
	</chamomile:stack>'
	select [documentation].[get_function_list](@stack); 
go

	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_function_list]">
				<description>workflow for getting function documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_function_list]" >		
					<description>get documentation for all functions.</description>
					<command fqn="[all]" timestamp="' + @timestamp + N'" >
						<description>get documentation for function.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>'
	
	select [documentation].[get_function_list](@stack); 
*/
create function [documentation].[get_function_list](
  @stack [xml])
returns [nvarchar](max)
as
  begin
      declare @documentation     [nvarchar](max)
              , @function_name   [nvarchar](max)
              , @stack_prototype [xml] = [utility].[get_prototype](N'[utility].[xsc].[stack].[prototype]');
      --
      ------------------------------------------------
      if @stack.value(N'(/*/object/workflow/command/@fqn)[1]', N'[sysname]') = N'[all]'
        declare function_cursor cursor for
          select N'[' + object_schema_name([object_id])
                 + N'].[' + [objects].[name] + N']'
          from   [sys].[objects] as [objects]
          where  [objects].[type] in ( N'FN', N'IF', N'TF' );
      else if @stack is not null
        declare function_cursor cursor for
          select t.c.value(N'./@fqn', N'[nvarchar](max)') as [function]
          from   @stack.nodes(N'/*/object/workflow/command') as t(c);
      begin
          open function_cursor
          fetch next from function_cursor into @function_name;
          while @@fetch_status = 0
            if @function_name is not null
              begin
                  set @documentation = coalesce(@documentation, N' ', N'')
                                       + [documentation].[get_function](@function_name);
                  fetch next from function_cursor into @function_name;
              end;
          close function_cursor;
          deallocate function_cursor;
      end;
      --
      ------------------------------------------------
      return @documentation;
  end;
go 
