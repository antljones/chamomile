use [chamomile];
go
if schema_id(N'documentation') is null
  execute(N'create schema documentation');
go
if object_id(N'[documentation].[set]', N'P') is not null
  drop procedure [documentation].[set];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------



	--
	---------------------------------------------
	declare @stack xml;
	execute [chamomile].[documentation].[set]
	  @object_fqn      =N'[chamomile].[documentation].[get_job]'
	  , @documentation =N'what is up with that dog?.'
	  , @type = N'html'
	  , @stack         =@stack output
	select @stack;
	--
	---------------------------------------------
	declare @stack xml;
	execute [chamomile].[documentation].[set]
	  @object_fqn =N'[chamomile].[job].[get_change]'
	  , @sequence =368
	  , @delete   =1
	  , @stack    =@stack output
	select @stack;
	--
	---------------------------------------------
	declare @stack xml;
	execute [chamomile].[documentation].[set]
	  @object_fqn =N'[chamomile].[job].[get_change]'
	  , @delete   =2;

	select * from repository_secure.data
	--
	---------------------------------------------
	select *
    from   [repository_secure].[data]
    where  [id] = N'43A823CD-C90E-E411-A934-20689D66B6F7';
	---------------------------------------------
    select [documentation].[get] (N'[chamomile].[job].[get_change]');
	---------------------------------------------
    select [entry]
    from   [repository].[get] (null, N'[chamomile].[job].[get_change]') 
	---------------------------------------------
    select * from   [repository].[get] (null, N'[chamomile].[job].[get_change]')


*/
create procedure [documentation].[set]
  @object_fqn      [nvarchar](max)
  , @documentation [nvarchar](max) = null
  , @type          [sysname] = N'text'
  , @sequence      [int] = 0
  , @delete        [int] = 0
  , @stack         xml([utility].[xsc]) = null output
as
  begin
      declare @subject_fqn           [nvarchar](max)
              , @message             [nvarchar](max)
              , @builder             [xml]
              , @id                  [uniqueidentifier]
              , @entry_builder       [xml]
              , @text_prototype      [xml] = [utility].[get_prototype](N'[chamomile].[documentation].[text].[prototype]')
              , @html_prototype      [xml] = [utility].[get_prototype](N'[chamomile].[documentation].[html].[prototype]')
              , @subject_description [nvarchar](max)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126);
      set @object_fqn=lower(@object_fqn);
      --
      -------------------------------------------
      execute [dbo].[sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](max)');
      set @subject_description = N'Created by ' + @subject_fqn + N'.';
      --
      -------------------------------------------------
      set @entry_builder = (select [entry]
                            from   [repository].[get](null, @object_fqn));
      set @entry_builder = isnull(@entry_builder, [utility].[get_prototype](N'[utility].[xsc].[stack].[prototype]'));
      if @sequence = 0
        set @sequence = @entry_builder.value(N'max (/*/object/documentation/*/@sequence)[1]', N'[int]')
                        + 1;
      --
      -------------------------------------------
      if @delete = 1
        set @entry_builder.modify('delete */object/documentation[text/@sequence=sql:variable("@sequence")]');
      else if @delete = 2
        begin
            set @id = (select [id]
                       from   [repository].[get] (null, @object_fqn));
            --
            -------------------------------------
            if @id is not null
              begin
                  execute [repository].[set]
                    @id       =@id
                    , @delete = 1;
                  --
                  -------------------------------------
                  if ( @entry_builder.value(N'count (/*/object/*)', N'[int]') = 0 )
                    set @id = (select [id]
                               from   [repository].[get] (null, @object_fqn));
                  execute [repository].[set]
                    @id       =@id
                    , @delete = 1;
              end;
        end;
      --
      -------------------------------------------
      else
        begin
            if @documentation is null
              begin
                  begin
                      set @message= N'@documentation cannot be null unless @delete in {1|2}';
                      raiserror (100068,1,1,@message,@subject_fqn);
                      return 100068;
                  end;
              end;
            --
            -------------------------------------------------
            begin
                set @message=null;
                with [invalid_data_finder]
                     as (select [value]
                                , [prototype]
                         from   ( values (@entry_builder
                                , N'[utility].[xsc].[stack].[prototype]'),
                                         (cast(@text_prototype as [nvarchar](max))
                                , N'[chamomile].[documentation].[text].[prototype]') ) as [invalid_data] ([value], [prototype]))
                select @message = coalesce(@message, N'', N'') + [prototype]
                                  + N', '
                from   [invalid_data_finder]
                where  [value] is null;
                if @message is not null
                  if @message is not null
                    begin
                        set @message=left(@message, len(@message) - 1);
                        raiserror (100066,1,1,@message,@subject_fqn);
                        return 100066;
                    end;
            end;
            --
            -------------------------------------------
            if @entry_builder.exist(N'*/object/documentation[*/@sequence=sql:variable("@sequence")]') = 1
              set @entry_builder.modify('delete */object/documentation[*/@sequence=sql:variable("@sequence")]');
            --
            -------------------------------------------
            if @type = N'text'
              begin
                  set @text_prototype.modify(N'insert text {sql:variable("@documentation")} as last into (/*/text)[1]');
                  set @text_prototype.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
                  set @text_prototype.modify(N'replace value of (/*/*/@sequence)[1] with sql:variable("@sequence")');
                  set @entry_builder.modify(N'insert sql:variable("@text_prototype") as last into (/*/object)[1]');
              end;
            --
            -------------------------------------------
            else if @type = N'html'
              begin
                  set @html_prototype.modify(N'insert text {sql:variable("@documentation")} as last into (/*/html)[1]');
                  set @html_prototype.modify(N'replace value of (/*/@fqn)[1] with sql:variable("@object_fqn")');
                  set @html_prototype.modify(N'replace value of (/*/*/@sequence)[1] with sql:variable("@sequence")');
                  set @entry_builder.modify(N'insert sql:variable("@html_prototype") as last into (/*/object)[1]');
              end;
            --
            -------------------------------------------
            execute [repository].[set]
              @stack=@entry_builder output;
            set @stack = @entry_builder;
        end;
  end
go 
