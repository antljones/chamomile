/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		Get the primary key column and type for all tables in a database.



	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------

*/

select [schemas].[name]   as [schema]
       , [tables].[name]  as [table]
       , [columns].[name] as [column]
       , [indexes].[name] as [index]
       , [types].[name]   as [type]
  from sys.indexes as [indexes]
       inner join [sys].[index_columns] as [index_columns]
               on [indexes].[object_id] = [index_columns].[object_id]
                  and [indexes].index_id = [index_columns].index_id
       join [sys].[tables] as [tables]
         on [tables].[object_id] = [index_columns].[object_id]
       join [sys].[columns] as [columns]
         on [columns].[object_id] = [tables].[object_id]
            and [columns].[column_id] = [index_columns].[column_id]
       join [sys].[schemas] as [schemas]
         on [schemas].[schema_id] = [tables].[schema_id]
       join [sys].[types] as [types]
         on [types].[user_type_id] = [columns].[user_type_id]
 where [indexes].[is_primary_key] = 1;

go 

