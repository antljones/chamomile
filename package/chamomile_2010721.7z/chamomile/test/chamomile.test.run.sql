use [chamomile];

go

if schema_id(N'test') is null
  execute (N'create schema test');

go

if object_id(N'[test].[run]', N'P') is not null
  drop procedure [test].[run];

go


/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'test'
			, @object [sysname] = N'run';

	select [schemas].[name]                as [schema]
		   , [procedures].[name]           as [procedure]
		   , [extended_properties].[name]  as [property]
		   , [extended_properties].[value] as [value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[procedures] as [procedures]
			 on [procedures].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [procedures].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [procedures].[name] = @object; 
*/
create procedure [test].[run]
  @stack xml([utility].[xsc]) = null output
as
  begin
      set nocount on;

      declare @test_tree             [xml]
              , @application_message [xml]
              , @sql                 [nvarchar](max)
              , @parameters          [nvarchar](max)
              , @procedure           [sysname]
              , @count               [int]
              , @error_stack         [xml]
              , @builder             [xml]
              , @test_stack_builder  [xml]
              , @string              [nvarchar](max)
              , @schema_filter       [sysname]
              , @procedure_filter    [sysname]
              , @subject_fqn         [nvarchar](1000)
              , @object_fqn          [nvarchar](1000)
              , @object              [sysname]
              , @test_stack          [xml];
      declare @test_suite_prototype    [nvarchar](1000)= N'[chamomile].[test_suite].[stack].[prototype]'
              , @utility_xsc_prototype [nvarchar](1000)= N'[utility].[xsc].[stack].[prototype]';
      declare @test_suite                 [xml] = (select [data]
                 from   [repository].[get] (null, @test_suite_prototype))
              , @stack_builder            [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get](null, @utility_xsc_prototype))
              , @stack_result_description [nvarchar](max) = N'Individual results are contained within the tests. No aggregate result is expected for this stack.'
              , @schema_filter_default    [sysname] = [utility].[get_meta_data](N'[chamomile].[test].[default_suffix]')
              , @test_suite_description   [nvarchar](max) = N'an aggregation of all test stacks executed within this method, along with counts of all tests and results.'
              , @timestamp                [sysname] = convert([sysname], current_timestamp, 126);

      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;

      set @subject_fqn = @builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      --
      -------------------------------------------
      set @test_suite.modify(N'replace value of (/*/@name)[1] with sql:variable("@subject_fqn")');
      set @test_suite.modify(N'replace value of (/*/description/text())[1] with sql:variable("@test_suite_description")');
      set @test_suite.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      --
      -------------------------------------------
      set @stack_builder.modify(N'replace value of (/*/subject/@name)[1] with sql:variable("@subject_fqn")');
      set @stack_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      set @stack_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@stack_result_description")');
      --
      ------------------------------------------------------------------------------------------------
      set @builder = @stack;

      declare test_list cursor for
        select t.c.value(N'data (./@name)', N'[nvarchar](1000)')
        from   @builder.nodes(N'(/*/object/*/command)') as t(c);

      begin
          open test_list;

          fetch next from test_list into @procedure;

          while @@fetch_status = 0
            begin
                set @sql = N'execute ' + @procedure
                           + N' @stack=@test_stack output;';
                set @parameters = N'@test_stack [xml] output';

                begin try
                    execute sp_executesql
                      @sql          =@sql
                      , @parameters =@parameters
                      , @test_stack =@test_stack_builder output;
                end try

                begin catch
                    set @application_message=N'<application_message>
							<sql>' + @sql + N'</sql>
							<parameters>'
                                             + @parameters + N'</parameters>	
						</application_message>';

                    execute [utility].[handle_error]
                      @stack                 = @error_stack output
                      , @procedure_id        =@@procid
                      , @application_message =@application_message;

                    if @test_stack_builder is null
                      set @test_stack_builder = @error_stack
                    else
                      set @test_stack_builder.modify(N'insert sql:variable("@error_stack") as last into (/*/result)[1]');
                end catch;

                set @test_stack_builder = @test_stack_builder.query(N'(/*/object/*)[1]');
                set @test_suite.modify(N'insert sql:variable("@test_stack_builder") as last into (/*)[1]');
                set @test_stack_builder = null;

                fetch next from test_list into @procedure;
            end

          close test_list;

          deallocate test_list;

          --
          -------------------------------------------
          set @stack_builder.modify(N'insert sql:variable("@test_suite") as last into (/*/object)[1]');
          --
          -- build totals
          -------------------------------------------
          set @count = @stack_builder.value(N'count (/*/object/test_suite/test_stack)', N'[int]');
          set @stack_builder.modify(N'replace value of (/*/object/test_suite/@stack_count)[1] with sql:variable("@count")');
          set @count = cast(@stack_builder.value(N'sum (/*/object/test_suite/test_stack/@test_count)', N'[float]') as [int]);
          set @stack_builder.modify(N'replace value of (/*/object/test_suite/@test_count)[1] with sql:variable("@count")');
          set @count = cast(@stack_builder.value(N'sum (/*/object/test_suite/test_stack/@pass_count)', N'[float]') as [int]);
          set @stack_builder.modify(N'replace value of (/*/object/test_suite/@pass_count)[1] with sql:variable("@count")');
          set @count = cast(@stack_builder.value(N'sum (/*/object/test_suite/test_stack/@error_count)', N'[float]') as [int]);
          set @stack_builder.modify(N'replace value of (/*/object/test_suite/@error_count)[1] with sql:variable("@count")');
          --
          -------------------------------------------
          set @stack = @stack_builder;
      end
  end

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'Executes the list of tests passed in and totals the results.'
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'')'
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<ol>
		<li>get "result" from meta data</li>
	</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140706', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140706'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'revision_20140706'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'package_dpr_2012_313_0002_compliance_cms_audit_program', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_dpr_2012_313_0002_compliance_cms_audit_program'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'package_dpr_2012_313_0002_compliance_cms_audit_program'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'test', N'procedure', N'run', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml([utility].[xsc])= N''<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-30T18:37:43.61">
    	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
    	  <object >
			<workflow name="[computer_physical_netbios].[machine].[instance].[chamoile].[test].[run]" >
    				<command name="[repository_test].[get]" timestamp="2014-06-30T18:37:43.61"/>
					<command name="[repository_test].[set]" timestamp="2014-06-30T18:37:43.61"/>
    		</workflow>
    	  </object>
    	</chamomile:stack>'';
execute [test].[run] @stack=@stack output;
select @stack as N''[test_suite]''; '
  , @level0type=N'SCHEMA'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'

if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'schema', N'test', N'procedure', N'run', N'parameter', N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'schema'
    , @level0name=N'test'
    , @level1type=N'procedure'
    , @level1name=N'run'
    , @level2type=N'parameter'
    , @level2name=N'@stack';

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - A list of tests to run.'
  , @level0type=N'schema'
  , @level0name=N'test'
  , @level1type=N'procedure'
  , @level1name=N'run'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; 
