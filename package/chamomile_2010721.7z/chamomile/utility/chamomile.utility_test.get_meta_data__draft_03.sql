declare @stack xml([utility].[xsc]) = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-15T19:32:55.107">
  <subject name="[utility].[xsc].[stack]">
    <description>Description of subject</description>
  </subject>
  <object>
    <meta_data name="[chamomile].[documentation].[job].[get_change]">
      <description>changed documentation using both name and job id</description>
      <value>here is where the documentation goes</value>
      <constraint />
    </meta_data>
  </object>
  <result>
    <description>Description of result</description>
  </result>
</chamomile:stack>'
        , @id  [uniqueidentifier] = N'64058A26-0DC5-497B-B512-4C4EE1F071F0';
execute [repository].[set]
  @id      =@id
  , @name  =N'[chamomile].[documentation].[job].[get_change]'
  , @stack =@stack output;
select *
from   [repository].[get] (@id, null);
/*
insert into [repository_secure].[data]
          ([id],[entry])
values      (@id,@stack); 
*/
