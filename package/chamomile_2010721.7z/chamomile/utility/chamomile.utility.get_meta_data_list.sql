use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[get_meta_data_list]', N'TF') is not null
  drop function [utility].[get_meta_data_list];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	select * from [utility].[get_meta_data_list](N'[chamomile].[boolean]');
*/
create function [utility].[get_meta_data_list] (
  @name [nvarchar](1000))
returns @data table (
  [id]            [uniqueidentifier] null
  , [entry]       [xml] null
  , [fqn]         [nvarchar](max)
  , [description] [nvarchar](max) null
  , [data]        [nvarchar](max) null )
as
  begin
      insert into @data
                  ([id],[entry],[fqn],[description],[data])
        select [id]
               , [entry]
               , [fqn]
               , [description]
               , [data].value(N'(/*/value/text())[1]', N'[nvarchar](max)')
        from   [repository].[get_list] (null, @name);
      return;
  end
go 
