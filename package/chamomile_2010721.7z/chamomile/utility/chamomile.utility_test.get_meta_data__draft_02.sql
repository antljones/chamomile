/*

    execute [utility].[set_meta_data]
      @name         =@name
      , @value      =@value
      , @description=@description
      , @stack      =@stack output;
	  
	declare @stack         xml([utility].[xsc])
            , @name        [nvarchar](1000) =N'[chamomile].[documentation].[html].[small_value]'
            , @value       [nvarchar](max) = N'small value'
            , @description [nvarchar](max) = N'description of small value';
    select [utility].[get_meta_data](@name);
    select *
    from   [utility].[get_meta_data_list] (@name); 
    go

	declare @name [nvarchar](1000) =N'[chamomile].[documentation].[html].[notebooks_of_lazarus_long]';
	select [utility].[get_meta_data](@name);
	select *
	from   [utility].[get_meta_data_list] (@name); 
 

*/
declare @stack         xml([utility].[xsc])
        , @name        [nvarchar](1000) =N'[chamomile].[documentation].[html].[notebooks_of_lazarus_long]'
        , @description [nvarchar](max) = null
        , @constraint  [nvarchar](max) = null
        , @value       [nvarchar](max) = N'<!DOCTYPE html>
<html>
   <head>
	  <link rel="stylesheet" type="text/css" href="..\..\source\common.css" target="blank">
   </head>
   <body>
      <h1 align="center">Notebooks of Lazarus Long</h1>
	  
      <center>
         from
         <p><a href="http://en.wikipedia.org/wiki/Time_Enough_for_Love"><u>Time Enough for Love</u></a><br>
            NY: G.P. Putnam''s Sons (A Berkley Medallion Book), 1973
         <p>By: Robert Heinlein
         <p><a href="http://www.angelfire.com/or/sociologyshop/fairuse.html">Fair Use</a>
         <p>The following "aphorisms" come from the "Notebooks of Lazarus Long" in Robert Heinlein''s 1973 novel, <u>Time Enough for Love</u>.  These notebooks are called "Intermission" (pp. 240-251) and "Second Intermission" (pp. 346-353) and are full of pithy insights and opinions of Lazarus Long, the central character in this classic science fiction novel.  Some of the aphorisms can be readily agreed with...while others might provoke disagreement.  Yet, all of them generate thought about our own time (my own personal standard concerning "science fiction").    They are presented here in that spirit...thought-provoking observations from an author, Heinlein, who has never been bereft of such insights in any book he has written...and who never forgot <i>who</i> he was writing for...and <i>when</i>.
         <p><a href="#inter">Intermission</a><br>
            <a href="#inter2">Second Intermission</a> 
			
         <p><a name="inter">Intermission</a>
		 <hr>
         <p>Excerpts from the notebooks of Lazarus Long
      </center>
            <hr>
      <p>Always store beer in a dark place.
      <p>By the data to date, there is only one animal in the Galaxy dangerous to man--man himself. So he
         must supply his own indispensable competition. He has no enemy to help him.
      <p>Men are more sentimental than women. It blurs their thinking.
      <p>Certainly the game is rigged. Don�t let that stop you; if you don�t bet, you can�t win.
      <p>Any priest or shaman must be presumed guilty until proved innocent.
      <p>Always listen to experts. They�ll tell you what can�t be done and why. Then do it!
      <p>Get a shot off fast. This upsets him long enough to let you make your second shot perfect.
      <p>There is no conclusive evidence of life after death. But there is no evidence of any sort against
         it.  Soon enough you will know.  So why fret about it?
      <p>If it can�t be expressed in figures, it is not science; it is opinion.
      <p>It has long been known that one horse can run faster than another--but which one? Differences are 	crucial.
      <p>A fake fortune teller can be tolerated. But an authentic soothsayer should be shot on sight. Cassandra 	did not get half the kicking around she deserved .
      <p>Delusions are often functional. A mother�s opinions about her children�s beauty, intelligence, goodness, 	et cetera ad nauseam, keep her from drowning them at birth.
      <p>Most �scientists� are bottle washers and button sorters.
      <p>A �pacifist male� is a contradiction in terms. Most self-described �pacifists� are not pacific; they simply 	assume false colors. When the wind changes, they hoist the Jolly Roger.
      <p>Nursing does not diminish the beauty of a woman�s breasts; it enhances their charm by making them 	look lived in and happy.
      <p>A generation which ignores history has no past�and no future.
      <p>A poet who reads his verse in public may have other nasty habits.
      <p>What a wonderful world it is that has girls in!
      <p>Small change can often be found under seat cushions.
      <p>History does not record anywhere at any time a religion that has any rational basis. Religion is a crutch 	for people not strong enough to stand up to the unknown without help. But, like dandruff, most people do 	have a religion and spend time and money on it and seem to derive considerable pleasure from fiddling with 	it.
      <p>It�s amazing how much �mature wisdom� resembles being too tired.
      <p>If you don�t like yourself, you can�t like other people.
      <p>Your enemy is never a villain in his own eyes. Keep this in mind; it may offer a way to make him your 	friend. If not, you can kill him without hate--and quickly.
      <p>A motion to adjourn is always in order.
      <p>No state has an inherent right to survive through conscript troops and, in the long run, no state ever has. 	Roman matrons used to say to their sons: �Come back with your shield, or on it.� Later on this custom 	declined. So did Rome.
      <p>Of all the strange �crimes that human beings have legislated out of nothing, �blasphemy� is the most 	amazing--with �obscenity� and �indecent exposure� fighting it out for second and third place.
      <p>Cheops� Law: Nothing is ever built on schedule or within budget.
      <p>It is better to copulate than never.
      <p>All societies are based on rules to protect pregnant women and young children. All else is surplus age, 	excrescence, adornment, luxury or folly which can--and must--be dumped in emergency to preserve this 	prime function. As racial survival is the only universal morality, no other basic is possible. Attempts to 	formulate a �perfect society� on any foundation other than �women and children first!� is not only witless, it 	is automatically genocidal.  Nevertheless, starry-eyed idealists (all of them male) have tried endlessly--and 	no doubt will keep on trying.
      <p>All men are created unequal.
      <p>Money is a powerful aphrodisiac. But flowers work almost as well.
      <p>A brute kills for pleasure. A fool kills from hate.
      <p>There is only one way to console a widow. But remember the risk.
      <p>When the need arises--and it does--you must be able too shoot your own dog. Don�t farm it out--that 	doesn�t make it nicer, it makes it worse.
      <p>Everything in excess! To enjoy the flavor of life, take big bites. Moderation is for monks.
      <p>It may be better to be a live jackal than a dead lion, but it is better still to be a live lion. And usually 	easier.
      <p>One man�s theology is another man�s belly laugh.
      <p>Sex should be friendly.  Otherwise stick to mechanical toys; it�s more sanitary.
      <p>Men rarely (if ever) manage to dream up a God superior to themselves. Most Gods have the manners 	and morals of a spoiled child.
      <p>Never appeal to a man�s �better nature.� He may not have one. Invoking his �self�interest� gives you 	more leverage.
      <p>Little girls, like butterflies, need no excuse.
      <p>You can have peace. Or you can have freedom. Don�t ever count on having both at once.
      <p>Avoid making irrevocable decisions while tired or hungry.  N.B.: Circumstances can force your hand. 	So think ahead!
      <p>Place your clothes and weapons where you can find them in the dark.
      <p>An elephant: A mouse built to government specifications.
      <p>Throughout history, poverty is the normal condition of man. Advances which permit this norm to be 	exceeded--here and there, now and then--are the work of an extremely small minority, frequently despised, 	often condemned, and almost always opposed by all right-thinking people. Whenever this tiny minority is 	kept from creating, or (as sometimes happens) is driven out of a society, the people then slip back into 	abject poverty. This is known as �bad luck.�
      <p>In a mature society, �civil servant� is semantically equal to �civil master.�
      <p>When a place gets crowded enough to require ID�s, social collapse is not far away. It is time to go 	elsewhere. The best thing about space travel is that it made it possible to go elsewhere.
      <p>A woman is not property, and husbands who think otherwise are living in a dreamworld.
      <p>The second best thing about space travel is that the distances involved make war very difficult, usually 	impractical, and almost always unnecessary. This is probably a loss for most people, since war is our races 	most popular diversion, one which gives purpose and color to dull and stupid lives. But it is a great boon to 	the intelligent man who fights only when he must--never for sport.
      <p>A zygote is a gamete�s way of producing more gamete�s. This may be the purpose of the universe.
      <p>There are hidden contradictions within the minds of people who �love nature� while deploring the
         �artificialities� with which �Man has spoiled �Nature.�
         The obvious contradiction lies in their choice of words, which imply that Man and his artifacts are not part 			of  �Nature�--but beavers and their damns are. But the contradictions go deeper than this prima-facie 			absurdity. In declaring his love for a beaver damn (erected by beavers for beaver�s purposes) and his hatred 			for dams erected by men (for the purpose of men) the �Naturist� reveals his hatred for his own race--i.e., his 		own self-hatred.
         In the case of �Naturists� such self�hatred is understandable; they are such a sorry lot. But hatred is too strong an emotion to feel toward them; pity and contempt are the most they rate.
         As for me, willy-nilly I am a man, not a beaver, and H. Sapiens is the only race I have or can have. Fortunately for me, I like being part of a race made up of men and women-- it strikes me as a fine arrangement and perfectly �natural.�  Believe it or not, there were �Naturists� who opposed the first flight 	to old Earth�s Moon as being �unnatural� and a �despoiling of nature.�
      <p>No man is an island--� Much as we may feel and act as individuals, our race is a single organism, always growing and branching--which must be pruned regularly to be healthy. This necessity need not be argued; 	anyone with eyes can see that any organism which grows without limit always dies within �its own poisons. 	The only rational question is whether pruning is best done before or after birth. Being an incurable 	sentimentalist I favor the former of these methods--killing makes me queasy, even when it�s a case of �He�s 	dead and I�m alive and that�s the way I wanted it to be.� But this may be a matter of taste. Some shamans 	think that it is better to be killed in a war, or to die in childbirth, or to starve in misery, than never to have 	lived at all. They may be right.  But I don�t have to like it--and I don�t.
      <p>Democracy is based on the assumption that a million men are wiser than one man. How�s that again? I 	missed something.
      <p>Autocracy is based on the assumption that one man is wiser than a million men. Let�s play that over 	again, too. Who decides?
      <p>Any government will work if authority and responsibility are equal and coordinate. This does not insure 	�good� government; it simply insures that it will work. But such governments are rare--most people want to 	run things but want no part of the blame. This used to be called the �backseat-driver syndrome.�
      <p>What are the facts? Again and again and again-what are the facts? Shun wishful thinking, ignore divine 	revelation, forget what �the stars foretell,� avoid opinion, care not what the neighbors think, never mind the 	unguessable �verdict of history�--what are the facts, and to how many decimal places? You pilot always into 	an unknown future; facts are your single clue. Get the facts!
      <p>God is omnipotent, omniscient, and omnibenevolent-it says so right here on the label. If you have a 	mind capable of believing all three of these divine attributes simultaneously, I have a wonderful bargain for 	you.  No checks, please. Cash and in small bills.
      <p>Courage is the compliment of fear. A man who is fearless cannot be courageous. (He is also a fool.)
      <p>The two highest achievements of the human mind are the twin concepts of �loyalty� and �duty.� 	Whenever these twin concepts fall into disrepute--get out of there fast. You may possibly save yourself, but 	it is too late to save that society. It is doomed.
      <p>People who go broke in a big way never miss any meals. It is the poor jerk who is shy half a slug who 	must tighten his belt.
      <p>The truth of a proposition has nothing to do with it�s credibility. And vice versa.
      <p>Anyone who cannot cope with mathematics is not fully human. At best he is a tolerable sub-human who 	has learned to wear shoes, bathe, and not make messes in the house.
      <p>Moving parts in rubbing contact require lubrication to avoid excessive wear. Honorifics and formal 	politeness provide lubrication where people rub together. Often the very young, the untraveled, the naive, 	the unsophisticated deplore these formalities as �empty,� �meaningless,� or �dishonest,� and scorn to use 	them. No matter how �pure� their motives, they thereby throw sand into machinery that does not work too 	well at best.
      <p>A human being should be able to change a diaper, plan an invasion, butcher a hog, conn a ship, design a 	building, write a sonnet, balance accounts, build a wall, set a bone, comfort the dying, take orders, give 	orders, cooperate, act alone, solve equations, analyze a new problem, pitch manure, program a computer, 	cook a tasty meal, fight efficiently, die gallantly.  Specialization is for insects!
      <p>The more you love, the more you can love--and the more intensely you love. Nor is there any limit on 	how many you can love. If a person had Time Enough, he could Love all of the majority who are decent and 	just.
      <p>Masturbation is cheap, clean, convenient, and free of any possibility of wrong-doing--and you don�t 	have to go home in the cold. But it�s lonely.
      <p>Beware of altrusim. It is based on self-deception, the root of all evil.
      <p>If tempted by something that feels �altruistic� examine your motives and root out that self-deception. 	Then, if you still want to do it, wallow in it!
      <p>The most preposterous notion that H. Sapiens has ever dreamed up is that the Lord God of Creation, 	Shaper and Ruler of all the Universes, wants the saccharine adoration of His creatures, can be swayed by 	their prayers, and becomes petulant if He does not receive this flattery. Yet this absurd fantasy, without a 	shred of evidence to bolster it, pays all the expenses of the oldest, largest, and least productive industry in all 	of history.
      <p>The second most preposterous notion is that copulation is inherently sinful.
      <p>Writing is not necessarily something to be ashamed of--but do it in private and wash your hands 	afterwards.
      <p>$100 placed at 7% interest compounded quarterly for 200 years will increase to more �than 	$100,000,000--by which time it will be worth nothing.
      <p>Dear, don�t bore him with trivia or burden him with your past mistakes. The happiest way to deal with a man is 	never to tell him anything he does not need to know.
      <p>Darling, a true lady takes off her dignity with her clothes and does her whorish best. At other times you can be as 	modest and dignified as your persona requires.
      <p>Everybody lies about sex.
      <p>If men were the automatons that behaviorists claim they are, the behaviorist psychologists could not have invented 	the amazing nonsense called �behaviorist psychology.� So they are wrong from scratch--as clever and as wrong as 	phlogiston chemists.
      <p>The shamans are forever yacking about their snake-oil �miracles.� I prefer the real McCoy--a pregnant woman.
      <p>If the universe has any purpose more important than topping the woman you love and making a baby with her hearty 	help, I�ve never heard of it.
      <p>Thou shalt remember the 11th commandment and keep it Wholly.
      <p>A touchstone to determine the actual worth of an �intellectual�--find out how he feels about astrology.
      <p>Taxes are not levied for the benefit of the taxed.
      <p>There is no such thing as ��Social Gambling. Either you are there to cut the other blokes heart out and eat it--or 	you�re a sucker. If you don�t like this choice--don�t gamble.
      <p>When a ship lifts, all bills are paid. No regrets.
      <p>The first time I was a drill� instructor I was too inexperienced for the job--the things I taught those lads must have 	got some of them killed. War is too serious a matter to be taught by the inexperienced.
      <p>A competent and self confident person is incapable of jealousy in anything. Jealousy is invariably a symptom of 	neurotic insecurity.
      <p>Money is the sincerest of all flattery. Women love to be flattered. So do men.
      <p>You live and learn or you don�t live long.
      <p>Whenever women have insisted on absolute equality with men, they have invariably wound up on the dirty end of the 	stick. What they are and what they can do makes them superior to men, and their proper tactic is to demand special 	privileges, all the traffic will bear. They should never settle merely for equality. For women, �equality� is a disaster.
      <p>Peace is an extension of war by political means. Plenty of elbowroom is pleasanter--and much safer.
      <p>One man�s �magic� is another man�s engineering. �Supernatural� is a null word.
      <p>The phrase �we (I) (you) simply must--�designates something that need not be done. �That goes without saying� is 	a red warning. �Of course� means you had best check it yourself. These small--change cliches and others like them, when 	read correctly, are reliable channel markers.
      <p>Do not handicap your children by making their lives easy.
      <p>Rub her feet.
      <p>If you happen to be one of the fretful who can do creative work, never force an idea; you�ll abort it if you do. Be 	patient and you�ll give birth to it when the time is ripe. Learn to wait.
      <p>Never crowd youngsters about their private affairs--sex especially. When they are growing up they are nerve ends all 	over, and resent (quite properly) any invasions of their privacy. Oh sure, they�ll make mistakes--but that�s their 	business, not yours. (You made your own mistakes, did you not?)
      <p>Never underestimate the power of human stupidity!

	  
         <hr>
      <center>
         <p><a name="inter2">Second Intermission</a>
         <p>More from the Notebooks of Lazarus Long
      </center>
	  <hr>
      <p>Always tell her she is beautiful, especially if she is not.
      <p>If you are part of a society that votes, then do so. There may be no candidates and no measures you want to vote 	for...but there are certain to be ones you want to vote against. In case of doubt, vote against. By this rule you 	will rarely go wrong.  If this is too blind for your taste, consult some well-meaning fool (there is always one 	around) and ask his advice. Then vote the other way. This enables you to be a good citizen (if such is your 	wish) without spending the enormous amount of time on it that truly intelligent exercise of franchise requires.
      <p>Sovereign ingredient for a happy marriage: Pay cash or do without. Interest charges not only eat up a household 	budget; awareness of debt eats up domestic felicity.
      <p>Those who refuse to support and defend a state have no claim to protection by that state. Killing an anarchist or a  pacifist should not be defined as �murder� in a legalistic sense. The offense against the state, if any, should be 	�Using deadly weapons inside city limits,� or �Creating a traffic hazard,� or �Endangering bystanders,� or other 	misdemeanor.  However, the state may reasonably place a closed season on these exotic asocial animals 	whenever they are in danger of becoming extinct. An authentic buck pacifist has rarely been seen off Earth, and it 	is doubtful that any have survived the trouble there...regrettable, as they had the biggest mouths and the 	smallest 	brains of any of the primates.  The small-mouthed variety of anarchist has spread through the Galaxy at the very wave front of the Diaspora; there is no need to protect them. But they often shoot back.
      <p>Another ingredient for a happy marriage: Budget the luxuries first!
      <p>And still another-- See to it that she has her own desk--then keep your hands off it!
      <p>And another--In a family argument, if it turns out you are right--apologize at once!
      <p>�God split himself into a myriad parts that he might have friends.� This may not be true, but it sounds good--and is 	no sillier than any other theology.	
      <p>To stay young requires unceasing cultivation of the ability to unlearn old falsehoods.
      <p>Does history record any case in which the majority was right?
      <p>When the fox gnaws--smile!
      <p>A �critic� is a man who creates nothing and thereby feels qualified to judge the work of creative men. There is logic in this; he is unbiased�he hates all creative, people equally.
      <p>Money is truthful. If a man speaks of his honor, make him pay cash.
      <p>Never frighten a little man. He�ll kill you.
      <p>Only a sadistic scoundrel--or a fool--tells the bald truth on social occasions.
      <p>This sad little lizard told me that he was a brontosaurus on his mother�s side. I did not laugh; people who boast of ancestry often have little else to sustain them. Humoring them costs nothing and adds to happiness in a world in which happiness is always in short supply.
      <p>In handling a stinging insect, move very slowly.
      <p>To be �matter of fact� about the world is to blunder into fantasy--and dull fantasy at that, as the real world is strange and wonderful.
      <p>The difference between science and the fuzzy subjects is that science requires reasoning, while those other subjects merely require scholarship.  Copulation is spiritual in essence--or it is merely friendly exercise. On second thought, strike out �merely.� Copulation is not �merely�--even when it is just a happy pastime for two strangers. But copulation at its spiritual best is so much more than physical coupling that it is different in kind as well as in degree.  The saddest feature of homosexuality is not that it is �wrong� or �sinful� or even that it can�t lead to progeny--but that it is more difficult to reach through it this spiritual union. Not impossible--but the cards are stacked against it.  But most sorrowfully--many people never achieve spiritual sharing even with the help of male-female advantage; they are condemned to wander through life alone.
      <p>Touch is the most fundamental sense. A baby experiences it, all over, before he is born and long before he learns to use sight, hearing, or taste, and no human ever ceases to need it. Keep your children short on pocket money--but long on hugs.
      <p>Secrecy is the beginning of tyranny.
      <p>The greatest productive force is human selfishness.
      <p>Be wary of strong drink. It can make you shoot at tax collectors--and miss.
      <p>The profession of shaman has many advantages. It offers high status with a safe livelihood free of work in the dreary, sweaty sense. In most societies it offers legal privileges and immunities not granted to other men. But it is hard to see how a man who has been given a mandate from on High to spread tidings of joy to all mankind can be seriously interested  in taking up a collection to pay his salary; it causes one to suspect that the shaman is on the moral level of any  other man.  But it�s lovely work if you can stomach it.
      <p>A whore should be judged by the same criteria as other, professionals offering services for pay--such as dentists, lawyers, hairdressers, physicians, plumbers, etc. Is she professionally competent? Does she give good measure?  Is she honest with her clients?  It is possible that the percentage of honest and competent whores is higher than that of plumbers and much higher than that of lawyers. And enormously higher than that of professors.
      <p>Minimize your therbligs until it becomes automatic; this doubles your effective lifetime--and thereby gives time to enjoy butterflies and kittens and rainbows.
      <p>Have you noticed how much they look like orchids? Lovely!
      <p>Expertise in one field does not carry over into other fields.  But experts often think so. The narrower their field of knowledge the more likely they are to think so.
      <p>Never try to out stubborn a cat
      <p>Tilting at windmills hurts you more than the windmills.
      <p>Yield to temptation, it may not pass your way again
      <p>Waking a person unnecessarily should not be considered a capital crime. For a first offense, that is.
      <p>�Go to hell!� or other insult direct is all the answer a snoopy question rates.
      <p>The correct way to punctuate a sentence that starts: �Of course It is none of my business but--� is to place a period after the word �but.� Don�t use excessive force in supplying such moron with a period. Cutting his throat is only a momentary pleasure and is bound to get you talked about.
      <p>A man does not insist on physical beauty in a woman who builds up his morale. After a while he realizes that she is beautiful--he just hadn�t noticed it at first.
      <p>A skunk is better company than a person who prides himself on being �frank.�
      <p>�All�s fair in love and war�--what a contemptible lie!
      <p>Beware of the �Black Swan� fallacy. Deductive logic is tautological; there is no way to get a new truth out of it, and it manipulates false statements as readily as true ones.  If you fail to remember this, it can trip you--with perfect logic. The designers of the earliest computers called this the �Gigo Law,� i.e., �Garbage in, garbage out.� 
      <p>Inductive logic is much more difficult --but can produce new truths.
      <p>A �practical joker� deserves applause for his wit according  to its quality. Bastinado.  For exception wit one might grant keelhauling.  But staking him out on an anthill  should be reserved for the very wittiest.
      <p>Natural laws have no pity.
      <p>On the planet Tranquille around KM849 (G-O) lives a little animal known as a �knafn.� It is herbivorous and has no natural enemies and is easily approached and may be petted	--sort of a six-legged puppy with scales. Stroking it is very pleasant; it wiggles its pleasure and broadcasts euphoria in some band that humans can detect. It�s worth the trip.  Someday some bright boy will figure out how to record this broadcast, then some smart boy will see commercial angles--and not long after that it will be regulated and taxed. In the meantime I have faked that name and catalog  number; it is several thousand light-years off in another direction.  Selfish of me--
      <p>Freedom begins when you tell Mrs. Grundy to go fly a kite.
      <p>Take care of the cojones and the frijoles will take care of themselves. Try to have getaway money--but don�t be fanatic about it.
      <p>If  �everybody knows� such-and-such, then it ain�t so, by at least ten thousand to one.
      <p>Political tags--such as royalist, communist, democrat, populist, fascist, liberal, conservative, and. so forth--are never basic criteria. The human race divides politically into those who want people to be controlled and those who have no such desire.  The former are idealists acting from highest motives for the greatest good of the greatest number.  The latter are surly curmudgeons, suspicious and lacking in altruism.  But they are more comfortable neighbors than the other sort.
      <p>All cats are not gray after midnight. Endless variety--
      <p>Sin lies only in hurting other people unnecessarily. All other sins are invented nonsense. (Hurting yourself is not sinful--just stupid.)
      <p>Being generous is inborn; being altruistic is a learned perversity.  No resemblance--
      <p>It is impossible for a man to love his wife wholeheartedly without loving all women somewhat. I suppose that the converse must be true of women.
      <p>You can go wrong by being too skeptical as readily as by being too trusting.
      <p>Formal courtesy between husband and wife is even more important than it is between strangers.
      <p>Anything free is worth what you pay for it.
      <p>Don�t store garlic near other victuals.
      <p>Climate is what we expect, weather is what we get.
      <p>Pessimist by policy, optimist by temperament--it is possible to be both.  How?  By never taking an unnecessary chance and by minimizing risks you can�t avoid.  This permits you to play the game happily, untroubled by the certainty of the outcome.
      <p>Do not confuse �duty� with what other people expect of you; they are utterly different. Duty is a debt you owe yourself to fulfill obligations you have assumed voluntarily.  Paying that debt can entail anytbing from years of patient work to instant willingness to die. Difficult it may be, but the reward is self-respect.  But there is no reward at all for doing what other people expect of you, and to do so is not merely difficult, but impossible. It is easier to deal with a footpad than it is with the leech who wants �just a few minutes of your time, please--this won�t take long.� Time is your total capital, and the minutes of your life are painfully few. If you allow yourself to fall into the vice of agreeing to such requests, they quickly snowball to the point where these parasites will use up 100 percent of your time--and squawk for more!  So learn to say No--and to be rude about it when necessary. Otherwise you will not have time to carry out your duty, or to do your own work, and certainly no time for love and happiness. The termites will nibble away your life and leave none of it for you.  (This rule does not mean that you must not do a favor for a friend, or even a stranger. But let the choice be yours. Don�t do it because it is �expected� of you.)
      <p>�I came, I saw, she conquered.� (The original Latin seems to have been garbled.)
      <p>A committee is a life form with six or more legs and no brain.
      <p>Animals can be driven crazy by placing too many in too small a pen. Homo sapiens is the only animal that voluntarily does this to himself.
      <p>
         Don�t try to have the last word. You might get it.
         <br>
   </body>
</html>
';
execute [utility].[set_meta_data]
  @name         =@name
  , @value      =@value
  , @description=@description
  , @stack      =@stack output; 
