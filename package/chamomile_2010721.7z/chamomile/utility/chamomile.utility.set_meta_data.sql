use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[set_meta_data]', N'P') is not null
  drop procedure [utility].[set_meta_data];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	declare @stack xml([utility].[xsc]);

	execute [utility].[set_meta_data]
	  @name         =N'[chamomile].[return_code].[code_65]'
	  , @value      =N'meta data not found.'
	  , @description=N'meta data not found for "[chamomile].[return_code].[code_65]".'
	  , @stack      =@stack output;

	select @stack; 


	select [utility].[get_meta_data](N'[chamomile].[return_code].[code_65]');

	select *
	from   [repository].[get_list] (null, N'[chamomile].[return_code].[code_65]'); 


*/
create procedure [utility].[set_meta_data]
  @name          [nvarchar](1000)
  , @value       [nvarchar](max) = null
  , @constraint  [nvarchar](max) = null
  , @description [nvarchar](max)
  , @stack       xml([utility].[xsc]) = null output
as
  begin
      declare @subject_fqn           [nvarchar](1000)
              , @message             [nvarchar](max)
              , @return_code         [int]
              , @builder             [xml]
              , @entry_builder       [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get] (null, N'[utility].[xsc].[stack].[prototype]'))
              , @meta_data_stack     [xml] = (select [data]
                 from   [repository].[get] (null, N'[chamomile].[meta_data].[stack].[prototype]'))
              , @object_type         [sysname] = N'meta_data'
              , @subject_description [nvarchar](max)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126);
      select @value = coalesce(@value, N'')
             , @description = coalesce(@description, N'');
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @subject_description = N'Created by ' + @subject_fqn + N'.';
      --
      -------------------------------------------
      if @constraint is not null
        if patindex (N'|%' + @value + N'|%', isnull(@constraint, N'|%' + @value + N'|%')) < 1
          begin
              set @message = N'error: "[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]" - in: '
                             + @subject_fqn;
              set @return_code =cast ([utility].[get_meta_data](N'[chamomile].[return_code].[meta_data_value_does_not_conform_to_constraint]') as [int]);
              raiserror(@message,1,1);
              return @return_code;
          end;
      --
      -------------------------------------------
      if @constraint is not null
        set @meta_data_stack.modify(N'replace value of (/*/constraint/text())[1] with sql:variable("@constraint")');
      else
        set @meta_data_stack.modify('delete (/*/constraint/text())[1]');
      set @meta_data_stack.modify(N'replace value of (/*/@name)[1] with sql:variable("@name")');
      set @meta_data_stack.modify(N'replace value of (/*/value/text())[1] with sql:variable("@value")');
      set @meta_data_stack.modify(N'replace value of (/*/*/text())[1] with sql:variable("@description")');
      --
      -------------------------------------------
      set @entry_builder.modify(N'insert sql:variable("@meta_data_stack") as last into (/*/object)[1]');
      set @name=lower(@name);
      execute [repository].[set]
        @name   =@name
        , @stack=@entry_builder output;
      set @stack = @entry_builder;
  end
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.92.00', N'SCHEMA', N'utility', N'procedure', N'set_meta_data', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.92.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'procedure'
    , @level1name=N'set_meta_data';
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.92.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'procedure'
  , @level1name=N'set_meta_data';
go 
