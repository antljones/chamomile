/*

	declare @stack         xml
            , @error_stack [xml];
    execute [utility_test].[get_meta_data]
      @stack        =@stack output
      , @error_stack=@error_stack output;
    select @stack         as N'@stack from [utility_test].[get_meta_data]'
           , @error_stack as N'@error_stack'; 
    




	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		A demonstration of the technique required to call a destructive method,
			one that inserts, updates, deletes, etc., from a unbreakable_code, with absolute
			certainly that the production state will be returned to it's state prior
			to the unbreakable_code.

			This allows unit unbreakable_codes to be run in production, allowing the goal of
			"unbreakable code" to be reached.

	--
	--	notes
	---------------------------------------------
		this unbreakable_code is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------
		Unit testing - http://en.wikipedia.org/wiki/Unit_unbreakable_codeing
		test-driven development - http://en.wikipedia.org/wiki/unbreakable_code-driven_development
		White-box testing - http://en.wikipedia.org/wiki/White-box_unbreakable_codeing
		Black-box testing - http://en.wikipedia.org/wiki/Black-box_unbreakable_codein
	--
	-- to view documentation
	---------------------------------------------
	select [sch].[name]
		   , [prc].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
	join   [sys].[procedures] as [prc]
	  on [prc].[object_id] = [prop].[major_id]
	join   [sys].[schemas] as [sch]
	  on [prc].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = N'unbreakable_code'
		   and [prc].[name] = N'set_flower'; 
*/
--
-- code block begin
-------------------------------------------------
use [chamomile];
go
if schema_id(N'utility_test') is null
  execute (N'create schema utility_test');
go
if object_id(N'[utility_test].[get_meta_data]', N'P') is not null
  drop procedure [utility_test].[get_meta_data];
go
-------------------------------------------------
-- code block end
--
create procedure [utility_test].[get_meta_data]
  @stack         [xml] = null output
  , @error_stack xml ([utility].[xsc]) output
as
  begin
      set nocount on;
      set transaction isolation level serializable;
      --
      -------------------------------------------
      declare @application_message               [xml]
              , @test_name                       [sysname]
              , @test_description                [nvarchar](max)
              , @expected_result                 [nvarchar](max)
              , @sequence                        [int]
              , @count                           [int]
              , @error                           [xml]
              , @server_information              [xml]
              , @sql                             [nvarchar](max)
              , @parameters                      [nvarchar](max)
              , @test_builder                    [xml]
              , @return_code                     [int] = 0
              , @test_builder_result_description [nvarchar](max)
              , @id                              [uniqueidentifier]
              , @actual                          [sysname]
              , @major_version                   [int]
              , @name                            [nvarchar](1000)
              , @subject_fqn                     [nvarchar](1000)
              , @object_fqn                      [nvarchar](1000)
              , @description                     [nvarchar](max)
              , @message                         [nvarchar](max)
              , @expected                        [sysname]
              , @builder                         [xml]
              , @builder_02                      [xml];
      --
      -- meta data and prototype names, used both to get meta data and messages and in error messages (raiserror)
      -------------------------------------------
      declare @test_type_meta_data              [nvarchar](1000)= N'[chamomile].[test].[default].[test]'
              , @pass_meta_data                 [nvarchar](1000)= N'[chamomile].[result].[default].[pass]'
              , @fail_meta_data                 [nvarchar](1000)= N'[chamomile].[result].[default].[fail]'
              , @existing_transaction_meta_data [nvarchar](1000)= N'[chamomile].[return_code].[existing_transaction]'
              , @meta_data_not_found            [nvarchar](1000)= N'[chamomile].[return_code].[meta_data_not_found]'
              --
              -----------------------------------
              , @test_stack_prototype           [nvarchar](1000)= N'[chamomile].[test_stack].[stack].[prototype]'
              , @data_stack_prototype           [nvarchar](1000)= N'[chamomile].[data].[stack].[prototype]'
              , @utility_xsc_prototype          [nvarchar](1000)= N'[utility].[xsc].[stack].[prototype]'
              , @test_prototype                 [nvarchar](1000)= N'[chamomile].[test].[stack].[prototype]'
              , @error_stack_prototype          [nvarchar](1000)=N'[chamomile].[error_stack].[stack].[prototype]'
              , @error_prototype                [nvarchar](1000)= N'[chamomile].[error].[stack].[prototype]'
              , @prototype_not_found            [nvarchar](1000)= N'[chamomile].[return_code].[prototype_not_found]';
      --
      -------------------------------------------
      declare @test                           [xml] = (select [data]
                 from   [repository].[get] (null, @test_prototype))
              , @stack_builder                [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get](null, @utility_xsc_prototype))
              , @type                         [sysname] = [utility].[get_meta_data](@test_type_meta_data)
              , @pass                         [sysname] = [utility].[get_meta_data](@pass_meta_data)
              , @fail                         [sysname]= [utility].[get_meta_data](@fail_meta_data)
              , @existing_transaction_message [nvarchar](max)= [utility].[get_meta_data](@existing_transaction_meta_data)
              , @test_stack                   [xml] = (select [data]
                 from   [repository].[get] (null, @test_stack_prototype))
              , @error_stack_builder          [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get](null, @utility_xsc_prototype))
              , @data_stack                   [xml] = (select [data]
                 from   [repository].[get] (null, @data_stack_prototype))
              , @builder_01                   [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get](null, @utility_xsc_prototype));
      set @error_stack = isnull(@error_stack, (select [data].query(N'/*/*[2]')
                                               from   [repository].[get](null, @utility_xsc_prototype)));
      set @builder = (select [data]
                      from   [repository].[get] (null, @error_stack_prototype));
      set @error_stack.modify(N'insert sql:variable("@builder") as last into (/*/result)[1]');
      --
      -------------------------------------------
      declare @test_object_description    [nvarchar](max) = N'the object that is constructed as a test.'
              , @test_result_description  [nvarchar](max) = N'the result of the test on the test object.'
              , @test_stack_description   [nvarchar](max) = N'the stack of all tests executed within this method, along with counts of all tests and results.'
              , @timestamp                [sysname] = convert([sysname], current_timestamp, 126)
              , @stack_result_description [nvarchar](max) = N'Individual results are contained within the tests. No aggregate result is expected for this stack.'
              --
              -- create unique transaction name, must be 32 characters or less
              -- todo - necessary for parallel operations?
              -----------------------------------
              , @transaction              [nvarchar](32);
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@server_information output;
      set @subject_fqn = @server_information.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @object_fqn = @server_information.value(N'(/*/fqn_prefix/@name)[1]', N'[nvarchar](1000)');
      set @major_version = @server_information.value(N'(/*/complete/@major_version)[1]', N'[int]');
      --
      -------------------------------------------
      begin
          if object_id(N'tempdb..#meta_data_list', N'U') is not null
            drop table #meta_data_list;
          create table #meta_data_list (
            [fqn]           [sysname]
            , [description] [nvarchar](max)
            );
          insert into #meta_data_list
                      ([fqn],[description])
            select [fqn]
                   , [description]
            from   [utility].[get_meta_data_list] (null)
            where  [fqn] in ( @test_type_meta_data, @pass_meta_data, @fail_meta_data, @existing_transaction_meta_data, @meta_data_not_found );
          select *
          from   #meta_data_list;
          select *
          from   #meta_data_list;
          select @message = coalesce(@message, N'', N'') + [type] + N', '
          from   #meta_data_list
          where  [description] is null;
          if @message is not null
            begin
                set @message = N'{null prototype list} = '
                               + left(@message, len(@message) - 1);
                raiserror (100065,1,1,@message);
                return 100065;
            end;
      end;
  end;
go
-------------------------------------------------
-- code block end
--
