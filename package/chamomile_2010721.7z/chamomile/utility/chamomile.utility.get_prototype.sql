use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[get_prototype]', N'FN') is not null
  drop function [utility].[get_prototype];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	select [utility].[get_prototype](N'[chamomile].[boolean].[default].[false]');
	select [utility].[get_prototype](N'[chamomile].[return_code].[code_65]');
*/
create function [utility].[get_prototype] (
  @name [nvarchar](1000))
returns [xml]
as
  begin
      declare @value [xml];
      if @name = N'[utility].[xsc].[stack].[prototype]'
        set @value = (select [data].query(N'/*/*[2]')
                      from   [repository].[get] (null, @name));
      else
        set @value = (select [data]
                      from   [repository].[get] (null, @name));
      return @value;
  end
go 
