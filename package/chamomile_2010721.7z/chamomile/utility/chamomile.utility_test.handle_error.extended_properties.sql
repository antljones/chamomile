if exists (select *
           from   ::fn_listextendedproperty(N'description', N'schema'
                                            , N'utility_test' , N'procedure'
                                            , N'handle_error', N'parameter'
                                            , N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description', @level0type=N'schema'
    , @level0name=N'utility_test', @level1type=N'procedure'
    , @level1name=N'handle_error', @level2type=N'parameter'
    , @level2name=N'@stack';
	  
	  go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility_test'
  , @level1type=N'procedure'
  , @level1name=N'handle_error'
  , @level2type=N'parameter'
  , @level2name=N'@stack'; if exists (select *
           from   ::fn_listextendedproperty(N'description', N'schema'
                                            , N'utility_test' , N'procedure'
                                            , N'handle_error', N'parameter'
                                            , N'@error_stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description', @level0type=N'schema'
    , @level0name=N'utility_test', @level1type=N'procedure'
    , @level1name=N'handle_error', @level2type=N'parameter'
    , @level2name=N'@error_stack';
	  
	  go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[@error_stack] [xml] - {todo: business description | where to find the value | how to use the value | what constraints are on the value}'
  , @level0type=N'schema'
  , @level0name=N'utility_test'
  , @level1type=N'procedure'
  , @level1name=N'handle_error'
  , @level2type=N'parameter'
  , @level2name=N'@error_stack';
