/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		INDEXED VIEWS ARE COVERED BY MICROSOFT CERTIFICATION EXAM 70-461 
		Exam 70-461: Querying Microsoft SQL Server 2012 
		Create Database Objects (24%): Create and alter views (simple statements). May include but not limited to:  
			create indexed views; create views without using the built in tools; CREATE, ALTER, DROP. Design views.  
			May include but not limited to: ensure code non regression by keeping consistent signature for  
			procedure, views and function (interfaces); security implications. 
 
		INDEXED VIEWS ARE OFTEN REFERRED TO AS MATERIALIZED VIEWS 
		"After a unique clustered index is created on the view, the view's result set is materialized immediately and  
		persisted in physical storage in the database, saving the overhead of performing this costly operation at  
		execution time." 
 
		INDEXES ON AN INDEXED VIEW ARE USED BY THE QUERY OPTIMIZER JUST AS ARE INDEXES ON THE UNDERLYING OBJECTS 
		"The indexed view can be used in a query execution in two ways. The query can reference the indexed view directly,  
		or, more importantly, the query optimizer can select the view if it determines that the view can be substituted  
		for some or all of the query in the lowest-cost query plan. In the second case, the indexed view is used instead  
		of the underlying tables and their ordinary indexes. The view does not need to be referenced in the query for the  
		query optimizer to use it during query execution. This allows existing applications to benefit from the newly  
		created indexed views without changing those applications." 

	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------
		Create Indexed Views: http://msdn.microsoft.com/en-us/library/ms191432.aspx 
		Improving Performance with SQL Server 2005 Indexed Views: http://technet.microsoft.com/en-us/library/cc917715.aspx 
		Improving Performance with SQL Server 2008 Indexed Views: http://msdn.microsoft.com/en-us/library/dd171921(v=sql.100).aspx 
*/
--
-- code block begin
use [chamomile];

go

if schema_id(N'indexed_views') is null
  execute (N'create schema indexed_views');

go

-- code block end
-- 
--  Required SET Options for Indexed Views.  
-- 
--  When SET ANSI_NULLS is ON, a SELECT statement that uses WHERE column_name = NULL  
--    returns zero rows even if there are null values in column_name 
set ansi_nulls on;
--  Trailing blanks in character values inserted into varchar columns are not trimmed.  
--    Trailing zeros in binary values inserted into varbinary columns are not trimmed.  
--    Values are not padded to the length of the column. 
set ansi_padding on;
--  When set to ON, if null values appear in aggregate functions, such as SUM, AVG, MAX,  
--    MIN, STDEV, STDEVP, VAR, VARP, or COUNT, a warning message is generated. When set to OFF,  
--    no warning is issued. 
set ansi_warnings on;
--  Terminates a query when an overflow or divide-by-zero error occurs during query execution. 
set arithabort on;
--  'abc' + NULL returns the value NULL. 
set concat_null_yields_null on;
--  When SET NUMERIC_ROUNDABORT is ON, an error is generated after a loss of precision occurs in an  
--    expression. When OFF, losses of precision do not generate error messages and the result is  
--    rounded to the precision of the column or variable storing the result. 
set numeric_roundabort off;
--  When SET QUOTED_IDENTIFIER is ON, identifiers can be delimited by double quotation marks,  
--    and literals must be delimited by single quotation marks. When SET QUOTED_IDENTIFIER  
--    is OFF, identifiers cannot be quoted and must follow all Transact-SQL rules for identifiers. 
set quoted_identifier on;

if object_id (N'[indexed_views].[view_test_01]', N'V') is not null
  drop view [indexed_views].[view_test_01];

go

if object_id (N'[indexed_views].[test_01]', N'U') is not null
  drop table [indexed_views].[test_01];

go

create table [indexed_views].[test_01] (
  [c1]   int
  , [c2] int
  , [c3] varchar(5)
  );

go

-- 
--  The view must be created WITH SCHEMABINDING in order to create an index on it. 
--  Tables must be referenced by two-part names, schema.tablename in the view definition. 
--  The definition of an indexed view must be deterministic.  
if object_id (N'[indexed_views].[view_test_01]', N'V') is not null
  drop view [indexed_views].[view_test_01];

go

create view [indexed_views].[view_test_01]
with schemabinding
as
  select [c1]
         , [c2]
         , [c3]
         ,
         -- 
         --  Having a non-deterministic function in the view will allow the view to be created, but attempts to create indexes will fail. 
         --  Msg 1949, Level 16, State 1, Line 2 
         --  Cannot create index on view 'test_01.[indexed_views].[view_test_01]'. The function 'getdate' yields nondeterministic results.  
         --    Use a deterministic system function, or modify the user-defined function to return deterministic results. 
         getdate() as [timestamp]
  --  Msg 4512, Level 16, State 3, Procedure [view_test_01], Line 5 
  --  Cannot schema bind view '[indexed_views].[view_test_01]' because name 'test_01' is invalid for schema binding. Names must be in two-part  
  --    format and an object cannot reference itself. 
  from   [indexed_views].[test_01];

go

if object_id (N'[indexed_views].[view_test_01]', N'V') is not null
  drop view [indexed_views].[view_test_01];

go

create view [indexed_views].[view_test_01]
with schemabinding
as
  select c1
         , c2
         , c3
  from   [indexed_views].[test_01];

go

-- An index on the table is not required to created an index on the view 
select count(*)
from   sys.indexes idx
where  idx.object_id = object_id(N'[indexed_views].[test_01]', N'U')
       and type_desc != N'HEAP';

go

-- 
--  A UNIQUE CLUSTERED INDEX is required before a NONCLUSTERED INDEX can be created 
if indexproperty (object_id('[indexed_views].[view_test_01]'), 'ix_test_view_test_01_c1', 'IndexID') is not null
  drop index [ix_test_view_test_01_c1] on [indexed_views].[view_test_01];

go

create unique clustered index ix_test_view_test_01_c1
  on [indexed_views].[view_test_01] (c1);

go

-- 
--  After a unique clustered index is created a nonclustered index can be created 
if indexproperty (object_id('[indexed_views].[view_test_01]'), 'ix_test_view_test_01_c1_c2_inc_c3', 'IndexID') is not null
  drop index ix_test_view_test_01_c1_c2_inc_c3 on [indexed_views].[view_test_01];

go

create nonclustered index ix_test_view_test_01_c1_c2_inc_c3
  on [indexed_views].[view_test_01]([c1], [c2])
  include ([c3])

go

-- 
-- There are now two indexes on the view but still none on the table 
select idx.name
       , idx.index_id
       , idx.type_desc
       , idx.is_unique
from   sys.indexes idx
where  idx.object_id = object_id(N'[indexed_views].[view_test_01]', N'V');

go

select count(*)
from   sys.indexes idx
where  idx.object_id = object_id(N'[indexed_views].[test_01]', N'U')
       and type_desc != N'HEAP';

go

insert into [indexed_views].[test_01]
            (c1
             , c2)
values      (1
             , 1),
            (2
             , 2),
            (3
             , 3);

select c1
       , c2
       , c3
from   [indexed_views].[view_test_01];

-- 
--  Attempts to truncate the table will fail. 
-- 
--  Returns error: 
--  Msg 3729, Level 16, State 2, Line 2 
begin try
    truncate table [indexed_views].[test_01];
end try

begin catch
    select N'Cannot TRUNCATE TABLE [indexed_views].[test_01] because it is being referenced by object [view_test_01]';
end catch

--  Records can still be deleted from the table 
delete from [indexed_views].[test_01]
where  c1 = 3;

select c1
       , c2
       , c3
from   [indexed_views].[view_test_01];

-- 
--  Attempts to change the underlying table in a way that would break the view will fail. 
-- 
--  Returns error: 
--  Msg 5074, Level 16, State 1, Line 2 
--  The object '[view_test_01]' is dependent on column 'c2'. 
--  Msg 4922, Level 16, State 9, Line 2 
begin try
    alter table [indexed_views].[test_01]
      drop column c2;
end try

begin catch
    select N'ALTER TABLE DROP COLUMN c2 failed because one or more objects access this column.'
end catch

-- 
--  Attempts to drop the table will fail. 
-- 
--  Returns error: 
--  Msg 3729, Level 16, State 1, Line 4 
begin try
    if object_id (N'[indexed_views].[test_01]', N'U') is not null
      drop table [indexed_views].[test_01];
end try

begin catch
    select N'Cannot DROP TABLE [indexed_views].[test_01] because it is being referenced by object [view_test_01].';
end catch

-- 
--  Columns can still be added to the table 
alter table [indexed_views].[test_01]
  add c4 bit;

select sch.name
       , tbl.name
       , col.name
       , typ.name
from   sys.columns as col
       join sys.tables as tbl
         on tbl.object_id = col.object_id
       join sys.schemas as sch
         on sch.schema_id = tbl.schema_id
       join sys.types as typ
         on col.system_type_id = typ.user_type_id
where  sch.name = N'[indexed_views]'
       and tbl.name = N'test_01';

-- 
-- Columns not referenced by the view can be altered 
alter table [indexed_views].[test_01]
  alter column c4 varchar(50);

-- 
--  Attempts to alter columns accessed by the view will fail 
-- 
--  Msg 5074, Level 16, State 1, Line 2 
--  The object '[view_test_01]' is dependent on column 'c3'. 
--  Msg 4922, Level 16, State 9, Line 2 
begin try
    alter table [indexed_views].[test_01]
      alter column c3 varchar(50);
end try

begin catch
    select N'ALTER TABLE ALTER COLUMN c3 failed because one or more objects access this column.';
end catch

go

-- 
--  Creating views that access system objects will fail 
--  Returns: 
--  Msg 2720, Level 16, State 1, Procedure vw_TryToAccessSystemObjects, Line 5 
if object_id(N'[indexed_views].vw_TryToAccessSystemObjets', N'V') is not null
  drop view [indexed_views].vw_trytoaccesssystemobjects;

go

declare @sql [nvarchar](max) = N'create view [indexed_views].vw_trytoaccesssystemobjects
    with schemabinding
    as
      select col.name
      from   sys.columns as col;';

begin try
    execute sp_executesql
      @sql;
end try

begin catch
    select N'Cannot schema bind view [indexed_views].vw_TryToAccessSystemObjects because it references system object sys.columns.'
end catch

go

-- 
--************************************************************************************************************************** 
--  CREATING VIEWS AGAINST REMOTE DATA 
--  CONNECTION test_02 
use [test_02];

go

if schema_id(N'[indexed_views]') is null
  execute (N'create schema [indexed_views]');

if object_id(N' [indexed_views].view_remote_table', N'V') is not null
  drop view [indexed_views].view_remote_table

go

-- 
--  A view can access remote data (across a linked server) 
create view [indexed_views].view_remote_table
as
  select a
         , b
         , c
  from   [test_02].[test_01].[indexed_views].[test_01];

go

-- 
--  An indexed view can not access remote data (across a linked server) 
--    as it requires schema binding and you can not schema bind to 
--    a remote object. 
--  RETURNS:  
--  Msg 2014, Level 16, State 1, Procedure vwi_TryToAccessRemoteWithIndexedView, Line 5 
--  Remote access is not allowed from within a schema-bound object. 
create view [indexed_views].vwi_trytoaccessremotewithindexedview
with schemabinding
as
  select a
         , b
         , c
  from   [test_02].[test_01].[indexed_views].[test_01];

go

-- 
--************************************************************************************************************************** 
--  INDEXES ON INDEXED VIEWS ARE USED AS TABLE INDEXES 
--  CONNECTION: test_01 
-- 
use [test_01];

go

-- 
-- 
if object_id(N'[indexed_views].[view_test_01]', N'V') is not null
  drop view [indexed_views].[view_test_01];

go

create view [indexed_views].[view_test_01]
as
  select a
         , b
         , c
  from   [indexed_views].[test_01];

go

-- 
--  Accessing the data from either the view or table performs a table scan and SQL Server 
--    suggests an index. 
select cvin
       , csaletype
       , cstockcode
from   [indexed_views].[view_test_01]
where  ddeliverydate = cast(N'2013-03-03' as datetime);

go

select cvin
       , csaletype
       , cstockcode
from   data.nvdrdata
where  ddeliverydate = cast(N'2013-03-03' as datetime);

go

-- 
-- Try with an indexed view 
if object_id(N'[indexed_views].vwi_NVDRData', N'V') is not null
  drop view [indexed_views].vwi_nvdrdata;

go

create view [indexed_views].vwi_nvdrdata
with schemabinding
as
  select cvin
         , csaletype
         , cstockcode
         , ddeliverydate
  from   data.nvdrdata;

go

if indexproperty (object_id('[indexed_views].vwi_NVDRData', N'V'), 'ix_indexed_views_vwi_NVDRData_cVIN', 'IndexID') is not null
  drop index [ix_indexed_views_vwi_nvdrdata_cvin] on [indexed_views].vwi_nvdrdata;

go

go

if indexproperty (object_id('[indexed_views].vwi_NVDRData', N'V'), 'ix_indexed_views_vwi_NVDRData_dDeliveryDate', 'IndexID') is not null
  drop index [ix_indexed_views_vwi_nvdrdata_ddeliverydate] on [indexed_views].vwi_nvdrdata;

go

go

-- 
--  No not only does a select using the view use the index, SQL Server also uses the index for a 
--    select directly to the table. 
select cvin
       , csaletype
       , cstockcode
from   [indexed_views].vwi_nvdrdata
where  ddeliverydate = cast(N'2013-03-03' as datetime);

go

select cvin
       , csaletype
       , cstockcode
from   data.nvdrdata
where  ddeliverydate = cast(N'2013-03-03' as datetime);

go 
