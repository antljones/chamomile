use [master];
go
if object_id(N'[dbo].[sp_get_best_practice_analysis]', N'P') is not null
  drop procedure [dbo].[sp_get_best_practice_analysis];
go
/*
	use [chamomile];
    go
    declare @bcp_command     [nvarchar](max), @documentation [nvarchar](max), @stack [xml];
    execute [dbo].[sp_get_best_practice_analysis]
      @object_fqn              =N'[unbreakable_code].[flower]'
      , @object_classification =N'oltp'
      , @status                =N'force_refresh'
      , @timestamp_output      = 0
      , @output_as             =N'none'
      , @stack                 = @stack output
      , @bcp_command           =@bcp_command output
      , @documentation         =@documentation output;
    select @bcp_command     as N'@bcp_command', @documentation as N'@documentation', @stack as N'@stack'; 
    
	--
	---------------------------------------------
	use [chamomile];
    go
    declare @bcp_command     [nvarchar](max), @documentation [nvarchar](max), @stack [xml];
    execute [dbo].[sp_get_best_practice_analysis]
      @object_fqn              =N'[unbreakable_code].[flower]'
      , @object_classification =N'olap'
      , @status                =N'force_refresh'
	  , @timestamp_output = 0
      , @output_as             =N'html'
      , @stack                 = @stack output
      , @bcp_command           =@bcp_command output
      , @documentation         =@documentation output;
    select @bcp_command     as N'@bcp_command', @documentation as N'@documentation', @stack as N'@stack'; 
     
    
    
    


	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
	--
	-- to view documentation
	----------------------------------------------------------------------
	declare @schema   [sysname] = N'dbo'
			, @object [sysname] = N'sp_get_best_practice_analysis';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
*/
create procedure [dbo].[sp_get_best_practice_analysis]
  @object_fqn              [nvarchar](max) = null
  , @object_classification [sysname]
  , @status                [sysname]= null
  , @timestamp_output      [bit]= 1
  , @output_as             [sysname] = N'none'
  , @stack                 [xml] output
  , @bcp_command           [nvarchar](max) = null output
  , @documentation         [nvarchar](max) = null output
as
  begin
      set nocount on;
      declare @identity_column_naming_error            [nvarchar](max)
              , @missing_table_documentation_violation [nvarchar](max)
              , @missing_column_documentation_error    [nvarchar](max)
              , @missing_procedure_documentation_error [nvarchar](max)
              , @missing_parameter_documentation_error [nvarchar](max)
              , @default_constraint_naming_error       [nvarchar](max)
              , @unique_constraint_naming_error        [nvarchar](max)
              , @primary_key_naming_error              [nvarchar](max)
              , @no_primary_key_error                  [nvarchar](max)
              , @no_identity_column_error              [nvarchar](max)
              , @no_unique_constraint_error            [nvarchar](max)
              , @composite_primary_key_error           [nvarchar](max)
              , @todo_error                            [nvarchar](max)
              , @unused_table_error                    [nvarchar](max)
              , @low_row_count_table_error             [nvarchar](max)
              , @unused_query_error                    [nvarchar](max);
      declare @count                [int]
              , @builder            [xml]
              , @stack_prototype    [xml]= [utility].[get_prototype](N'[chamomile].[utility].[stack].[xsc]')
              , @test               [xml] = [utility].[get_prototype](N'[chamomile].[test].[stack].[prototype]')
              , @test_stack         [xml] = [utility].[get_prototype](N'[chamomile].[test_stack].[stack].[prototype]')
              , @pass               [sysname] = [utility].[get_meta_data](null, N'[chamomile].[result].[default].[pass]')
              , @fail               [sysname] = [utility].[get_meta_data](null, N'[chamomile].[result].[default].[fail]')
              , @sequence           [int]
              , @test_name          [nvarchar](max)
              , @test_description   [nvarchar](max)
              , @return_code        [int]
              , @message            [nvarchar](max)
              , @start              [datetime] = current_timestamp
              , @timestamp          [sysname] = convert([sysname], current_timestamp, 121)
              , @subject_fqn        [nvarchar](1000)
              , @object_type        [sysname]
              , @elapsed            [decimal](9, 4)
              , @id                 [uniqueidentifier]
              , @server             [nvarchar](1000)
              , @normalized_server  [nvarchar](1000)
              , @database           [sysname]
              , @schema             [sysname]
              , @object             [sysname]
              , @stripped_timestamp [sysname]
              , @oltp               [sysname] = N'oltp'
              , @olap               [sysname] = N'olap'
              , @table              [sysname] = N'table'
              , @procedure          [sysname] = N'procedure'
              , @function           [sysname] = N'function';
      declare @list as table (
        [html] [nvarchar](max)
        );
      declare @required_properties as table(
        [property] [sysname]
        );
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      set @stripped_timestamp = @builder.value(N'(/*/@stripped_timestamp)[1]', N'[sysname]');
      --
      -------------------------------------------
      select @object = parsename(@object_fqn, 1)
             , @schema = parsename(@object_fqn, 2)
             , @database = parsename(@object_fqn, 3);
      --
      -------------------------------------------
      with [get_type]
           as (select lower([objects].[type_desc]) as [type_desc]
               from   [sys].[objects] as [objects]
               where  object_schema_name([objects].[object_id]) = @schema
                      and [objects].[name] = @object)
      select @object_type = case
                                when [type_desc] like N'%' + @table + N'%'
                                    then
                                  @table
                                when [type_desc] like N'%' + @procedure + N'%'
                                    then
                                  @procedure
                                when [type_desc] like N'%' + @function + N'%'
                                    then
                                  @function
                            end
      from   [get_type];
      --
      -------------------------------------------
      set @status = coalesce(@status, N'allow_stale');
      set @subject_fqn = N'[' + db_name()
                         + N'].[dbo].[sp_get_best_practice_analysis]';
      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @normalized_server=@builder.value(N'(/*/normalized_server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=N'[master].[dbo].[best_practice_analysis]';
      --
      -------------------------------------------
      set @message = N'[best_practice_analysis] {'
                     + @subject_fqn + N'}';
      set @test_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@message")');
      --
      -------------------------------------------
      if @object_type = @table
         and @object_classification = @oltp
        begin
            select @sequence = 1
                   , @test_name = N'missing_table_documentation_violation'
                   , @test_description = N'all tables must have documentation in extended properties.';
            set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
            set @test.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@test_name")');
            set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_description")');
            --
            -----------------------------------
            delete from @required_properties;
            insert into @required_properties
                        ([property])
            values      (N'description'),
                        (N'package'),
                        (N'revision');
            --
            ---------------------------------------
            with [template]
                 as (select object_schema_name([object].[object_id]) as [schema]
                            , [object].[name]                        as [table]
                            , [object].[object_id]                   as [object_id]
                            , [required_properties].[property]       as [required_property]
                     from   @required_properties as [required_properties]
                            join [sys].[tables] as [object]
                              on 1 = 1
                                 ----------
                                 and ( object_schema_name([object].[object_id]) = @schema
                                        or @schema is null )
                                 and ( [object].[name] = @object
                                        or @object is null ))
            select @missing_table_documentation_violation = coalesce(@identity_column_naming_error + ' ', '')
                                                            + N'<violation><li class="error" >['
                                                            + [schema] + N'].[' + [table] + N'].['
                                                            + [required_property] + N']</li></violation>'
            from   [template] as [template]
                   left join [sys].[extended_properties] as [extended_properties]
                          on [extended_properties].[major_id] = [template].[object_id]
                             and ( substring([extended_properties].[name], 0, len([required_property]) + 1) = [extended_properties].[name] )
            where  ( [extended_properties].[minor_id] = 0
                      or [extended_properties].[minor_id] is null )
                   and ( substring([extended_properties].[name], 0, len([required_property]) + 1) != [extended_properties].[name]
                          or [extended_properties].[name] is null );
            --
            ---------------------------------------
            set @missing_table_documentation_violation = N'<missing_table_documentation_violation><details><summary>[missing_table_documentation_violation]</summary><ol>'
                                                         + @missing_table_documentation_violation
                                                         + N'</ol></details></missing_table_documentation_violation>';
            set @builder = cast(@missing_table_documentation_violation as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//violation)', N'[int]');
                  if @count > 0
                    begin
                        set @message = N' - <u>violation_count</u> {'
                                       + cast(@count as [sysname]) + N'}';
                        set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                    end;
                  else
                    set @test.modify(N'replace value of (/*/@actual)[1] with sql:variable("@pass")');
                  --
                  set @test.modify(N'insert sql:variable("@builder") as last into (/*/result)[1]');
                  set @test_stack.modify(N'insert sql:variable("@test") as last into (/*)[1]');
                  set @missing_table_documentation_violation = cast(@builder as [nvarchar](max));
              end;
            select @test_stack
                   , @test;
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            select @sequence = 2
                   , @test_name = N'missing_column_documentation_error'
                   , @test_description = N'all columns must have documentation in extended properties.';
            set @test.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@sequence")');
            set @test.modify(N'replace value of (/*/object/@fqn)[1] with sql:variable("@test_name")');
            set @test.modify(N'replace value of (/*/object/description/text())[1] with sql:variable("@test_description")');
            select @test as N'here'
            --
            -------------------------------------
            delete from @required_properties;
            insert into @required_properties
                        ([property])
            values      (N'description');
            with [template]
                 as (select object_schema_name([object].[object_id]) as [schema]
                            , [object].[name]                        as [table]
                            , [object].[object_id]                   as [object_id]
                            , [columns].[name]                       as [column]
                            , [columns].[column_id]                  as [column_id]
                            , [required_properties].[property]       as [required_property]
                     from   @required_properties as [required_properties]
                            join [sys].[tables] as [object]
                              on 1 = 1
                            join [sys].[columns] as [columns]
                              on [columns].[object_id] = [object].[object_id]
                     where
                      ----------
                      ( object_schema_name([object].[object_id]) = @schema
                         or @schema is null )
                      and ( [object].[name] = @object
                             or @object is null ))
            select @missing_column_documentation_error = coalesce(@missing_column_documentation_error + ' ', '')
                                                         + N'<violation><li class="error" >['
                                                         + [schema] + N'].[' + [table] + N'].[' + [column]
                                                         + N'].[' + [required_property]
                                                         + N']</li></violation>'
            from   [template] as [template]
                   left join [sys].[extended_properties] as [extended_properties]
                          on [extended_properties].[major_id] = [template].[object_id]
                             and [extended_properties].[minor_id] = [template].[column_id]
                             and ( substring([extended_properties].[name], 0, len([required_property]) + 1) = [extended_properties].[name] )
            where  ( [extended_properties].[minor_id] = 0
                      or [extended_properties].[minor_id] is null )
                   and ( substring([extended_properties].[name], 0, len([required_property]) + 1) != [extended_properties].[name]
                          or [extended_properties].[name] is null );
            --
            ---------------------------------------
            set @missing_column_documentation_error = N'<missing_column_documentation_error><details><summary>[missing_column_documentation_error]</summary><ol>'
                                                      + @missing_column_documentation_error
                                                      + N'</ol></details></missing_column_documentation_error>';
            set @builder = cast(@missing_column_documentation_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @missing_column_documentation_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @missing_column_documentation_error as N'@missing_column_documentation_error';
        end;
      --
      -------------------------------------------
      if @object_type = @procedure
        begin
            ----== select N'running @missing_procedure_documentation_error';
            delete from @required_properties;
            insert into @required_properties
                        ([property])
            values      (N'description'),
                        (N'package'),
                        (N'revision'),
                        (N'execute_as');
            with [template]
                 as (select object_schema_name([object].[object_id]) as [schema]
                            , [object].[name]                        as [procedure]
                            , [object].[object_id]                   as [object_id]
                            , [required_properties].[property]       as [required_property]
                     from   @required_properties as [required_properties]
                            join [sys].[procedures] as [object]
                              on 1 = 1
                     ----------
                     where  ( object_schema_name([object].[object_id]) = @schema
                               or @schema is null )
                            and ( [object].[name] = @object
                                   or @object is null ))
            select @missing_procedure_documentation_error = coalesce(@missing_procedure_documentation_error + ' ', '')
                                                            + N'<violation><li class="error" >['
                                                            + [schema] + N'].[' + [procedure] + N'].['
                                                            + [required_property] + N']</li></violation>'
            from   [template] as [template]
                   left join [sys].[extended_properties] as [extended_properties]
                          on [extended_properties].[major_id] = [template].[object_id]
                             and ( substring([extended_properties].[name], 0, len([required_property]) + 1) = [extended_properties].[name] )
            where  ( [extended_properties].[minor_id] = 0
                      or [extended_properties].[minor_id] is null )
                   and ( substring([extended_properties].[name], 0, len([required_property]) + 1) != [extended_properties].[name]
                          or [extended_properties].[name] is null );
            --
            ---------------------------------------
            set @missing_procedure_documentation_error = N'<missing_procedure_documentation_error><details><summary>[missing_procedure_documentation_error]</summary><ol>'
                                                         + @missing_procedure_documentation_error
                                                         + N'</ol></details></missing_procedure_documentation_error>';
            set @builder = cast(@missing_procedure_documentation_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @missing_procedure_documentation_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @missing_procedure_documentation_error as N'@missing_procedure_documentation_error';
        end;
      --
      -------------------------------------------
      if @object_type = @procedure
        begin
            ----== select N'running @missing_parameter_documentation_error';
            delete from @required_properties;
            insert into @required_properties
                        ([property])
            values      (N'description');
            with [template]
                 as (select object_schema_name([object].[object_id]) as [schema]
                            , [object].[name]                        as [procedure]
                            , [object].[object_id]                   as [object_id]
                            , [parameters].[name]                    as [parameter]
                            , [parameters].[parameter_id]            as [parameter_id]
                            , [required_properties].[property]       as [required_property]
                     from   @required_properties as [required_properties]
                            join [sys].[procedures] as [object]
                              on 1 = 1
                            join [sys].[parameters] as [parameters]
                              on [parameters].[object_id] = [object].[object_id]
                     ----------
                     where  ( object_schema_name([object].[object_id]) = @schema
                               or @schema is null )
                            and ( [object].[name] = @object
                                   or @object is null ))
            select @missing_parameter_documentation_error = coalesce(@missing_parameter_documentation_error + ' ', '')
                                                            + N'<violation><li class="error" >['
                                                            + [schema] + N'].[' + [procedure] + N'].['
                                                            + [parameter] + N'].[' + [required_property]
                                                            + N']</li></violation>'
            from   [template] as [template]
                   left join [sys].[extended_properties] as [extended_properties]
                          on [extended_properties].[major_id] = [template].[object_id]
                             and [extended_properties].[minor_id] = [template].[parameter_id]
                             and ( substring([extended_properties].[name], 0, len([required_property]) + 1) = [extended_properties].[name] )
            where  ( [extended_properties].[minor_id] = 0
                      or [extended_properties].[minor_id] is null )
                   and ( substring([extended_properties].[name], 0, len([required_property]) + 1) != [extended_properties].[name]
                          or [extended_properties].[name] is null );
            --
            ---------------------------------------
            set @missing_parameter_documentation_error = N'<missing_parameter_documentation_error><details><summary>[missing_parameter_documentation_error]</summary><ol>'
                                                         + @missing_parameter_documentation_error
                                                         + N'</ol></details></missing_parameter_documentation_error>';
            set @builder = cast(@missing_parameter_documentation_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @missing_parameter_documentation_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @missing_parameter_documentation_error as N'@missing_parameter_documentation_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @default_constraint_naming_error';
            select @default_constraint_naming_error = coalesce(@default_constraint_naming_error + ' ', '')
                                                      + N'<violation><li class="error" >['
                                                      + [schemas].[name] + N'].[' + [object].[name]
                                                      + N'].[' + [columns].[name] + N'].['
                                                      + [default_constraints].[name]
                                                      + N']</li></violation>'
            from   [sys].[default_constraints] as [default_constraints]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [default_constraints].[schema_id]
                   join [sys].[tables] as [object]
                     on [object].[object_id] = [default_constraints].[parent_object_id]
                   join [sys].[columns] as [columns]
                     on [columns].[column_id] = [default_constraints].[parent_column_id]
                        and [columns].[object_id] = [default_constraints].[parent_object_id]
            where  [default_constraints].[name] not like lower(N'' + [schemas].[name] + N'.' + [object].[name]
                                                               + N'.' + [columns].[name] + N'.default')
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @default_constraint_naming_error = N'<default_constraint_naming_error><details><summary>[default_constraint_naming_error]</summary><ol>'
                                                   + @default_constraint_naming_error
                                                   + N'</ol></details></default_constraint_naming_error>';
            set @builder = cast(@default_constraint_naming_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @default_constraint_naming_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @default_constraint_naming_error as N'@default_constraint_naming_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @unique_constraint_naming_error';
            select @unique_constraint_naming_error = coalesce(@unique_constraint_naming_error + ' ', '')
                                                     + N'<violation><li class="error" >['
                                                     + [schemas].[name] + N'].['+ + [object].[name]
                                                     + N'].[' + [columns].[name] + N'].['
                                                     + [indexes].[name] + N']</li></violation>'
            from   [sys].[indexes] as [indexes]
                   join [sys].[index_columns] as [index_columns]
                     on [indexes].[index_id] = [index_columns].[index_id]
                        and [indexes].[object_id] = [index_columns].[object_id]
                   join [sys].[tables] as [object]
                     on [object].[object_id] = [index_columns].[object_id]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [object].[schema_id]
                   join [sys].[columns] as [columns]
                     on [columns].[column_id] = [index_columns].[column_id]
                        and [columns].[object_id] = [index_columns].[object_id]
            where  [indexes].[is_unique_constraint] = 1
                   and [indexes].[name] not like lower([schemas].[name] + N']' + [object].[name] + N'.'
                                                       + [columns].[name] + N'.unique')
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @unique_constraint_naming_error = N'<unique_constraint_naming_error><details><summary>[unique_constraint_naming_error]</summary><ol>'
                                                  + @unique_constraint_naming_error
                                                  + N'</ol></details></unique_constraint_naming_error>';
            set @builder = cast(@unique_constraint_naming_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @unique_constraint_naming_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @unique_constraint_naming_error as N'@unique_constraint_naming_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @primary_key_naming_error';
            select @primary_key_naming_error = coalesce(@primary_key_naming_error + ' ', '')
                                               + N'<violation><li class="error" >['
                                               + [schemas].[name] + N'].[' + [object].[name]
                                               + N'].[' + [columns].[name] + N'].['
                                               + [indexes].[name] + N']</li></violation>'
            from   [sys].[tables] as [object]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[indexes] as [indexes]
                          on [indexes].[object_id] = [object].[object_id]
                   left join [sys].[index_columns] as [index_columns]
                          on [indexes].[index_id] = [index_columns].[index_id]
                             and [indexes].[object_id] = [index_columns].[object_id]
                   left join [sys].[columns] as [columns]
                          on [columns].[column_id] = [index_columns].[column_id]
                             and [columns].[object_id] = [index_columns].[object_id]
            where  [indexes].[is_primary_key] = 1
                   and [indexes].[name] not like lower([schemas].[name] + N'.' + [object].[name] + N'.'
                                                       + [columns].[name]
                                                       + N'.primary_key_clustered')
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @primary_key_naming_error = N'<primary_key_naming_error><details><summary>[primary_key_naming_error]</summary><ol>'
                                            + @primary_key_naming_error
                                            + N'</ol></details></primary_key_naming_error>';
            set @builder = cast(@primary_key_naming_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @primary_key_naming_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @primary_key_naming_error as N'@primary_key_naming_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @identity_column_naming_error';
            select @identity_column_naming_error = coalesce(@identity_column_naming_error + ' ', '')
                                                   + N'<violation><li class="error" >['
                                                   + [schemas].[name] + N'].[' + [object].[name]
                                                   + N'].[' + [columns].[name]
                                                   + N']</li></violation>'
            from   [sys].[tables] as [object]
                   left join [sys].[schemas] as [schemas]
                          on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[columns] as [columns]
                          on [object].[object_id] = [columns].[object_id]
                             and [columns].[is_identity] = 1
            where  [columns].[name] != lower(N'id')
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @identity_column_naming_error = N'<identity_column_naming_error><details><summary>[identity_column_naming_error]</summary><ol>'
                                                + @identity_column_naming_error
                                                + N'</ol></details></identity_column_naming_error>';
            set @builder = cast(@identity_column_naming_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @identity_column_naming_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @identity_column_naming_error as N'@identity_column_naming_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @no_primary_key_error';
            select @no_primary_key_error = coalesce(@no_primary_key_error + ' ', '')
                                           + N'<violation><li class="error" >['
                                           + [schemas].[name] + N'].[' + [object].[name]
                                           + N'].[' + N']</li></violation>'
            from   [sys].[tables] as [object]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[indexes] as [indexes]
                          on [indexes].[object_id] = [object].[object_id]
                   left join [sys].[index_columns] as [index_columns]
                          on [indexes].[index_id] = [index_columns].[index_id]
                             and [indexes].[object_id] = [index_columns].[object_id]
                   left join [sys].[columns] as [columns]
                          on [columns].[column_id] = [index_columns].[column_id]
                             and [columns].[object_id] = [index_columns].[object_id]
            where  [indexes].[type_desc] = N'HEAP'
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @no_primary_key_error = N'<no_primary_key_error><details><summary>[no_primary_key_error]</summary><ol>'
                                        + @no_primary_key_error
                                        + N'</ol></details></no_primary_key_error>';
            set @builder = cast(@no_primary_key_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @no_primary_key_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @no_primary_key_error as N'@no_primary_key_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
         and @object_classification = @oltp
        begin
            ----== select N'running @no_identity_column_error';
            select @no_identity_column_error = coalesce(@no_identity_column_error + ' ', '')
                                               + N'<violation><li class="error" >['
                                               + [schemas].[name] + N'].[' + [object].[name]
                                               + N'].[' + N']</li></violation>'
            from   [sys].[tables] as [object]
                   left join [sys].[schemas] as [schemas]
                          on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[columns] as [columns]
                          on [object].[object_id] = [columns].[object_id]
                             and [columns].[is_identity] = 1
            ----------
            where  ( object_schema_name([object].[object_id]) = @schema
                      or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null )
            group  by [schemas].[name]
                      , [object].[name]
                      , [columns].[is_identity]
            having [columns].[is_identity] is null;
            --
            ---------------------------------------
            set @no_identity_column_error = N'<no_identity_column_error><details><summary>[no_identity_column_error]</summary><ol>'
                                            + @no_identity_column_error
                                            + N'</ol></details></no_identity_column_error>';
            set @builder = cast(@no_identity_column_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @no_identity_column_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @no_identity_column_error as N'@no_identity_column_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
        begin
            ----== select N'running @no_unique_constraint_error';
            select @no_unique_constraint_error = coalesce(@no_unique_constraint_error + ' ', '')
                                                 + isnull(N'<violation><li class="error" >[' + [schemas].[name] + N'].['+ [object].[name] + N']</li></violation>', N'')
            from   [sys].[tables] as [object]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[indexes] as [indexes]
                          on [indexes].[object_id] = [object].[object_id]
                             and [indexes].[is_unique_constraint] = 1
                   left join [sys].[index_columns] as [index_columns]
                          on [indexes].[index_id] = [index_columns].[index_id]
                             and [indexes].[object_id] = [index_columns].[object_id]
                   left join [sys].[columns] as [columns]
                          on [columns].[column_id] = [index_columns].[column_id]
                             and [columns].[object_id] = [index_columns].[object_id]
            where  [indexes].[name] is null
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null );
            --
            ---------------------------------------
            set @no_unique_constraint_error = N'<no_unique_constraint_error><details><summary>[no_unique_constraint_error]</summary><ol>'
                                              + @no_unique_constraint_error
                                              + N'</ol></details></no_unique_constraint_error>';
            set @builder = cast(@no_unique_constraint_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @no_unique_constraint_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @no_unique_constraint_error as N'@no_unique_constraint_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
         and @object_classification = @oltp
        begin
            ----== select N'running @composite_primary_key_error';
            select @composite_primary_key_error = coalesce(@composite_primary_key_error + ' ', '')
                                                  + isnull(N'<violation><li class="error" >[' + [schemas].[name] + N'].['+ [object].[name] + N'].[' + [indexes].[name] + N']</li></violation>', N'')
            from   [sys].[tables] as [object]
                   join [sys].[schemas] as [schemas]
                     on [schemas].[schema_id] = [object].[schema_id]
                   left join [sys].[indexes] as [indexes]
                          on [indexes].[object_id] = [object].[object_id]
                   left join [sys].[index_columns] as [index_columns]
                          on [indexes].[index_id] = [index_columns].[index_id]
                             and [indexes].[object_id] = [index_columns].[object_id]
                   left join [sys].[columns] as [columns]
                          on [columns].[column_id] = [index_columns].[column_id]
                             and [columns].[object_id] = [index_columns].[object_id]
            where  [indexes].[is_primary_key] = 1
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null )
            group  by [schemas].[name]
                      , [object].[name]
                      , [indexes].[name]
            having count(*) > 1;
            --
            ---------------------------------------
            set @composite_primary_key_error = N'<composite_primary_key_error><details><summary>[composite_primary_key_error]</summary><ol>'
                                               + @composite_primary_key_error
                                               + N'</ol></details></composite_primary_key_error>';
            set @builder = cast(@composite_primary_key_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @composite_primary_key_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @composite_primary_key_error as N'@composite_primary_key_error';
        end;
      --
      -------------------------------------------
      begin
          ----== select N'running @todo_error';
      /* insert into @list
                   ([html])
         select N'<li>' + cast([class] as [sysname])
                + [class_desc]
         --  + cast([major_id] as [sysname])
         --  + cast([minor_id] as [sysname])
         --  + object_schema_name([major_id])
         --  + object_name([major_id]) + [name]
         --  + cast([value] as [nvarchar](max)) + N'</li>'
         from   [sys].[extended_properties] as [extended_properties]
         where  cast([name] as [sysname]) like N'%todo%'
                 or cast([value] as [sysname]) like N'%todo%'
                    ----------
                    and ( object_schema_name([major_id]) = @schema
                           or @schema is null )
                    and ( [major_id] = @object
                           or @object is null )
         order  by object_schema_name([major_id])
                   , object_name([major_id])
                   , [name];
       select @todo_error = coalesce(@todo_error + ' ', '') + [html]
       from   @list;
       set @todo_error = @todo_error;*/
          --
          ---------------------------------------
          set @todo_error = N'<todo_error><details><summary>[todo_error]</summary><ol>'
                            + @todo_error
                            + N'</ol></details></todo_error>';
          set @builder = cast(@todo_error as [xml]);
          if @builder is not null
            begin
                set @count = @builder.value(N'count(//error)', N'[int]');
                set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                set @message = N' - error_count {'
                               + cast(@count as [sysname]) + N'}';
                set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                set @todo_error = cast(@builder as [nvarchar](max));
            end;
      ----== select @todo_error as N'@todo_error';
      end;
      --
      -------------------------------------------
      if @object_type = @table
         and @schema is null
         and @object is null
        begin
            ----== select N'running @unused_table_error';
            select @unused_table_error = coalesce(@unused_table_error + ' ', '')
                                         + isnull(N'<violation><li class="error" >[' + [schemas].[name] + N'].['+ [object].[name] + + N']</li></violation>', N'')
            from   [sys].[tables] as [object]
                   inner join [sys].[schemas] as [schemas]
                           on [schemas].[schema_id] = [object].[schema_id]
                   inner join [sys].[indexes] as [indexes]
                           on [object].[object_id] = [indexes].[object_id]
                   inner join [sys].[partitions] as [partitions]
                           on [indexes].[object_id] = [partitions].[object_id]
                              and [indexes].[index_id] = [partitions].[index_id]
                   inner join [sys].[allocation_units] as [allocation_units]
                           on [partitions].[partition_id] = [allocation_units].container_id
            where  [object].[name] not like 'dt%'
                   and [object].[is_ms_shipped] = 0
                   and [indexes].[object_id] > 255
                   and [partitions].[rows] = 0
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null )
            group  by [schemas].[name]
                      , [object].[name]
                      , [partitions].[rows]
            order  by sum([allocation_units].total_pages) * 8;
            --
            ---------------------------------------
            set @unused_table_error = N'<unused_table_error><details><summary>[unused_table_error]</summary><ol>'
                                      + @unused_table_error
                                      + N'</ol></details></unused_table_error>';
            set @builder = cast(@unused_table_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @unused_table_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @unused_table_error as N'@unused_table_error';
        end;
      --
      -------------------------------------------
      if @object_type = @table
         and @schema is null
         and @object is null
        begin
            ----== select N'running @low_row_count_table_error';
            select @low_row_count_table_error = coalesce(@low_row_count_table_error + ' ', '')
                                                + isnull(N'<violation><li class="error" >[' + [schemas].[name] + N'].['+ [object].[name] + + N']</li></violation>', N'')
            from   [sys].[tables] as [object]
                   inner join [sys].[schemas] as [schemas]
                           on [schemas].[schema_id] = [object].[schema_id]
                   inner join [sys].[indexes] as [indexes]
                           on [object].[object_id] = [indexes].[object_id]
                   inner join [sys].[partitions] as [partitions]
                           on [indexes].[object_id] = [partitions].[object_id]
                              and [indexes].[index_id] = [partitions].[index_id]
                   inner join [sys].[allocation_units] as [allocation_units]
                           on [partitions].[partition_id] = [allocation_units].container_id
            where  [object].[name] not like 'dt%'
                   and [object].is_ms_shipped = 0
                   and [indexes].[object_id] > 255
                   and [partitions].[rows] < 5
                   ----------
                   and ( object_schema_name([object].[object_id]) = @schema
                          or @schema is null )
                   and ( [object].[name] = @object
                          or @object is null )
            group  by [schemas].[name]
                      , [object].[name]
                      , [partitions].[rows]
            order  by sum([allocation_units].total_pages) * 8;
            --
            ---------------------------------------
            set @low_row_count_table_error = N'<low_row_count_table_error><details><summary>[low_row_count_table_error]</summary><ol>'
                                             + @low_row_count_table_error
                                             + N'</ol></details></low_row_count_table_error>';
            set @builder = cast(@low_row_count_table_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @low_row_count_table_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @low_row_count_table_error as N'@low_row_count_table_error';
        end;
      --
      -------------------------------------------
      if @object_type = @procedure
         and @schema is null
         and @object is null
        begin
            ----== select N'running @unused_query_error';
            with [builder]
                 as (select top(10) [objects].[object_id]
                     from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                            join [sys].[databases] as [databases]
                              on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                            join [sys].[objects] as [objects]
                              on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
                     where  [databases].[name] = db_name()
                            and datediff(day, [last_execution_time], current_timestamp) > 90
                     order  by [last_execution_time] asc)
            select @unused_query_error = coalesce(@unused_query_error + ' ', '')
                                         + [objects].[name]
                                         + convert([sysname], [cached_time])
                                         + convert([sysname], [last_execution_time])
                                         + convert([sysname], [execution_count])
                                         + convert([sysname], [total_worker_time] / [execution_count])
                                         + convert([sysname], [total_elapsed_time] / [execution_count])
                                         + convert([sysname], [total_logical_reads] / [execution_count])
                                         + convert([sysname], [total_logical_writes] / [execution_count])
                                         + convert([sysname], [total_physical_reads] / [execution_count])
            from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                   join [builder] as [builder]
                     on [builder].[object_id] = [dm_exec_procedure_stats].[object_id]
                   join [sys].[databases] as [databases]
                     on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                   join [sys].[objects] as [objects]
                     on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
            where  [databases].[name] = db_name()
            order  by [last_execution_time] asc;
            --
            ---------------------------------------
            set @unused_query_error = N'<unused_query_error><div id="first_indent"><details><summary>[unused_query_error]</summary><ol>'
                                      + @unused_query_error
                                      + N'</ol></details></div></unused_query_error>';
            set @builder = cast(@unused_query_error as [xml]);
            if @builder is not null
              begin
                  set @count = @builder.value(N'count(//error)', N'[int]');
                  set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
                  set @message = N' - error_count {'
                                 + cast(@count as [sysname]) + N'}';
                  set @builder.modify(N'insert text {sql:variable("@message")} as last into (/*/details/summary)[1]');
                  set @unused_query_error = cast(@builder as [nvarchar](max));
              end;
        ----== select @unused_query_error as N'@unused_query_error';
        end;
      --
      -- documentation
      ---------------------------------------------------------------------------------------------
      set @documentation = N'<br><details class="summary">
						<summary>[documentation]</summary>[object_name]: [master].[dbo].[sp_get_best_practice_analysis]';
      select @documentation = coalesce(@documentation + ' ', '')
                              + isnull(N'<tr><td valign="top" align="right">[' +cast([extended_properties].[name] as [sysname])+ N']: '+ cast([extended_properties].[value] as [nvarchar](max)), N'')
      from   [master].[sys].[extended_properties] as [extended_properties]
             join [master].[sys].[objects] as [objects]
               on [objects].[object_id] = [extended_properties].[major_id]
             join [master].[sys].[schemas] as [schemas]
               on [objects].[schema_id] = [schemas].[schema_id]
      where  [schemas].[name] = @schema
             and [objects].[name] = @object;
      --
      -- load documentation into repository and create bcp extraction command
      -------------------------------------------		 
      select @elapsed = cast(466000 / cast(1000000 as [decimal](9, 0)) as [decimal](9, 4));
      set @documentation = N'<best_practice_analysis><div id="outer_indent"><details><summary>'
                           + @object_fqn + + N'</summary>'
                           --
                           + case when cast(@missing_table_documentation_violation as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @missing_table_documentation_violation, N'') else N'' end
                           --
                           + case when cast(@missing_column_documentation_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @missing_column_documentation_error, N'') else N'' end
                           --
                           + case when cast(@missing_parameter_documentation_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @missing_parameter_documentation_error, N'') else N'' end
                           --
                           + case when cast(@default_constraint_naming_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @default_constraint_naming_error, N'') else N'' end
                           --
                           + case when cast(@unique_constraint_naming_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @unique_constraint_naming_error, N'') else N'' end
                           --
                           + case when cast(@primary_key_naming_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @primary_key_naming_error, N'') else N'' end
                           --
                           + case when cast(@identity_column_naming_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @identity_column_naming_error, N'') else N'' end
                           --
                           + case when cast(@no_primary_key_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @no_primary_key_error, N'') else N'' end
                           --
                           + case when cast(@no_identity_column_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @no_identity_column_error, N'') else N'' end
                           --
                           + case when cast(@no_unique_constraint_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @no_unique_constraint_error, N'') else N'' end
                           --
                           + case when cast(@composite_primary_key_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @composite_primary_key_error, N'') else N'' end
                           --
                           + case when cast(@todo_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @todo_error, N'') else N'' end
                           --
                           + case when cast(@unused_table_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @unused_table_error, N'') else N'' end
                           --
                           + case when cast(@low_row_count_table_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @low_row_count_table_error, N'') else N'' end
                           --
                           + case when cast(@unused_query_error as [xml]).value(N'count(//error)', N'[int]') > 0 then + isnull( @unused_query_error, N'') else N'' end
                           --
                           + N'<p class="timestamp">built by {'
                           + @subject_fqn + N'} timestamp {' + @timestamp
                           + N'} elapsed_time(s) {'
                           + cast(@elapsed as [sysname]) + N'}</p>'
                           + N'</details></div></best_practice_analysis>';
      --
      -------------------------------------------
      set @builder = cast(@documentation as [xml]);
      set @count = @builder.value(N'count (//error)', N'[int]');
      set @builder.modify(N'insert attribute error_count {sql:variable("@count")} as first into (/*)[1]');
      set @documentation = cast(@builder as [nvarchar](max));
      set @stack = @builder;
      --
      -------------------------------------------
      if @output_as != N'none'
        begin
            execute [chamomile].[documentation].[set]
              @object_fqn      =@object_fqn
              , @documentation =@documentation
              , @type          = N'html'
              , @sequence      = 1
              , @stack         = @stack output;
            --
            -------------------------------------------
            if @timestamp_output = 1
              set @message = N'_' + @stripped_timestamp;
            else
              set @message = N'';
            --
            -------------------------------------------
            if @output_as = N'html'
              set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                                 + @object_fqn + N'''));" queryout '
                                 + @subject_fqn + '_' + @object_fqn + @message + N'.'
                                 + @output_as + N' -t, -T -c -d ' + db_name()
                                 + N' -S ' + @server + N';';
            else if @output_as = N'xml'
              set @bcp_command = N'BCP "select [documentation].[get] ('''
                                 + @object_fqn + N''');" queryout '
                                 + @subject_fqn + '_' + @object_fqn + @message + N'.'
                                 + @output_as + N' -t, -T -c -d ' + db_name()
                                 + N' -S ' + @server + N';';
        end;
  end;
go
--
-------------------------------------------------
exec [sp_MS_marksystemobject]
  N'sp_get_best_practice_analysis';
go
--
-------------------------------------------------
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'dbo', N'procedure', N'sp_get_best_practice_analysis', default, default))
  exec sys.sp_addextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'procedure'
    , @level1name=N'sp_get_best_practice_analysis'
    , @level2type=null
    , @level2name=null;
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'procedure'
  , @level1name=N'sp_get_best_practice_analysis'
  , @level2type=null
  , @level2name=null;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140706', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'revision_20140706'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140706'
  , @value     =N'Katherine E. Lightsey - Created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_best_practice_analysis'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_basic', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_best_practice_analysis'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<details class="summary">
				<summary>[todo]</summary><ol>
				<ol>
					<li>Check databases to ensure that no files are being stored on the c: drive.</li>
					<li>Add documentation checks for:
						<ol>
							<li>functions and function parameters.</li>
							<li>views and view columns.</li>
							<li>indexes.</li>
						</ol>
					<li>Check for constraints on columns - columns should have constraints by default.</li>
					<li>Check for auditing columns on tables.</li>
					<li>Pass in patterns for naming error checks.</li>
					<li>Exclude xml tables from [no_unique_constraint_error].</li>
					<li>Check for [newsequentialid] for [no_identity_column_error].</li>
					<li>Output bcp command similar to [master].[dbo].[sp_create_extended_properties].</li>
					<li>List "todo".</li>
					<li>include "execute [repository].[set] @id=@id, @delete=1" in bcp command.</li>
					<li>Pass in object and schema to allow analysis of granular objects.</li>
				</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_best_practice_analysis'
go
if not exists
       (select *
        from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'<details class="summary">
				<summary>[master].[dbo].[sp_get_best_practice_analysis]</summary><ol>
			<p>Analyzes the current database for error of best practice. Best practice evalutions include:</p>
				<ol>
						<li>[naming_error] - The object does conform to standard naming convention.
						<li>[no_primary_key_error - The table does not include a primary key.
						<li>[composite_primary_key_error - The table uses a composite primary key. This typically indicateds that the key is a composite natural key. Recommend;ed practice is to use a surrogate individual primary key on OLTP tables, only using a natural or composite natural primary key on OLAP tables.
						<li>[no_identity_column_error - The table does not include an identity column. All OLTP tables should include an identity column of either type [int] or [bigint].
						<li>[no_unique_constraint_error - The table does not include a unique index. All tables must include a unique index which defines the uniqueness of the table.

				</ol>
			<p>Objects evaluated include:</p>
				<ol>
					<li>[DEFAULT_CONSTRAINT - </li>
					<li>[FOREIGN_KEY_CONSTRAINT - </li>
					<li>[PRIMARY_KEY_CONSTRAINT -</li>
					<li>[IDENTITY_COLUMN - </li>
					<li>[SQL_SCALAR_FUNCTION -</li>
					<li>[SQL_STORED_PROCEDURE -</li>
					<li>[SQL_TRIGGER -</li>
					<li>[UNIQUE_CONSTRAINT -</li>
					<li>[USER_TABLE - </li>
				</ol></details>'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis';
go
if not exists
       (select *
        from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'execute_as'
    , @value     =N'
	<p>--</p> 
	<p>--select text of [bcp command] output and execute in command window. The extend;ed properties are copied	to a file as named in the bcp command.</p>
	<p>-------------------------------------------------------------------</p> 
	<p>use [chamomile];</p>
	<p>go</p>
	<p>execute [dbo].[sp_get_best_practice_analysis];</p>
	'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_best_practice_analysis'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.92.00', N'SCHEMA', N'dbo', N'procedure', N'sp_get_best_practice_analysis', null, null))
  exec sys.sp_addextendedproperty
    @name        =N'release_00.92.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'procedure'
    , @level1name=N'sp_get_best_practice_analysis'
go
exec sys.sp_addextendedproperty
  @name        =N'release_00.92.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'procedure'
  , @level1name=N'sp_get_best_practice_analysis'
go 
