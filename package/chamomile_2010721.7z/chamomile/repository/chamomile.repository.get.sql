use [chamomile]
go
if schema_id(N'repository') is null
  execute (N'create schema repository');
go
if exists
   (select *
    from   sys.objects
    where  object_id = object_id(N'[repository].[get]')
           and type in ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  drop function [repository].[get];
go
set ansi_nulls on
go
set quoted_identifier on
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	select * from [repository].[get_list] (null, N'[chamomile].[boolean].[default].[false]');
	select [id]
		   , [entry]
		   , [fqn]
		   , [category]
		   , [class]
		   , [type]
		   , [sub_type]
		   , [description]
		   , [data]
	from   [repository].[get] (null, N'[chamomile].[boolean].[default].[false]'); 

	select [description] from [repository].[get] ('0916D6E9-A106-E411-881D-20689D66B6F7', null);
	
select [id],[entry],[fqn],[category],[class],[type],[sub_type],[description],[data]
from   [repository].[get] (null, N'[utility].[xsc].[stack].[prototype]'); 
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	All content is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
	licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Accessor method for [repository_secure].[data].
	filename:		chamomile.repository.get.sql

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'repository_secure'
			, @object [sysname] = N'get';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 

		   
	select * from [repository].[get](N'64058A26-0DC5-497B-B512-4C4EE1F071F0', null);
	select * from [repository].[get](null, N'[chamomile].[documentation].[job].[get_change]');

	
	select * from [repository].[get] (null, N'[chamomile].[job].[get_change]')

	select * from [repository_secure].[data] where [id] = N'B7F0AECE-810E-E411-A934-20689D66B6F7';



*/
create function [repository].[get] (
  @id     [uniqueidentifier]
  , @fqn [nvarchar](1000))
returns @data table (
  [id]            [uniqueidentifier] null
  , [entry]       [xml] null
  , [fqn]         [nvarchar](max)
  , [data]        [xml] null )
with schemabinding
as
  begin
      declare @filter [sysname] = (select [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
										data (/*/object[1]/meta_data/value)[1]', N'[nvarchar](max)')
         from   [repository_secure].[data]
         where  [entry].value(N'data (/*/object/meta_data/@fqn)[1]', N'[nvarchar](1000)') = N'[chamomile].[naming_convention].[default].[filter]');
      if @id is not null
        insert into @data
                    ([id],[entry],[fqn],[data])
          select [id]
                 , [entry]
                 , [fqn]
                 , [data]
          from   [repository].[get_list] (null, @fqn)
          where  [id] = @id;
      else
        insert into @data
                    ([id],[entry],[fqn],[data])
          select [id]
                 , [entry]
                 , [fqn]
                 , [data]
          from   [repository].[get_list] (null, @fqn)
          where  [fqn] = @fqn;
      return;
  end
go 
