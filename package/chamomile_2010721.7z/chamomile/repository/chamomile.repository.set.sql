use [chamomile];
go
if schema_id(N'repository') is null
  execute (N'create schema repository');
go
if object_id(N'[repository].[set]', N'P') is not null
  drop procedure [repository].[set];
go
/*
		   

declare @stack  xml ([utility].[xsc]) = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-07-08T08:42:19.17">
    <subject fqn="[utility].[xsc].[stack]">
      <description>{description of the subject  object.}</description>
    </subject>
    <object>
		<meta_data fqn="[chamomile].[test].[test_01]">
			<description>[chamomile].[test].[test_01]asfasadfasdfsxxxxxxxxxxxsfadfaa</description>
			<value>[chamomile].[test].[test_01]</value>
		</meta_data>
    </object>
  </chamomile:stack>'
        , @fqn [nvarchar](1000) = N'[chamomile].[test].[test_01]';


execute [repository].[set]
  @stack =@stack output;

select @stack as N'@stack output';

select *
from   [repository].[get_list] (null, N'[chamomile].[test].[test_01]'); 
select *
from   [repository].[get_list] (N'80B4C8AC-DF0D-E411-A934-20689D66B6F7', null);



	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	--
	-- to view documentation
	---------------------------------------------
	declare @schema   [sysname] = N'repository'
			, @object [sysname] = N'set';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
		   
	select * from   [repository].[get] (null, N'[chamomile].[job].[get_change]')
	execute [repository].[set]
	  @id       =N'77768C66-BF0E-E411-A934-20689D66B6F7'
	  , @delete = 1; 


*/
create procedure [repository].[set]
  @id       [uniqueidentifier] = null
  , @stack  xml = null output
  , @delete [bit] = 0
-- todo - with native_compilation, schemabinding, execute as owner
as
  begin
      set nocount on;
      declare @fqn                                [nvarchar](1000)
              , @invalid_parameter_list_prototype [nvarchar](1000)= N'[chamomile].[return_code].[invalid_parameter_list]'
              , @false_prototype                  [nvarchar](1000)=N'[chamomile].[boolean].[default].[false]';
      declare @builder               [xml]
              , @false               [sysname] = [utility].[get_meta_data](null, @false_prototype)
              , @timestamp           [sysname] = convert([sysname], current_timestamp, 126)
              , @object_fqn          [nvarchar](max)
              , @application_message [nvarchar](max)
              , @message             [nvarchar](max)
              , @subject_fqn         [nvarchar](1000)
              , @subject_description [nvarchar](1000)
              , @error_stack_builder [xml]
              , @return_code         [int]
              , @entry               xml([utility].[xsc]);
      declare @output as table (
        [action]  [sysname]
        , [id]    [uniqueidentifier]
        , [entry] [xml]
        );
      --
      ---------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @subject_fqn = @builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      set @subject_description = N'created by ' + @subject_fqn;
      --
      ---------------------------
      if @stack is null
         and @id is null
        begin
            set @message= N'@stack and @id both cannot be null values. Values can be retrieved from the repository either by [id] or @object_fqn.';
            raiserror (100068,1,1,@message);
            return 100068;
        end;
      --
      ---------------------------
      else if @stack is not null
        begin
            set @fqn = @stack.value(N'data(/*/object/*/@fqn)[1]', N'[nvarchar](1000)');
            set @stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
            set @stack.modify(N'replace value of (/*/subject/@fqn)[1] with sql:variable("@subject_fqn")');
            set @stack.modify(N'replace value of (/*/subject/description/text())[1] with sql:variable("@subject_description")');
        end;
      --
      ---------------------------
      set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
											replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');
      --
      ---------------------------
      if @delete = 1
        begin
            if @id is null
              begin
                  set @id=(select [id]
                           from   [repository].[get_list](null, @fqn)
                           where  [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/object[1]/data[1]/@fqn[1])[1]', N'nvarchar(max)') = @fqn
                                  and [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)') = @false)
                  delete from [repository_secure].[data]
                  where  [id] = @id;
              end;
            else
              begin
                  delete from [repository_secure].[data]
                  where  [id] = @id
                         and [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)') = @false;
              end;
        end;
      else
        begin
            if @id is not null
              begin
                  update [repository_secure].[data]
                  set    [entry] = @stack
                  where  [id] = @id;
              end;
            else
              begin
                  begin try
                      with [non_persistent]
                           as (select [id]
                                      , [entry]
                                      , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/object[1]/*[1]/@fqn[1])[1]', N'nvarchar(max)') as [name]
                                      , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/@persistent[1])[1]', N'nvarchar(max)')         as [persistent]
                               from   [repository_secure].[data])
                      merge into [non_persistent] as target
                      using (values (@id
                            , @fqn
                            , @stack
                            , @false)) as source ([id], [name], [entry], [persistent])
                      on target.[entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/*[1]/object[1]/*[1]/@fqn[1])[1]', N'nvarchar(max)') = source.[name]
                      --
                      ----------------------------------------------------------------
                      when matched and target.[persistent] = @false then
                        update set target.[entry] = source.[entry]
                      when not matched by target then
                        insert ([entry])
                        values (source.[entry])
                      output $action
                             , coalesce([inserted].[id], [deleted].[id])
                             , coalesce([inserted].[entry], [deleted].[entry])
                      into @output([action], [id], [entry]);
                  end try
                  begin catch
                      set @application_message=N'<application_message>error attempting to merge into repository</application_message>';
                      --
                      -----------------------------------
                      execute [utility].[handle_error]
                        @procedure_id         =@@procid
                        , @application_message=@application_message
                        , @stack              =@error_stack_builder output;
                      set @stack = @error_stack_builder;
                      --
                      -----------------------------------
                      return 1;
                  end catch;
              end;
            --
            ----------------------------------------------------------------
            set @id = coalesce((select [id]
                                from   @output
                                where  lower([action]) = N'insert'), (select [id]
                                                                      from   @output
                                                                      where  lower([action]) = N'update'), (select [id]
                                                                                                            from   @output
                                                                                                            where  lower([action]) = N'delete'));
            set @entry = @stack;
            set @entry.modify(N'declare namespace chamomile="http://www.katherinelightsey.com";
			insert attribute id {sql:variable("@id")} as last into (/*)[1]');
            set @stack = @entry;
        end;
  end;
go 
