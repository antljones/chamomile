
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		preload data into [repository_secure].[data].

*/
use [chamomile];

go

set nocount on;

go

delete from [repository_secure].[data];

go

set nocount on;

declare @stack         xml([utility].[xsc])
        , @subject_fqn [nvarchar](1000) = N'[chamomile].[repository_secure].[data].[load.sql]'
        , @subject_descripton [nvarchar](max) = N'Data pre-load script.'
        , @object_fqn  [nvarchar](1000)
        , @object_type [sysname]
        , @timestamp   [sysname] = convert([sysname], current_timestamp, 126)
        , @builder     [xml];

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<data fqn="[utility].[xsc].[stack].[prototype]" >
		<description>A prototype for the default stack.</description>
		<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="'+@timestamp+N'">
			<subject fqn="[utility].[xsc].[stack]" >
				<description>Description of subject</description>
			</subject>
			<object/>
			<result>
				<description>Description of result</description>
			</result>
		</chamomile:stack>
	</data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[html].[footer]" stale="false" timestamp="'+@timestamp+N'" >

		<html sequence="99"><![CDATA[
			</body>
				<p class="footer">All content is copyright <a href="http://www.katherinelightsey.com" target="blank">Katherine Elizabeth Lightsey</a> 1959-2014 (aka; my life), all rights reserved. All software contained herein is licensed as <a href="http://www.katherinelightsey.com/#!chamomile/c1pl">[chamomile]</a> and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html">GNU Affero GPL</a>.</p>
			</html>
		]]></html>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[html].[head]" stale="false" timestamp="'+@timestamp+N'" >

		<html sequence="1"><![CDATA[
			<!DOCTYPE html>
				<html>
					<head>
						<link rel="stylesheet" type="text/css" href="..\..\source\common.css" target="blank">
						<p class="header">built on <a href="http://www.katherinelightsey.com" target="blank">[chamomile]</a></p>
					</head>
					<body>
		]]></html>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[presentation].[regular_expressions]" stale="false" timestamp="'+@timestamp+N'" >

		<html sequence="1"><![CDATA[
			<body>
				<h1 class="chamomile"><a href="http://technet.microsoft.com/en-us/library/ms190215(v=sql.105).aspx">[regular_expressions]</a></h1>
				<img style="float: right;margin: 0 0 10px 0px;border: 1px solid #666;padding: 2px;" src="..\..\source\fairysoap.jpg" height="350" title="1910 Fairy Soap Ad ~ Child with Blocks" />
			</body>
		]]></html>

		<html sequence="2"><![CDATA[
			<body>
				<p><a href="http://www.freeformatter.com/regex-tester.html#examples">Regular Expression Tester</a></p>
				<p><a href="http://www.regular-expressions.info/xml.html">XML Schema Regular Expressions</a></p>
				<p><a href="http://msdn.microsoft.com/en-us/library/4edbef7e(v=vs.110).aspx">Character Escapes in Regular Expressions</a></p>
				<p><a href="http://www.regular-expressions.info/shorthand.html#xml">XML Character Classes</a></p>
			</body>
		]]></html>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[example]" stale="false" timestamp="'+@timestamp+N'" >

		<html sequence="1"><![CDATA[
				<h1 class="chamomile"><a href="http://technet.microsoft.com/en-us/library/ms190215(v=sql.105).aspx">[regular_expressions]</a></h1>
				<img style="float: right;margin: 0 0 10px 0px;border: 1px solid #666;padding: 2px;" src="..\..\source\fairysoap.jpg" height="350" title="1910 Fairy Soap Ad ~ Child with Blocks" />
		]]></html>
	

		<html  sequence="43"><![CDATA[
			<ol>
				<li>this is a list</li>
				<li>This is line 2</li>
			</ol>
		]]></html>
	

		<text sequence="12">
			Free text for next step goes here
		</text>

		<html sequence="22"><![CDATA[
				<p><a href="http://www.freeformatter.com/regex-tester.html#examples">Regular Expression Tester</a></p>
				<p><a href="http://www.regular-expressions.info/xml.html">XML Schema Regular Expressions</a></p>
				<p><a href="http://msdn.microsoft.com/en-us/library/4edbef7e(v=vs.110).aspx">Character Escapes in Regular Expressions</a></p>
				<p><a href="http://www.regular-expressions.info/shorthand.html#xml">XML Character Classes</a></p>
		]]></html>

		<text sequence="4">
			Free text for first step goes here
		</text>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
   
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[html].[example]" stale="false" timestamp="'+@timestamp+N'" >
	
		<html sequence="2"><![CDATA[
			<body>
				<p><a href="http://www.freeformatter.com/regex-tester.html#examples">Regular Expression Tester</a></p>
				<p><a href="http://www.regular-expressions.info/xml.html">XML Schema Regular Expressions</a></p>
				<p><a href="http://msdn.microsoft.com/en-us/library/4edbef7e(v=vs.110).aspx">Character Escapes in Regular Expressions</a></p>
				<p><a href="http://www.regular-expressions.info/shorthand.html#xml">XML Character Classes</a></p>
			</body>
		]]></html>

		<html sequence="1"><![CDATA[
			<body>
				<p>first stuff goes here</p>
			</body>
		]]></html>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
   
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[text].[example]" stale="false" timestamp="'+@timestamp+N'" >
	

		<text sequence="2">
			Free text for next step goes here
		</text>

		<text sequence="1">
			Free text for first step goes here
		</text>

	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[stack].[prototype]" stale="false" timestamp="'+@timestamp+N'" />
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[html].[prototype]" stale="false" timestamp="'+@timestamp+N'" >
		<html sequence="99" />
	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<documentation fqn="[chamomile].[documentation].[text].[prototype]" stale="false" timestamp="'+@timestamp+N'" >
		<text sequence="99" />
	</documentation>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<error_suite fqn="[chamomile].[error_suite].[stack].[prototype]" error_count="0" timestamp="'+@timestamp+N'" >	
		<description>prototype for [chamomile].[error_suite].[stack]</description>
	</error_suite>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
	
	
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<error_stack fqn="[chamomile].[error_stack].[stack].[prototype]" error_count="0" timestamp="'+@timestamp+N'" >
		<description>prototype for [chamomile].[error_stack].[stack]</description>
	</error_stack>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object >
	<error fqn="[chamomile].[error].[stack].[prototype]" schema="error_procedure_schema" procedure="error_procedure" error_number="0" error_line="0" error_severity="0" error_state="0" timestamp="'+@timestamp+N'">		
		<description>construct "error_message" is system generated; construct "application_message" is built by the application when it catches an error and before it calls [chamomile].[utility].[handle_error].</description>
		<error_message />
	</error>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object >
	<application_message fqn="[chamomile].[application_message].[prototype]" >
		<description />
	</application_message>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object >
	<workflow fqn="[chamomile].[workflow].[stack].[prototype]" >		
		<description>prototype for [chamomile].[workflow].[stack]</description>
	</workflow>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<command fqn="[chamomile].[command].[stack].[prototype]" timestamp="'+@timestamp+N'" >
		<description>prototype for [chamomile].[command].[stack]</description>
	</command>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<data fqn="[chamomile].[data].[stack].[prototype]" timestamp="'+@timestamp+N'" >
		<description>prototype for [chamomile].[data].[stack]</description>
	</data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
   
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<test_suite fqn="[chamomile].[test_suite].[stack].[prototype]" stack_count="0" test_count="0" error_count="0" pass_count="0" timestamp="'+@timestamp+N'" >	
		<description>prototype for [chamomile].[test].[test_suite]</description>
	</test_suite>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);
	
--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<test_stack fqn="[chamomile].[test_stack].[stack].[prototype]" test_count="0" error_count="0" pass_count="0" timestamp="'+@timestamp+N'" >
		<description>prototype for [chamomile].[test].[test_stack]</description>
	</test_stack>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<test sequence="1" fqn="[chamomile].[test].[stack].[prototype]" expected="pass" actual="fail" timestamp="'+@timestamp+N'" >
		<description>prototype for [chamomile].[test].[test]</description>
		<object fqn="[chamomile].[test].[stack].[object]">
			<description>prototype for [chamomile].[test].[test]</description>
		</object>
		<result fqn="[chamomile].[test].[stack].[result]">
			<description>prototype for [chamomile].[test].[test]</description>
		</result>
	</test>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack  = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="'+@timestamp+N'">
  <subject fqn="' + @subject_fqn + N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[meta_data].[stack].[prototype]" >
		<description>prototype for meta_data objects.</description>
		<value>value_1</value>
		<constraint>|value_1|value_2|</constraint>
	</meta_data>
  </object>
</chamomile:stack>';
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[test].[default].[suffix]" >
		<description>Default suffix for test schemas; for business schema [business_application_01] there should be a test schema [business_application_01_test].</description>
		<value>_test</value>
		<constraint>|_test|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[result].[default].[pass]">
		<description>Default text string to indicate "pass".</description>
		<value>pass</value>
		<constraint>|pass|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[result].[default].[fail]">
		<description>Default text string to indicate "fail".</description>
		<value>fail</value>
		<constraint>|fail|</constraint>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[naming_convention].[default].[filter]" >
		<description>Default filter used for [chamomile] object naming as passed through [utility].[all_string]; allowed values.</description>
		<value>a-z0-9._</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[test].[default].[test]">
		<description>Test type.</description>
		<value>test</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[boolean].[default].[true]">
		<description>true</description>
		<value>true</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[boolean].[default].[false]">
		<description>false</description>
		<value>false</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[utility].[handle_error].[description]">
		<description>default description for error stack.</description>
		<value>error stack built by [chamomile].[utility].[handle_error].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[description].[default].[lock_test].[stack_subject]">
		<description>default stack subject for [chamomile].[lock_test]</description>
		<value>Tests generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[description].[default].[lock_test].[stack_result]">
		<description>default stack result for [chamomile].[lock_test]</description>
		<value>Result of tests generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[description].[default].[lock_test].[workflow]">
		<description>default workflow description for [chamomile].[lock_test]</description>
		<value>Test workflow generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[description].[default].[lock_test].[command]">
		<description>default command description for [chamomile].[lock_test]</description>
		<value>Test command generated programmatically due to [chamomile].[lock_test].</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[documentation].[license]">
		<description>Short text version of the [chamomile] license.</description>
		<value>
			<![CDATA[
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer">
					All content and software is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
					Licensed as <a href="http://www.katherinelightsey.com/#!license/cjlz" target="blank">[chamomile]</a>
					 and as open source under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="blank">GNU Affero GPL</a>.
				</body>
			</html>
			]]>
		</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
set @stack=N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="true" timestamp="' + @timestamp + '">
  <subject fqn="'+@subject_fqn+N'" >
    <description>' + @subject_descripton + N'</description>
  </subject>
  <object>
	<meta_data fqn="[chamomile].[license].[documentation]">
		<description>Text automatically appended to the footer of documentation generated by [chamomile].[documentation]</description>
		<value>
			<![CDATA[
			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
				</head>
				<body class="footer_append">
					Documentation generated programmatically using <a href="http://www.katherinelightsey.com/#!documentation/cr08" target="blank">[chamomile].[documentation].
				</body>
			</html>
			]]>
		</value>
	</meta_data>
  </object>
</chamomile:stack>'
insert into [repository_secure].[data] ([entry]) values (@stack);

--
-- meta data - imlemented as system messages - (re: [chamomile].[presentation].[sp_addmessage] - http://www.katherinelightsey.com/#!spaddmessage/czpx)
--------------------------------------------------------------------------
--------------------------------------------------------------------------

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100066)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100066;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100066
  , @severity=11
  , @msgtext = N'[chamomile].[return_code].[data_not_found] - meta_data or prototype was not found for the value of [sys].[messages].[message_id] provided (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go

--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100067)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100067;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100067
  , @severity=11
  , @msgtext = N'[chamomile].[error].[existing_transaction] - unable to continue due to an existing transaction (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go


--
--------------------------------------------------------------------------
--------------------------------------------------------------------------
if exists
   (select *
    from   [sys].[messages]
    where  [message_id] = 100068)
  execute [dbo].[sp_dropmessage]
    @msgnum = 100068;
go
execute [dbo].[sp_addmessage]
  @msgnum    = 100068
  , @severity=11
  , @msgtext = N'[chamomile].[error].[invalid_parameter_list] - the parameter list as entered is not valid (%s). Additional information {if available} (%s).'
  , @lang    = null
  , @with_log=N'TRUE'
  , @replace ='replace';
go
