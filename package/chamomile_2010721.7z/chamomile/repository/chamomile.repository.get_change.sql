use [chamomile];

go

if object_id(N'[repository].[get_change]', N'P') is not null
  drop procedure [repository].[get_change];

go


/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

*/
create procedure [repository].[get_change]
as
  begin
      set transaction isolation level serializable;

      declare @change [xml];

      while (select count(*)
             from   [chamomile].[cdc].[repository_secure.data_CT])
            > 0
        begin
            begin transaction get_change;

			-- 
			-- todo - get standard records "__$..." then get all else as select *
			-- so the same "get_change" method can be used for all tables and will always
			-- get all columns.
			-------------------------------------
            set @change = (select top(100) [__$start_lsn]     as N'@start_lsn'
                                           , [__$end_lsn]     as N'@end_lsn'
                                           , [__$seqval]      as N'@seqval'
                                           , [__$operation]   as N'@operation'
                                           , [__$update_mask] as N'@update_mask'
                                           , [id]             as N'change/@id'
                                           , [entry]          as N'change/entry'
                           from   [chamomile].[cdc].[repository_secure.data_CT]
                           order  by [__$start_lsn] desc
                           for xml path(N'change'), root(N'change_batch'));

            if @change is not null
              insert into [chamomile_change].[repository_secure].[change]
                          ([change])
              values      (@change);

            with [delete_set]
                 as (select top(100) *
                     from   [cdc].[repository_secure.data_CT]
                     order  by [__$start_lsn] desc)
            delete from [delete_set];

            commit transaction get_change;
        end;
  end;

go


