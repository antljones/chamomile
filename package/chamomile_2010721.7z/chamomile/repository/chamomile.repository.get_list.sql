use [chamomile]
go
if schema_id(N'repository') is null
  execute (N'create schema repository');
go
if exists
   (select *
    from   sys.objects
    where  object_id = object_id(N'[repository].[get_list]')
           and type in ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  drop function [repository].[get_list];
go
set ansi_nulls on
go
set quoted_identifier on
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	select * from [repository].[get_list] (null, N'[chamomile].[naming_convention].[default].[filter]');
	
	select * from [repository].[get_list] (null, N'[chamomile].[result].[default]');
	
	select * from [repository].[get_list] (null, null);
	
select [id],[entry],[fqn],[category],[class],[type],[sub_type],[description],[data]
from   [repository].[get_list] (null, N'[utility].[xsc].[stack].[prototype]'); 

	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	All content is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
	licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'repository_secure'
			, @object [sysname] = N'get_list';

	select [schemas].[name]                as [schema]
		   , [objects].[name]              as [object]
		   , [extended_properties].[name]  as [property]
		   , [extended_properties].[value] as [value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 

*/
create function [repository].[get_list] (
  @id     [uniqueidentifier]
  , @fqn [nvarchar](1000))
returns @data table (
  [id]            [uniqueidentifier] null
  , [entry]       [xml] null
  , [fqn]         [nvarchar](max)
  , [data]        [xml] null )
with schemabinding
as
  begin
      declare @entry as table (
        [id]      [uniqueidentifier]
        , [entry] [xml]
        , [name]  [nvarchar](1000)
        );
      declare @filter [sysname] = (select [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
										data (/*/object[1]/meta_data/value)[1]', N'[nvarchar](max)')
         from   [repository_secure].[data]
         where  [entry].value(N'data (/*/object/meta_data/@fqn)[1]', N'[nvarchar](1000)') = N'[chamomile].[naming_convention].[default].[filter]');
      if @id is not null
        begin
            insert into @entry
                        ([id],[entry],[name])
              select [id]
                     , [entry]
                     , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
 							data(/*/object/*[1]/@fqn)[1]', '[nvarchar](max)')
              from   [repository_secure].[data]
              where  [id] = @id;
        end;
      else
        begin
            insert into @entry
                        ([id],[entry],[name])
              select [id]
                     , [entry]
                     , [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
 							data(/*/object/*[1]/@fqn)[1]', '[nvarchar](max)')
              from   [repository_secure].[data]
              where  ( [utility].[strip_string]([entry].value('data(/*/object/*/@fqn)[1]', N'[nvarchar](1000)'), @filter, null, null) like N'%'
                                                                                                                                            + [utility].[strip_string](@fqn, @filter, null, null)
                                                                                                                                            + N'%'
                        or @fqn is null );
        end;
      insert into @data
                  ([id],[entry],[fqn],[data])
        select [id]                                                                        as [id]
               , [entry]                                                                   as [entry]
               , [name]                                                                    as [fqn]
               , [entry].query(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
 							(/*/object/*[1])')                                                  as [data]
        from   @entry;
      return;
  end
go
--select [entry].value('(/*/object/meta_data/@fqn)[1]', N'[nvarchar](1000)') from [repository_secure].[data];
-- select [entry].query('local-name(/*[1]/object[1]/*[2])') from [repository_secure].[data];
