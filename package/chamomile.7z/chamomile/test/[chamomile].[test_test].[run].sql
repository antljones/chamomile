
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

*/
declare @stack xml([utility].[xsc])= N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-30T18:37:43.61">
    	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
    	  <object >
			<workflow xmlns:chamomile="http://www.katherinelightsey.com/" name="[computer_physical_netbios].[machine].[instance].[chamoile].[test].[run]" >
    				<command name="[repository_test].[get]" timestamp="2014-06-30T18:37:43.61"/>
					<command name="[repository_test].[set]" timestamp="2014-06-30T18:37:43.61"/>
    		</workflow>
    	  </object>
    	</chamomile:stack>';

execute [test].[run]
  @stack=@stack output;

select @stack as N'[test_suite]'; 
