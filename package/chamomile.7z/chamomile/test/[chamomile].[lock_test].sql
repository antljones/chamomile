/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
*/
use [chamomile];

go

if exists
   (select *
    from   sys.triggers
    where  parent_class = 0
           and name = 'lock_test')
  drop trigger [lock_test] on database;

go

create trigger [lock_test]
on database
after alter_function, drop_function, alter_procedure, drop_procedure, alter_table, drop_table
as
  begin
      --
      -- meta data prototypes
      ----------------------------------------------
      declare @workflow_stack_description_prototype  [nvarchar](1000)= N'[chamomile].[description].[default].[lock_test].[workflow]'
              , @command_stack_description_prototype [nvarchar](1000)= N'[chamomile].[description].[default].[lock_test].[command]'
              , @stack_subject_description_prototype [nvarchar](1000)= N'[chamomile].[description].[default].[lock_test].[stack_subject]'
              , @stack_result_description_prototype  [nvarchar](1000)= N'[chamomile].[description].[default].[lock_test].[stack_result]'
              , @workflow_stack_prototype            [nvarchar](1000)= N'[chamomile].[workflow].[stack].[prototype]'
              , @command_stack_prototype             [nvarchar](1000)= N'[chamomile].[command].[stack].[prototype]'
              , @utility_xsc_prototype               [nvarchar](1000)= N'[utility].[xsc].[stack].[prototype]';

      --
      -- meta data
      ----------------------------------------------
      declare @workflow_stack_description   [nvarchar](max) = [utility].[get_meta_data](@workflow_stack_description_prototype)
              , @command_stack_description  [nvarchar](max) = [utility].[get_meta_data](@command_stack_description_prototype)
              , @stack_subject_description  [nvarchar](max) = [utility].[get_meta_data](@stack_subject_description_prototype)
              , @stack_result_description   [nvarchar](max) = [utility].[get_meta_data](@stack_result_description_prototype)
              , @workflow_stack             [xml] = (select [data]
                 from   [repository].[get] (null, @workflow_stack_prototype))
              , @command_stack              [xml] = (select [data]
                 from   [repository].[get] (null, @command_stack_prototype))
              , @stack_builder              [xml] = (select [data].query(N'/*/*[2]')
                 from   [repository].[get](null, @utility_xsc_prototype))
              , @default_test_schema_suffix [sysname] = N'_test'

      --
      -- event data
      ----------------------------------------------
      declare @event_data [xml] = eventdata();

      declare @schema        [sysname] = @event_data.value(N'(/*/SchemaName/text())[1]', N'[sysname]')
              , @object      [sysname] = @event_data.value(N'(/*/ObjectName/text())[1]', N'[sysname]')
              , @object_type [sysname] = @event_data.value(N'(/*/ObjectType/text())[1]', N'[sysname]')
              --
              -- local variables
              ----------------------------------------------
              , @test_schema [sysname]
              , @test_object [nvarchar](1000)
              , @sql         [nvarchar](max)
              , @parameters  [nvarchar](max)
              , @stack       [xml]
              , @timestamp   [sysname] = convert([sysname], current_timestamp, 126);

      --
      ----------------------------------------------
      set @test_schema = @schema + @default_test_schema_suffix

      set @test_object = N'[' + @test_schema + N'].[' + @object + N']';

      if exists
         (select *
          from   [sys].[objects]
          where  object_schema_name([object_id]) = @test_schema
                 and name = @object)
        begin
            --
            ----------------------------------------------
            set @command_stack.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_object")');

            set @command_stack.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');

            set @command_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@command_stack_description")');

            --
            ----------------------------------------------
            set @workflow_stack.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_object")');

            set @workflow_stack.modify(N'insert sql:variable("@command_stack") as last into (/*)[1]');

            set @workflow_stack.modify(N'replace value of (/*/description/text())[1] with sql:variable("@workflow_stack_description")');

            --
            ----------------------------------------------
            set @stack_builder.modify(N'insert sql:variable("@workflow_stack") as last into (/*/object)[1]');

            set @stack_builder.modify(N'replace value of (/*/@timestamp)[1] with sql:variable("@timestamp")');

            set @stack_builder.modify(N'replace value of (/*/subject/description/text())[1] with sql:variable("@stack_subject_description")');

            set @stack_builder.modify(N'replace value of (/*/result/description/text())[1] with sql:variable("@stack_result_description")');

            select @stack_builder as N'before in trigger';

            execute [test].[run]
              @stack=@stack_builder output;

            set @stack_builder.modify(N'insert sql:variable("@stack") as last into (/*/result)[1]');

			select @stack_builder;
			--
			-- delete_me begin
			----------------------------------------------
            declare @variable [int];

            select @sql = N'execute [presentation_test].[trigger_test] @stack=@stack output'
                   , @parameters = N'@stack [xml] output';

            execute sp_executesql
              @sql         =@sql
              , @parameters=@parameters
              , @stack     =@stack output;

            set @variable = @stack.value(N'(/*/@variable)[1]', N'[int]');

            if @variable != 0
              rollback;
			----------------------------------------------
			-- delete_me end
			--
        end;
  end

go 
