/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		demonstrates the capability of a trigger to determine whether to allow an object to be modified
			based on the return value of a test.

		using this technique allows the creation of unbreakable code (http://www.katherinelightsey.com/#!unbreakablecode/c90f)
	--
	--	notes
	---------------------------------------------
		this presentation is designed to be run incrementally a code block at a time. 
		code blocks are delineated as:

		--
		-- code block begin
		-----------------------------------------
			<run code here>
		-----------------------------------------
		-- code block end
		--
	
	--
	-- references
	---------------------------------------------

*/
--
-- code block begin
-------------------------------------------------
use [chamomile];

go

if schema_id(N'presentation') is null
  execute (N'create schema presentation');

go

if schema_id(N'presentation_test') is null
  execute (N'create schema presentation_test');

go

if exists
   (select *
    from   sys.triggers
    where  parent_class = 0
           and name = 'test_trigger')
  drop trigger [test_trigger] on database;

go

-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
--
-- create test object
-------------------------------------------------
if object_id(N'[presentation_test].[trigger_test]', N'P') is not null
  drop procedure [presentation_test].[trigger_test];

go

create procedure [presentation_test].[trigger_test]
  @stack [xml] output
as
  begin
      set @stack= N'<stack name="['
                  + object_schema_name(@@procid) + N'].['
                  + object_name(@@procid)
                  + N']" variable="1" />'
  end;

go

-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
--
-- create business object
-------------------------------------------------
if object_id(N'[presentation].[trigger_test]', N'P') is not null
  drop procedure [presentation].[trigger_test];

go

create procedure [presentation].[trigger_test]
  @stack [xml] output
as
  begin
      select 1;
  end;

go

-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
if exists
   (select *
    from   sys.triggers
    where  parent_class = 0
           and name = 'test_trigger')
  drop trigger [test_trigger] on database;

go

--
-- create lock trigger
-------------------------------------------------
create trigger [test_trigger]
on database
after alter_function, drop_function, alter_procedure, drop_procedure, alter_table, drop_table
as
  begin
      declare @event_data [xml] = eventdata()

      declare @schema        [sysname] = @event_data.value(N'(/*/SchemaName/text())[1]', N'[sysname]')
              , @object      [sysname] = @event_data.value(N'(/*/ObjectName/text())[1]', N'[sysname]')
              , @object_type [sysname] = @event_data.value(N'(/*/ObjectType/text())[1]', N'[sysname]')
              , @stack       [xml]
              , @variable    [int]
              , @sql         [nvarchar](max) = N'execute [presentation_test].[trigger_test] @stack=@stack output'
              , @parameters  [nvarchar](max) = N'@stack [xml] output';

      execute sp_executesql
        @sql         =@sql
        , @parameters=@parameters
        , @stack     =@stack output;

      set @variable = @stack.value(N'(/*/@variable)[1]', N'[int]');

      if @variable != 0
        rollback;
  end;

go

-------------------------------------------------
-- code block end
--
--
-- code block begin
-------------------------------------------------
--
-- attempt to drop business object
-- select object_id(N'[presentation].[trigger_test]', N'P');
-------------------------------------------------
begin try
    if object_id(N'[presentation].[trigger_test]', N'P') is not null
      drop procedure [presentation].[trigger_test];
end try

begin catch
    select case when object_id(N'[presentation].[trigger_test]', N'P') is null then
                 N'Error! The object was dropped, but it should not have been!'
           else
                 N'The object was not dropped based on output from [presentation_test].[trigger_test]!'
           end as [exists];
end catch;

go
-------------------------------------------------
-- code block end
--
