use [master];

go

if object_id(N'[dbo].[sp_get_documentation]', N'P') is not null
  drop procedure [dbo].[sp_get_documentation];

go

/*
	declare @stack xml([utility].[xsc]), @return_code [int]
	execute @return_code = [dbo].[sp_get_documentation] @stack=@stack output;
	select @stack, @return_code;

	BCP "select [description] from [chamomile].[repository].[get] ('37AC1740-D106-E411-9BC2-005056A23D4E', null);" queryout master.documentation.html -t, -T -c -d master -S MCKDEVTSQL02;

	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------

	--
	-- Description
	----------------------------------------------------------------------
	title:			Accessor method for documentation of objects.
	filename:		chamomile.documentation.sp_get_documentation.sql
	description:	sp_get_documentation all properties for objects that meet conditions.

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'dbo'
			, @object [sysname] = N'sp_get_documentation';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
*/
create procedure [dbo].[sp_get_documentation]
  @stack xml = null output
as
  begin
      set nocount on;

      declare @schema              [sysname]
              , @object            [sysname]
              , @output            [nvarchar](max)
              , @property_value    [sysname]
              , @return_code       [int]
              , @message           [nvarchar](max)
              , @category          [sysname]
              , @timestamp         [sysname] = convert([sysname], current_timestamp, 121)
              , @property_name     [sysname]
              , @subject_fqn       [nvarchar](1000)
              , @object_fqn        [nvarchar](1000)
              , @object_type       [sysname]
              , @bcp_command       [nvarchar](max)
              , @builder           [xml]
              , @id                [uniqueidentifier]
              , @server            [nvarchar](1000)
              , @normalized_server [nvarchar](1000);
      declare @list as table (
        [database]       [sysname] null
        , [schema]       [sysname] null
        , [major_object] [sysname] null
        , [minor_object] [sysname] null
        , [html]         [nvarchar](max)
        );

      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;

      set @object_type = N'result';
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @normalized_server=@builder.value(N'(/*/normalized_server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      --
      -- head and style sheet
      ---------------------------------------------------------------------------------------------
      set @output = N'<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="..\..\source\common.css">
	</head>
	<body><h2>[' + db_name() + ']</h2>';
      --
      --------------------------------------------------------------------
      set @output = @output + N'<p class="footer">[' + db_name()
                    + '].[documentation]</p>'
                    + N'<p class="footer">[' + @timestamp + '</p>';

      --
      --------------------------------------------------------------
      delete from @list;

      with [database_documentation]
           as (select N'<tr><td>'
                      + cast([extended_properties].[name] as [sysname])
                      + N'</td><td>'
                      + cast([extended_properties].[value] as [nvarchar](max))
                      + N'</td></tr>' as [html]
               from   sys.fn_listextendedproperty(default, default, default, default, default, default, default) as [extended_properties])
      insert into @list
                  ([database],[schema],[major_object],[minor_object],[html])
        select db_name()
               , null
               , null
               , null
               , [html]
        from   [database_documentation];

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[database_documentation]</summary>';
          set @output = @output + '<br><table>';

          select @output = coalesce(@output, N' ', N'') + [html]
          from   @list
          where  [minor_object] is null
                  or len([minor_object]) < 1;

          set @output = @output + '</table></details>';
      end;

      --
      --------------------------------------------------------------
      delete from @list;

      with [table_documentation]
           as (select isnull([schemas].[name], N'')                as [schema]
                      , isnull([tables].[name], N'')               as [major_object]
                      , N''                                        as [minor_object]
                      , N''                                        as [type]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[tables] as [tables]
                      join [sys].[objects] as [objects]
                        on [objects].[object_id] = [tables].[object_id]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [tables].[schema_id]
                      join [sys].[columns] as [columns]
                        on [columns].[object_id] = [tables].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [tables].[object_id]
                                and [extended_properties].[minor_id] = 0
               union
               select isnull([schemas].[name], N'')                as [schema]
                      , isnull([tables].[name], N'')               as [major_object]
                      , isnull([object].[name], N'')               as [minor_object]
                      ,
                      --
                      case
                        --
                        when [types].[name] in ( N'nvarchar' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[max_length] / 2 as [sysname])
                              + N')' +
                              --
                              case when [object].[is_nullable] = 1 then N' null '
                              --
                              else N' not null '
                              --
                              end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'decimal' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[precision] as [sysname])
                              + N', '
                              + cast ([object].[scale] as [sysname]) + N')'
                              + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            --
                            when [types].[name] in ( N'varchar' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[max_length] as [sysname])
                              + N')' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'sysname' ) then
                              N'[' + [types].[name] + N']' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'xml' ) then
                              N'([' + [types].[name] + N'](['
                              + [xml_schemas].[name] + N'].['
                              + [xml_schema_collections].[name] + N'])' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end
                              +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                        --
                        else
                              N'[' + [types].[name] + N']' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                        --
                        end                                        as [type]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[tables] as [tables]
                      left join [sys].[schemas] as [schemas]
                             on [schemas].[schema_id] = [tables].[schema_id]
                      left join [sys].[columns] as [object]
                             on [object].[object_id] = [tables].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = [object].[column_id]
                      left join [sys].[types] as [types]
                             on [object].[user_type_id] = [types].[user_type_id]
                      left join [sys].[xml_schema_collections] as [xml_schema_collections]
                             on [xml_schema_collections].[xml_collection_id] = [object].[xml_collection_id]
                      left join [sys].[schemas] as [xml_schemas]
                             on [xml_schemas].[schema_id] = [xml_schema_collections].[schema_id]
                      left join [sys].[identity_columns] as [identity_columns]
                             on [identity_columns].[object_id] = [object].[object_id]
                                and [identity_columns].[column_id] = [object].[column_id])
      insert into @list
                  ([schema],[major_object],[minor_object],[html])
        select [schema]
               , [major_object]
               , [minor_object]
               , N'<tr>' + N'<td>[' + db_name() + N'].[' + [schema]
                 + N'].[' + [major_object] + N']'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + N'.[' + [minor_object] + N']</td>' else N'' end
                 --
                 + N'<td>'
                 + [property] + N'</td>' + N'<td>'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + [type] + N' ' else N'' end
                 --
                 + N' {'
                 + cast([value] as [nvarchar](max)) + N'}'
                 + N'</td>' + N'</tr>'
        from   [table_documentation]
        order  by [schema]
                  , [major_object]
                  , [minor_object];

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[table_documentation]</summary>';

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[table_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is null
                      or len([minor_object]) < 1;

              set @output = @output + '</table></details>';
          end;

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[column_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is not null
                     and len([minor_object]) > 0;

              set @output = @output + '</table></details>';
          end;

          set @output = @output + '</details>';
      end;

      --
      --------------------------------------------------------------
      delete from @list;

      with [view_documentation]
           as (select isnull([schemas].[name], N'')                as [schema]
                      , isnull([views].[name], N'')                as [major_object]
                      , N''                                        as [minor_object]
                      , N''                                        as [type]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[views] as [views]
                      join [sys].[objects] as [objects]
                        on [objects].[object_id] = [views].[object_id]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [views].[schema_id]
                      join [sys].[columns] as [columns]
                        on [columns].[object_id] = [views].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [views].[object_id]
                                and [extended_properties].[minor_id] = 0
               union
               select isnull([schemas].[name], N'')                as [schema]
                      , isnull([views].[name], N'')                as [major_object]
                      , isnull([object].[name], N'')               as [minor_object]
                      ,
                      --
                      case
                        --
                        when [types].[name] in ( N'nvarchar' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[max_length] / 2 as [sysname])
                              + N')' +
                              --
                              case when [object].[is_nullable] = 1 then N' null '
                              --
                              else N' not null '
                              --
                              end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'decimal' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[precision] as [sysname])
                              + N', '
                              + cast ([object].[scale] as [sysname]) + N')'
                              + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            --
                            when [types].[name] in ( N'varchar' ) then
                              N'[' + [types].[name] + N']' + N'('
                              + cast ([object].[max_length] as [sysname])
                              + N')' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'sysname' ) then
                              N'[' + [types].[name] + N']' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                            --
                            when [types].[name] in ( N'xml' ) then
                              N'([' + [types].[name] + N'](['
                              + [xml_schemas].[name] + N'].['
                              + [xml_schema_collections].[name] + N'])' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end
                              +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                        --
                        else
                              N'[' + [types].[name] + N']' + case when [object].[is_nullable] = 1 then N' null ' else N' not null ' end +
                              --
                              case
                              --
                              when [object].[is_identity] = 1 then N' identity(' + cast([identity_columns].[seed_value] as [sysname]) + N', ' + cast([identity_columns].[increment_value] as [sysname]) + N') '
                              --
                              else N''
                              --
                              end
                        --
                        end                                        as [type]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[views] as [views]
                      left join [sys].[schemas] as [schemas]
                             on [schemas].[schema_id] = [views].[schema_id]
                      left join [sys].[columns] as [object]
                             on [object].[object_id] = [views].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = [object].[column_id]
                      left join [sys].[types] as [types]
                             on [object].[user_type_id] = [types].[user_type_id]
                      left join [sys].[xml_schema_collections] as [xml_schema_collections]
                             on [xml_schema_collections].[xml_collection_id] = [object].[xml_collection_id]
                      left join [sys].[schemas] as [xml_schemas]
                             on [xml_schemas].[schema_id] = [xml_schema_collections].[schema_id]
                      left join [sys].[identity_columns] as [identity_columns]
                             on [identity_columns].[object_id] = [object].[object_id]
                                and [identity_columns].[column_id] = [object].[column_id])
      insert into @list
                  ([schema],[major_object],[minor_object],[html])
        select [schema]
               , [major_object]
               , [minor_object]
               , N'<tr>' + N'<td>[' + db_name() + N'].[' + [schema]
                 + N'].[' + [major_object] + N']'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + N'.[' + [minor_object] + N']</td>' else N'' end
                 --
                 + N'<td>'
                 + [property] + N'</td>' + N'<td>'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + [type] + N' ' else N'' end
                 --
                 + N' {'
                 + cast([value] as [nvarchar](max)) + N'}'
                 + N'</td>' + N'</tr>'
        from   [view_documentation]
        order  by [schema]
                  , [major_object]
                  , [minor_object];

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[view_documentation]</summary>';

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[view_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is null
                      or len([minor_object]) < 1;

              set @output = @output + '</table></details>';
          end;

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[column_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is not null
                     and len([minor_object]) > 0;

              set @output = @output + '</table></details>';
          end;

          set @output = @output + '</details>';
      end;

      --
      --------------------------------------------------------------
      delete from @list;
      
      with [xml_schema_collection_documentation]
           as (select [schemas].[name]                  as [schema]
                      , [xml_schema_collections].[name] as [major_object]
                      , [extended_properties].[name]    as [property]
                      , [extended_properties].[value]   as [value]
               from   [sys].[xml_schema_collections] as [xml_schema_collections]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [xml_schema_collections].[schema_id]
                      join [sys].[extended_properties] as [extended_properties]
                        on [extended_properties].[major_id] = [xml_schema_collections].[xml_collection_id])
      insert into @list
                  ([schema],[major_object],[html])
        select [schema]
               , [major_object]
               , N'<tr>' + N'<td>[' + db_name() + N'].[' + [schema]
                 + N'].[' + [major_object] + N']'
                 --
                 + N'<td>'
                 + [property] + N'</td>' + N'<td>'
                 --
                 + N' {'
                 + cast([value] as [nvarchar](max)) + N'}'
                 + N'</td>' + N'</tr>'
        from   [xml_schema_collection_documentation]
        order  by [schema]
                  , [major_object]; 

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[xml_schema_collection_documentation]</summary>';

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[xml_schema_collection_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is null
                      or len([minor_object]) < 1;

              set @output = @output + '</table></details>';
          end;

          set @output = @output + '</details>';
      end;

      --
      --------------------------------------------------------------
      delete from @list;

      with [procedure_documentation]
           as (select isnull([schemas].[name], N'')                as [schema]
                      , isnull([procedures].[name], N'')           as [object]
                      , N''                                        as [minor_object]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[procedures] as [procedures]
                      join [sys].[objects] as [objects]
                        on [objects].[object_id] = [procedures].[object_id]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [procedures].[schema_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [procedures].[object_id]
                                and [extended_properties].[minor_id] = 0
               union
               select isnull([schemas].[name], N'')                as [schema]
                      , isnull([procedures].[name], N'')           as [object]
                      , isnull([parameters].[name], N'')           as [minor_object]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[procedures] as [procedures]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [procedures].[schema_id]
                      join [sys].[parameters] as [parameters]
                        on [parameters].[object_id] = [procedures].[object_id]
                      join [sys].[types] as [types]
                        on [types].[user_type_id] = [parameters].[user_type_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [parameters].[object_id]
                                and [extended_properties].[minor_id] = [parameters].[parameter_id])
      insert into @list
                  ([minor_object],[html])
        select [minor_object]
               , N'<tr>' + N'<td>[' + db_name() + N'].[' + [schema]
                 + N'].[' + [object] + N']'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + N'.[' + [minor_object] + N']</td>' else N'' end
                 --
                 + N'<td>' + [property]
                 + N'</td>' + N'<td>'
                 + cast([value] as [nvarchar](max))
                 + N'</td>' + N'</tr>'
        from   [procedure_documentation];

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[procedure_documentation]</summary>';

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[procedure_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is null
                      or len([minor_object]) < 1;

              set @output = @output + '</table></details>';
          end;

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[parameter_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is not null
                     and len([minor_object]) > 0;

              set @output = @output + '</table></details>';
          end;

          set @output = @output + '</details>';
      end;

      --
      --------------------------------------------------------------
      delete from @list;

      with [function_documentation]
           as (select isnull([schemas].[name], N'')                as [schema]
                      , isnull([object].[name], N'')               as [object]
                      , N''                                        as [minor_object]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[objects] as [object]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [object].[schema_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = 0
               where  [object].[type_desc] like N'%fun%'
               union
               select isnull([schemas].[name], N'')                as [schema]
                      , isnull([object].[name], N'')               as [object]
                      , isnull([parameters].[name], N'')           as [minor_object]
                      , isnull([extended_properties].[name], N'')  as [property]
                      , isnull([extended_properties].[value], N'') as [value]
               from   [sys].[objects] as [object]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [object].[schema_id]
                      join [sys].[parameters] as [parameters]
                        on [parameters].[object_id] = [object].[object_id]
                      join [sys].[types] as [types]
                        on [types].[user_type_id] = [parameters].[user_type_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = [parameters].[parameter_id]
               where  [object].[type_desc] like N'%fun%'
                      and [parameters].[parameter_id] != 0)
      insert into @list
                  ([minor_object],[html])
        select [minor_object]
               , N'<tr>' + N'<td>[' + db_name() + N'].[' + [schema]
                 + N'].[' + [object] + N']'
                 --
                 + case when [minor_object] is not null and len([minor_object]) > 0 then + N'.[' + [minor_object] + N']</td>' else N'' end
                 --
                 + N'<td>' + [property]
                 + N'</td>' + N'<td>'
                 + cast([value] as [nvarchar](max))
                 + N'</td>' + N'</tr>'
        from   [function_documentation];

      begin
          set @output = @output
                        + '<br><details class="summary"><summary>[function_documentation]</summary>';

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[function_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is null
                      or len([minor_object]) < 1;

              set @output = @output + '</table></details>';
          end;

          begin
              set @output = @output
                            + '<br><details class="summary"><summary>[parameter_properties]</summary><table>';

              select @output = coalesce(@output, N' ', N'') + [html]
              from   @list
              where  [minor_object] is not null
                     and len([minor_object]) > 0;

              set @output = @output + '</table></details>';
          end;

          set @output = @output + '</details>';
      end;

      --
      --------------------------------------------------------------
      set @output = @output + N'</table>';
      --
      -- documentation
      ---------------------------------------------------------------------------------------------
      set @category = N'[documentation]';
      set @output = @output + N'<br>'
                    + [chamomile].[utility].[get_meta_data](N'[chamomile].[license]')
                    + [chamomile].[utility].[get_meta_data](N'[chamomile].[license].[documentation]')
                    + '</body></html>';

      --
      -- load documentation into repository and create bcp extraction command
      --------------------------------------------------------------------------
      select @schema = N'dbo'
             , @object = N'sp_get_documentation';

      set @object_fqn = N'[' + db_name() + N'].[' + @schema + N'].[' + @object
                        + N']';
      set @builder = null;

      execute [chamomile].[utility].[set_meta_data]
        @name         =@object_fqn
        , @value      =N'result'
        , @description=@output
        , @stack      =@builder output;

      set @id = @builder.value(N'(/*/@id)[1]', N'[uniqueidentifier]')
      set @bcp_command = N'BCP "select [description] from [chamomile].[repository].[get] ('''
                         + cast(@id as [sysname])
                         + N''', null);" queryout ' + db_name()
                         + N'.documentation.html -t, -T -c -d '
                         + db_name() + N' -S ' + @server + N';';
      set @stack = @builder;

      select @bcp_command as N'bcp command'
             , @output    as N'@output; may be truncated.';
  end

go

exec [sp_MS_marksystemobject]
  N'sp_get_documentation';

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'todo', N'SCHEMA', N'dbo', N'procedure', N'sp_get_documentation', default, default))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'procedure'
    , @level1name=N'sp_get_documentation'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<ol>
		<li>todo - use minor id to pick up columns and parameters.</li>
		<li>include "execute [repository].[set] @id=@id, @delete=1" in bcp command.</li>
	</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'procedure'
  , @level1name=N'sp_get_documentation'
  , @level2type=null
  , @level2name=null;

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'dbo', N'procedure', N'sp_get_documentation', default, default))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'procedure'
    , @level1name=N'sp_get_documentation'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N'[chamomile].[license]');'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'procedure'
  , @level1name=N'sp_get_documentation'
  , @level2type=null
  , @level2name=null;

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_documentation', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_documentation'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'<ol>
	<li>Add database and schema.</li>
  </ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_documentation'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_documentation', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_documentation'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'select text of [bcp command] output and execute in command window. The extended properties are copied	to a file as named in the bcp command.
	<hr>
	<div><span style="font-family: Courier New; font-size: 10pt;">
<span style="color: blue; ">use</span>&nbsp;<span style="color: maroon; ">[chamomile]</span><span style="color: silver; ">;</span>
<br/>
<br/><span style="color: maroon; ">go</span>
<br/>
<br/><span style="color: blue; ">declare</span>&nbsp;<span style="color: #8000FF; ">@stack</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color: black; font-style: italic; ">xml</span><span style="color: maroon; ">(</span><span style="color: maroon; ">[utility]</span><span style="color: silver; ">.</span><span style="color: maroon; ">[xsc]</span><span style="color: maroon; ">)</span>
<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color: silver; ">,</span>&nbsp;<span style="color: #8000FF; ">@return_code</span>&nbsp;<span style="color: black; font-style: italic; ">[int]</span>
<br/>
<br/><span style="color: blue; ">execute</span>&nbsp;<span style="color: #8000FF; ">@return_code</span>&nbsp;<span style="color: silver; ">=</span>&nbsp;<span style="color: maroon; ">[dbo]</span><span style="color: silver; ">.</span><span style="color: #FF0080; font-weight: bold; ">[sp_get_documentation]</span>
<br/>&nbsp;&nbsp;<span style="color: #8000FF; ">@stack</span><span style="color: silver; ">=</span><span style="color: #8000FF; ">@stack</span>&nbsp;<span style="color: maroon; ">output</span><span style="color: silver; ">;</span>
<br/>
<br/><span style="color: blue; ">select</span>&nbsp;<span style="color: #8000FF; ">@stack</span>
<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color: silver; ">,</span>&nbsp;<span style="color: #8000FF; ">@return_code</span><span style="color: silver; ">;</span>&nbsp;
</span></div>
	'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_documentation'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140706', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_documentation', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140706'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_documentation'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140706'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_documentation'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_basic', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_documentation', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_documentation'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_documentation'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'release_00.92.00', N'SCHEMA', N'dbo', N'PROCEDURE', N'sp_get_documentation', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'release_00.92.00'
    , @level0type=N'SCHEMA'
    , @level0name=N'dbo'
    , @level1type=N'PROCEDURE'
    , @level1name=N'sp_get_documentation'

go

exec sys.sp_addextendedproperty
  @name        =N'release_00.92.00'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'dbo'
  , @level1type=N'PROCEDURE'
  , @level1name=N'sp_get_documentation'

go 
