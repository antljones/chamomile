
if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'replace_schema'
                                            , N'PROCEDURE'
                                            , N'replace_method'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'replace_schema'
    , @level1type=N'PROCEDURE'
    , @level1name=N'replace_method'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'replace_schema'
  , @level1type=N'PROCEDURE'
  , @level1name=N'replace_method'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'replace_schema'
                                            , N'PROCEDURE'
                                            , N'replace_method'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'replace_schema'
    , @level1type=N'PROCEDURE'
    , @level1name=N'replace_method'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'replace_schema'
  , @level1type=N'PROCEDURE'
  , @level1name=N'replace_method'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'replace_schema'
                                            , N'PROCEDURE'
                                            , N'replace_method'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'replace_schema'
    , @level1type=N'PROCEDURE'
    , @level1name=N'replace_method'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'replace_schema'
  , @level1type=N'PROCEDURE'
  , @level1name=N'replace_method'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'replace_schema'
                                            , N'PROCEDURE'
                                            , N'replace_method'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'replace_schema'
    , @level1type=N'PROCEDURE'
    , @level1name=N'replace_method'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'replace_schema'
  , @level1type=N'PROCEDURE'
  , @level1name=N'replace_method'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'replace_schema'
                                            , N'PROCEDURE'
                                            , N'replace_method'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'replace_schema'
    , @level1type=N'PROCEDURE'
    , @level1name=N'replace_method'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'replace_schema'
  , @level1type=N'PROCEDURE'
  , @level1name=N'replace_method'

go