use [chamomile];
go
if object_id(N'[documentation].[get_job_list]', N'P') is not null
  drop procedure [documentation].[get_job_list];
go
/*
	declare @timestamp [sysname] = convert([sysname], current_timestamp, 126), @documentation [nvarchar](max), @bcp_command [nvarchar](max);
	declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
			<subject fqn="[chamomile].[documentation].[get_job_list]">
				<description>workflow for getting job documentation</description>
			</subject>
			<object>
				<workflow fqn="[chamomile].[workflow].[get_job_list]" >		
					<description>get documentation for all jobs.</description>
					<command fqn="[all]" timestamp="' + @timestamp + N'" >
						<description>get documentation for job.</description>
					</command>
				</workflow>
			</object>
		</chamomile:stack>';
	execute [documentation].[get_job_list] @stack = @stack, @status="force_refresh", @bcp_command=@bcp_command output, @documentation = @documentation output;
	select @bcp_command;
go

declare @timestamp [sysname] = convert([sysname], current_timestamp, 126);
declare @stack xml = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" persistent="false" timestamp="2014-07-18T13:56:57.76">
		<subject fqn="[chamomile].[documentation].[get_job_list]">
			<description>workflow for getting job documentation</description>
		</subject>
		<object>
			<workflow fqn="[chamomile].[workflow].[get_job_list]" >		
				<description>get documentation for listed jobs.</description>
				<command fqn="[chamomile].[get_change]" timestamp="' + @timestamp + N'" >
					<description>get documentation for job.</description>
				</command>
				<command fqn="[chamomile].[cdc.chamomile_cleanup]" timestamp="' + @timestamp + N'" >
					<description>get documentation for job.</description>
				</command>
			</workflow>
		</object>
	</chamomile:stack>'
	select [documentation].[get_job_list](@stack); 
go
*/
create procedure [documentation].[get_job_list]
  @stack           [xml]
  , @status        [sysname]= N'allow_stale'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @job_name          [nvarchar](max)
              , @subject_fqn     [nvarchar](max)
              , @server          [sysname]
              , @start                   [datetime] = current_timestamp
              , @elapsed            [decimal](9, 4)
              , @object_fqn      [nvarchar](max) = N'[chamomile].[documentation].[get_job_list]'
              , @builder         [xml]
              , @stack_prototype [xml] = [utility].[get_prototype](N'[utility].[xsc].[stack].[prototype]');
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      --
      ------------------------------------------------
      if @stack.value(N'(/*/object/workflow/command/@fqn)[1]', N'[sysname]') = N'[all]'
        declare job_cursor cursor for
          select N'[chamomile].[' + [name] + N']'
          from   [msdb].[dbo].[sysjobs] as [sysjobs];
      else if @stack is not null
        declare job_cursor cursor for
          select t.c.value(N'./@fqn', N'[nvarchar](max)') as [job]
          from   @stack.nodes(N'/*/object/workflow/command') as t(c);
      begin
          open job_cursor
          fetch next from job_cursor into @job_name;
          while @@fetch_status = 0
            if @job_name is not null
              begin
                  set @documentation = coalesce(@documentation, N' ', N'')
                                       + [documentation].[get_job](@job_name);
                  fetch next from job_cursor into @job_name;
              end;
          close job_cursor;
          deallocate job_cursor;
      end;
      --
      -------------------------------------------	
      set @documentation = N'<details><summary>job list</summary>'
                           + @documentation + N'</details>';
      execute [chamomile].[documentation].[set]
        @object_fqn      =@object_fqn
        , @documentation =@documentation
        , @type          = N'html'
        , @sequence      = 1
        , @stack         = @stack output;
      set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                         + @object_fqn + N'''));" queryout '
                         + @object_fqn + '.html -t, -T -c -d '
                         + db_name() + N' -S ' + @server + N';';
  end;
go 
