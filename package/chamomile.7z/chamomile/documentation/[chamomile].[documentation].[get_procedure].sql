use [chamomile];
go
if object_id(N'[documentation].[get_procedure]', N'P') is not null
  drop procedure [documentation].[get_procedure];
go
/*
	declare @documentation [nvarchar](max), @bcp_command [nvarchar](max);
    execute [documentation].[get_procedure]
      @object_fqn     = N'[chamomile].[documentation].[get_procedure_list]'
      , @status       = N'force_refresh'
      , @output_as    = N'html'
      , @bcp_command  =@bcp_command output
      , @documentation=@documentation output;
    select @bcp_command as N'@bcp_command', @documentation as N'@documentation'; 
    
*/
create procedure [documentation].[get_procedure]
  @object_fqn      [sysname]
  , @status        [sysname]= N'allow_stale'
  , @output_as     [sysname] = N'html'
  , @bcp_command   [nvarchar](max) = null output
  , @documentation [nvarchar](max) output
as
  begin
      declare @procedure_details         [nvarchar](max)
              , @extended_properties     [nvarchar](max)
              , @stale                   [sysname]
              , @stack                   [xml]
              , @timestamp               [sysname] = convert([sysname], current_timestamp, 126)
              , @builder                 [xml]
              , @subject_fqn             [nvarchar](max)
              , @server                  [sysname]
              , @parameter_documentation [nvarchar](max)
              , @start                   [datetime] = current_timestamp
              , @elapsed            [decimal](9, 4)
              , @schema                  [sysname] = parsename(@object_fqn, 2)
              , @object                  [sysname] = parsename(@object_fqn, 1);
      --
      ------------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@builder output;
      set @server=@builder.value(N'(/*/server/@name)[1]', N'[nvarchar](1000)');
      set @subject_fqn=@builder.value(N'(/*/fqn/@fqn)[1]', N'[nvarchar](1000)');
      --
      -------------------------------------------
      select @documentation = [documentation].[get](@object_fqn)
             , @stale = [entry].value(N'(/*/object/documentation/@stale)[1]', N'[sysname]')
      from   [documentation].[get_list](@object_fqn);
      if @documentation is null
          or ( @stale = N'true'
               and @status != N'allow_stale' )
          or ( @stale = N'false'
               and @status = N'force_refresh' )
        begin
            --
            -------------------------------------------
            begin
                select @procedure_details = N'<procedure_details><div id="seventh_indent"><details><summary>procedure details</summary><ol><li>object_id {'
                                            + cast([object_id] as [sysname]) + N'}</li>'
                                            + N'<li>created {'
                                            + cast([create_date] as [sysname])
                                            + N'}</li>' + N'<li>modified {'
                                            + cast([modify_date] as [sysname])
                                            + N'}</li></ol></details></div></procedure_details>'
                from   [sys].[objects] as [objects]
                       left join [sys].[extended_properties] as [extended_properties]
                              on [extended_properties].[major_id] = [objects].[object_id]
                                 and [extended_properties].[class] = 1
                where  object_schema_name([objects].[object_id]) = @schema
                       and [objects].[name] = @object
                       and [objects].[type] in ( N'P' );
            end;
            --
            -------------------------------------------
            begin
                select @parameter_documentation = coalesce(@parameter_documentation, N' ', N'')
                                                  + N'<li><name>' + case
                                                  --
                                                  when [parameters].[name] is null or len([parameters].[name]) = 0then N'{returns} ' else [parameters].[name] end
                                                  --
                                                  + case
                                                  --
                                                  when type_name([parameters].[user_type_id]) like N'n%' and [parameters].[max_length]=-1 then N' [' + type_name([parameters].[user_type_id]) + N'](max)'
                                                  --
                                                  when type_name([parameters].[user_type_id]) like N'n%' then N' [' + type_name([parameters].[user_type_id]) + N'](' + cast ([parameters].[max_length]/2 as [sysname]) + N')'
                                                  --
                                                  else N' [' + type_name([parameters].[user_type_id]) + N']'
                                                  --
                                                  end + N'</name>'
                                                  + isnull(N' - <property>' + cast([extended_properties].[name] as [sysname]) + N'</property> <description>' + isnull(N'{' + cast([extended_properties].[value] as [nvarchar](max)) + N'}', N'') + N'</description>', N'')
                                                  + N'</li>'
                from   [sys].[parameters] as [parameters]
                       join [sys].[objects] as [objects]
                         on [objects].[object_id] = [parameters].[object_id]
                       left join [sys].[extended_properties] as [extended_properties]
                              on [extended_properties].[major_id] = [objects].[object_id]
                                 and [extended_properties].[class] != 1
                where  object_schema_name([objects].[object_id]) = @schema
                       and [objects].[name] = @object
                       and [objects].[type] in ( N'P' );
                select @parameter_documentation = N'<parameter_documentation><div id="seventh_indent"><details><summary>parameter documentation</summary><ol>'
                                                  + @parameter_documentation
                                                  + N'</ol></details></div></parameter_documentation>';
            end;
            --
            -------------------------------------------
            begin
                select @extended_properties = coalesce(@extended_properties, N' ', N'')
                                              + isnull(N'<li>' + cast([extended_properties].[name] as [sysname]) + N' {' + isnull(cast([extended_properties].[value] as [nvarchar](max)), N'') + N'}' + N'</li>', N'')
                from   [sys].[objects] as [objects]
                       left join [sys].[extended_properties] as [extended_properties]
                              on [extended_properties].[major_id] = [objects].[object_id]
                                 and [extended_properties].[class] = 1
                where  object_schema_name([objects].[object_id]) = @schema
                       and [objects].[name] = @object
                       and [objects].[type] in ( N'P' );
                select @extended_properties = N'<extended_properties><div id="seventh_indent"><details><summary>procedure documentation</summary><ol>'
                                              + @extended_properties
                                              + N'</ol></details></div></extended_properties>';
            end;
            --
            -------------------------------------------
            select @elapsed = cast(466000 / cast(1000000 as [decimal](9, 0)) as [decimal](9, 4));
            set @documentation = N'<procedure_documentation><div id="sixth_indent"><details><summary>'
                                 + @object_fqn + + N'</summary><ol>'
                                 + isnull(@extended_properties, N'')
                                 + isnull(@procedure_details, N'')
                                 + isnull(@parameter_documentation, N'')
                           --
                           + N'<p class="timestamp">built by {'
                           + @subject_fqn + N'} timestamp {' + @timestamp
                           + N'} elapsed_time(s) {'
                           + cast(@elapsed as [sysname])
                           + N'}</p>'
                                 + N'</ol></details></div></procedure_documentation>';
            --
            -------------------------------------------		 
            execute [chamomile].[documentation].[set]
              @object_fqn      =@object_fqn
              , @documentation =@documentation
              , @type          = N'html'
              , @sequence      = 1
              , @stack         = @stack output;
        end;
      --
      -------------------------------------------
      if @output_as = N'html'
        set @bcp_command = N'BCP "select [documentation].[get_formatted_html]([documentation].[get] ('''
                           + @object_fqn + N'''));" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
      else if @output_as = N'xml'
        set @bcp_command = N'BCP "select [documentation].[get] ('''
                           + @object_fqn + N''');" queryout '
                           + @subject_fqn + '.' + @output_as
                           + N' -t, -T -c -d ' + db_name() + N' -S ' + @server
                           + N';';
  end;
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'license', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure'
go
exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [utility].[get_meta_data](N''[chamomile].[license]'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'execute_as', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure'
go
exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140719', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140719'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure'
go
exec sys.sp_addextendedproperty
  @name        =N'revision_20140719'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure'
go
if exists
   (select *
    from   ::fn_listextendedproperty(N'package_chamomile_basic', N'SCHEMA', N'documentation', N'PROCEDURE', N'get_procedure', null, null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get_procedure'
go
exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get_procedure'
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure', default, default))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure'
    , @level2type = null
    , @level2name =null;
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'Builds documentation.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure'
  , @level2type = null
  , @level2name =null;
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure'
    , @level2type = N'parameter'
    , @level2name =N'@documentation';
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'@status [sysname]= N''allow_stale'' - defaults to ''allow_stale''; default behavior is to accept and retrieve stale documentation. If ''force_refresh'' the documentation will be regenerated regardless of the stale state. If ''require_current'' stale documentation will be refreshed.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure'
  , @level2type = N'parameter'
  , @level2name =N'@documentation';
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure', N'parameter', N'@documentation'))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure'
    , @level2type = N'parameter'
    , @level2name =N'@documentation';
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'@documentation [nvarchar](max) output - will contain the output of the procedure.'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure'
  , @level2type = N'parameter'
  , @level2name =N'@documentation';
go
if exists
   (select *
    from   fn_listextendedproperty(N'description', N'schema', N'documentation', N'procedure', N'get_procedure', N'parameter', N'@object_fqn'))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'schema'
    , @level0name = N'documentation'
    , @level1type = N'procedure'
    , @level1name = N'get_procedure'
    , @level2type = N'parameter'
    , @level2name =N'@object_fqn';
exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'@object_fqn [sysname] - the fully qualified name of the procedure for which to retrieve or generate documentation as [{database}].[{schema}].[{object}]'
  , @level0type = N'schema'
  , @level0name = N'documentation'
  , @level1type = N'procedure'
  , @level1name = N'get_procedure'
  , @level2type = N'parameter'
  , @level2name =N'@object_fqn';
go 
