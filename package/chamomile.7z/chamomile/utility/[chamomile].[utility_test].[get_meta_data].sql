/*

*/
declare @application_message [xml]
        , @builder           [xml]
        , @error_stack       [xml]
        , @sql_major_version [int]
        , @pass              [sysname]
        , @message           [nvarchar](2048)
        , @optional_message  [nvarchar](2048)
        , @parameters        [nvarchar](max)
        , @subject_fqn       [nvarchar](100)
        , @test              [xml];
declare @return_code                      [int] = null
        , @application_message_prototype  [nvarchar](1000) = N'[chamomile].[application_message].[prototype]'
        , @test_prototype                 [nvarchar](1000)= N'[chamomile].[test].[stack].[prototype]'
        , @prototype_not_found_prototype  [nvarchar](1000)= N'[chamomile].[return_code].[prototype_not_found]'
        , @message_id_meta_data_not_found [int]= 100065
        , @message_id_does_not_exist      [int] = 2000000000
        , @pass_meta_data_prototype       [nvarchar](1000)= N'[chamomile].[result].[default].[pass]'
        , @null_prototype                 [nvarchar](1000) = null
        , @null_meta_data                 [nvarchar](1000) = null
        , @section                        [sysname]
        , @sql_to_return                  [nvarchar](max) = N'raiserror (@message,1,1);';
--
-------------------------------------------
execute [dbo].[sp_get_server_information]
  @procedure_id=@@procid
  , @stack     =@builder output;
set @sql_major_version = @builder.value(N'(/*/complete/@major_version)[1]', N'[int]');
--
-- validate meta data variables
-------------------------------------------------
begin
    begin try
        select @section = N'validating meta data'
               , @return_code = null
               , @null_meta_data = null
               , @optional_message = N'section="' + @section + N'"';
        --
		-- @message_id_does_not_exist
        ---------------------------------------------
        select @return_code = [message_id]
               , @message = [text]
        from   [sys].[messages]
        where  [message_id] = @message_id_does_not_exist;
        --
        --
        if @return_code is null
          set @null_meta_data = @message_id_meta_data_not_found;
        --
		-- @pass_meta_data_prototype
        ---------------------------------------------
        set @pass = [utility].[get_meta_data](@pass_meta_data_prototype)
        if @pass is null
          set @null_meta_data = @pass_meta_data_prototype;
        --
        ---------------------------------------------
        if @null_meta_data is not null
          begin
              set @message =FORMATMESSAGE(@message_id_meta_data_not_found, cast(@message_id_does_not_exist as [sysname]), @optional_message);
              if @sql_major_version < 12
                execute sp_executesql
                  @sql=@sql_to_return;
              else
                -- todo - add system messages
                throw 51000, @return_code, 1;
          end;
    end try
    begin catch
        if @application_message is null
          set @application_message = isnull(@application_message, N'<application_message><description>'
                                                                  + @message
                                                                  + N'</description></application_message>');
        else
          set @application_message.modify(N'insert text {sql:variable("@message")} as last into (/*/description)[1]');
        execute [utility].[handle_error]
          @stack                 = @error_stack output
          , @procedure_id        =@@procid
          , @application_message =@application_message;
        select @error_stack   as N'@error_stack'
               , @return_code as N'@return_code';
    end catch;
end;
--
-- validate prototype variables
-------------------------------------------------
begin
    begin try
        select @null_prototype = null
               , @return_code = [data]
               , @message = [description]
        from   [utility].[get_meta_data_list](@prototype_not_found_prototype);
        --
        ---------------------------------------------
        set @application_message = (select [data]
                                    from   [repository].[get] (null, @application_message_prototype));
        if @application_message is null
          set @null_prototype = @application_message_prototype;
        --
        ---------------------------------------------
        set @test = (select [data]
                     from   [repository].[get] (null, @test_prototype));
        if @test is null
          set @null_prototype = @test_prototype;
        --
        ---------------------------------------------
        if @null_prototype is not null
          begin
              set @message = @message + @null_prototype;
              if @sql_major_version < 12
                execute sp_executesql
                  @sql=@sql_to_return;
              else
                throw 51000, @return_code, 1;
          end;
    end try
    begin catch
        if @application_message is null
          set @application_message = isnull(@application_message, N'<application_message><description>'
                                                                  + @message
                                                                  + N'</description></application_message>');
        else
          set @application_message.modify(N'insert text {sql:variable("@message")} as last into (/*/description)[1]');
        execute [utility].[handle_error]
          @stack                 = @error_stack output
          , @procedure_id        =@@procid
          , @application_message =@application_message;
        select @error_stack   as N'@error_stack'
               , @return_code as N'@return_code';
    end catch;
end; 
