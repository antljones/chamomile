use [chamomile];
go
if schema_id(N'utility') is null
  execute(N'create schema utility');
go
if object_id(N'[utility].[get_meta_data]', N'FN') is not null
  drop function [utility].[get_meta_data];
go
/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------


	select [utility].[get_meta_data](N'[chamomile].[boolean].[default].[false]');
	select [utility].[get_meta_data](N'[chamomile].[return_code].[code_65]');


	select [utility].[get_meta_data](N'64058A26-0DC5-497B-B512-4C4EE1F071F0', null);
	select [utility].[get_meta_data](null, N'[chamomile].[documentation].[job].[get_change]');
*/
create function [utility].[get_meta_data] (
  @id     [sysname]
  , @fqn [nvarchar](1000))
returns [nvarchar](max)
as
  begin
      declare @value [nvarchar](max);
      set @value = (select [data].value(N'(/*/value/text())[1]', N'[nvarchar](max)')
                    from   [repository].[get] (@id, @fqn));
      return @value;
  end
go 
