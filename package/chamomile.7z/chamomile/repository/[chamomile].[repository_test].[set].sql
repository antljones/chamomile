use [chamomile];

go

if schema_id(N'repository_test') is null
  execute (N'create schema repository_test');

go

if object_id(N'[repository_test].[set]', N'P') is not null
  drop procedure [repository_test].[set];

go

/*
	All content is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and 
		copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved,
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
	---------------------------------------------

	--
	--	description
	---------------------------------------------
		facade method for accessor, as accessor uses both set and get, allows programmatic testing by individual name.

	declare @stack xml ([utility].[xsc]), @return_code [int];
	execute @return_code = [repository_test].[set] @stack=@stack output;
	select @stack as [@stack], @return_code as [@return_code];


	--
	-- License
	---------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	All content is copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), set rights reserved. 
	licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) and copyright Katherine Elizabeth Lightsey, 1959-2014 (aka; my life), all rights reserved, 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).
		
	--
	-- to view documentation
	---------------------------------------------
	declare @schema   [sysname] = N'repository_test'
			, @object [sysname] = N'set';

	select [schemas].[name]
		   , [objects].[name]
		   , [extended_properties].[name]
		   , [extended_properties].[value]
	from   [sys].[extended_properties] as [extended_properties]
		   join [sys].[objects] as [objects]
			 on [objects].[object_id] = [extended_properties].[major_id]
		   join [sys].[schemas] as [schemas]
			 on [objects].[schema_id] = [schemas].[schema_id]
	where  [schemas].[name] = @schema
		   and [objects].[name] = @object; 
*/
create procedure [repository_test].[set]
  @stack xml ([utility].[xsc]) output
as
  begin
      set nocount on;

      declare @return_code     [int]
              , @subject_fqn   [nvarchar](1000)
              , @stack_builder [xml]
              , @description   [nvarchar](max) = N'facade method for accessor ([repository_test].[get]), as accessor uses both set and get, allows programmatic testing by individual name.';

      --
      -------------------------------------------
      execute [sp_get_server_information]
        @procedure_id=@@procid
        , @stack     =@stack_builder output;

      set @subject_fqn = @stack_builder.value(N'(/*/fqn/@name)[1]', N'[nvarchar](1000)');
      set @stack_builder=null;

      execute @return_code = [repository_test].[get]
        @stack=@stack_builder output;

      set @stack_builder.modify(N'replace value of (/*/object/test_stack/@name)[1] with sql:variable("@subject_fqn")');
      set @stack_builder.modify(N'replace value of (/*/object/test_stack/description/text())[1] with sql:variable("@description")');
      set @stack=@stack_builder;

      return @return_code;
  end;

go 
