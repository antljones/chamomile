use [test_02];

go

if schema_id(N'Address') is null
  execute (N'create schema Address');

go

if object_id(N'[Address].[Data]', N'V') is not null
  drop view [Address].[Data];

go

/*
	Katherine E. Lightsey
	20140313

	Gets address data from [Address__secure].[Data]

*/
create view [Address].[Data]
as
  select [ID],
         --
         isnull([Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[1],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[2],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[3],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[4],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[5],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[6],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[7],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[8],', 'sysname'), N'')
         +
         --
         isnull(N', ' +[Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/*)[9],', 'sysname'), N'')
         +
         --
         isnull([Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/country)[1],', 'sysname'), N'')       as [Address],
         --
         isnull([Entry].value('declare namespace noetic="http://www.noeticpartners.com/"; (./*/@address_type)[1],', 'sysname'), N'') as [AddressType],
         --
         [Entry]
  from   [Address__secure].[Data];

go

grant execute on [Address].[Data] to usrdesa;

go 
