if object_id(N'[Address__secure].[Address__Party]', N'U') is not null
  drop table [Address__secure].[Address__Party];

go

create table [Address__secure].[Address__Party]
  (
     [ID]                       [int] identity(1, 1) not null,
     [Address]                  [int] not null,
     [Party]                    [int] not null,
     [AddressPurposeType]       [sysname],
     [AddressType]              [sysname],
     [PreferredMethodOfContact] [sysname]
     constraint [Address__Party__ID__primary_key] primary key ([ID]),
     constraint [Address__Party__Address__Party__unique] unique ([Address], [Party])
  ); 
