use [test_02];

go

if schema_id(N'Address__secure') is null
  execute (N'create schema Address__secure');

go

if object_id(N'[Address__secure].[Get]', N'P') is not null
  drop procedure [Address__secure].[Get];

go

/*
	Katherine E. Lightsey
	20140313

	Gets address data from [Address__secure].[Data]
*/
create procedure [Address__secure].[Get] @id [int] = null
as
  begin
      select [ID],
             [Entry]
      from   [Address__secure].[Data]
      where  ( @id = [ID] )
              or ( @id is null );
  end;

go

grant execute on [Address__secure].[Get] to usrdesa;

go 
