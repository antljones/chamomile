use [chamomile];

go

if schema_id(N'repository_secure') is null
  execute (N'create schema repository_secure');

go

if object_id(N'[repository_secure].[set]'
             , N'P') is not null
  drop procedure [repository_secure].[set];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Mutator method for [repository_secure].[data].
	filename:		chamomile.repository.set.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'repository_secure'
			, @object [sysname] = N'set';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create procedure [repository_secure].[set]
  @stack    xml ([utility].[stack_xsc]) output
  , @delete [bit] = 0
as
  begin
      declare @builder       [xml] = @stack
              , @timestamp   [sysname] = convert([sysname], current_timestamp, 126)
              , @object_fqn  [nvarchar](max)
              , @object_type [sysname]
              , @true        [sysname] = N'true'
              , @id          [uniqueidentifier];
      declare @output as table (
        [action] [sysname]
        , [id]   [uniqueidentifier]
        );

      set @object_fqn = @stack.value(N'declare namespace chamomile="http://www.katherinelightsey.com/";
			data(chamomile:stack/object/@name)[1]'
                                     , N'[nvarchar](1000)');
      set @object_type = @stack.value(N'declare namespace chamomile="http://www.katherinelightsey.com/";
			data(chamomile:stack/object/@object_type)[1]'
                                      , N'[sysname]');
      set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
											replace value of (/chamomile:object_stack/@timestamp)[1] with sql:variable("@timestamp")');

      --
      -- delete from [repository_secure].[data]
      if @delete = 1
        with [delete]
             as (select [id]
                        , [entry]
                 from   [repository_secure].[data]
                 where  [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/chamomile:stack[1]/object[1]/@name[1])[1]'
                                      , N'nvarchar(max)') = @object_fqn
                        and [entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/chamomile:stack[1]/object[1]/@object_type[1])[1]'
                                          , N'nvarchar(max)') = @object_type)
        delete from [delete];

      begin
          merge into [repository_secure].[data] as target
          using (values (@builder
                , @object_fqn
                , @object_type
                , @delete)) as source ([entry], [object_fqn], [object_type], [delete])
          on target.[entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/chamomile:stack[1]/object[1]/@name[1])[1]'
                                  , N'nvarchar(max)') = [object_fqn]
             and target.[entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/chamomile:stack[1]/object[1]/@object_type[1])[1]'
                                      , N'nvarchar(max)') = [object_type]
             and target.[entry].value(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
												string(/chamomile:stack[1]/object[1]/@unique[1])[1]'
                                      , N'nvarchar(max)') = @true
          --
          ----------------------------------------------------------------
          when matched and [delete] = 0 then
            update set target.[entry] = source.[entry]
          --
          ----------------------------------------------------------------
          when not matched by target and [delete] = 0 then
            insert ([entry])
            values (source.[entry])
          --
          ----------------------------------------------------------------
          output $action
                 , coalesce([inserted].[id]
                          , [deleted].[id])
          into @output([action], [id]);

          --
          ----------------------------------------------------------------
          set @id = coalesce((select [id]
                              from   @output
                              where  lower([action]) = N'insert')
                             , (select [id]
                                from   @output
                                where  lower([action]) = N'update')
                             , (select [id]
                                from   @output
                                where  lower([action]) = N'delete'));
          set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com";
			insert attribute id {sql:variable("@id")} as last into (/*)[1]');
          set @stack = @builder;
      end
  end;

go

if exists (select *
           from   ::fn_listextendedproperty(N'todo'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'procedure'
                                            , N'set'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<ol>
		<li>Implement @delete at both the stack and the object level.</li>
	</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'procedure'
                                            , N'set'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go 
