/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Drop and create the [repository_secure].[data] table.
	filename:		chamomile.repository_secure.data.sql
	prerequisites:	
	description:	
		
	--
	-- Notes
	----------------------------------------------------------------------
	
	--
	-- References
	----------------------------------------------------------------------
*/
--
use [chamomile];

go

if schema_id(N'repository_secure') is null
  execute (N'create schema repository_secure');

go

if exists (select *
           from   dbo.sysobjects
           where  id = object_id(N'[repository_secure].[repository_secure.data.id.default]')
                  and type = 'D')
  begin
      alter table [repository_secure].[data]
        drop constraint [repository_secure.data.id.default]
  end

go 

if exists
   (select *
    from   sys.indexes
    where  object_id = object_id(N'[repository_secure].[data]')
           and name = N'repository_secure.data.entry.xml_index_property')
  drop index [repository_secure.data.entry.xml_index_property] on [repository_secure].[data]

go

if exists
   (select *
    from   sys.indexes
    where  object_id = object_id(N'[repository_secure].[data]')
           and name = N'repository_secure.data.entry.xml_index')
  drop index [repository_secure.data.entry.xml_index] on [repository_secure].[data]

go

if exists
   (select *
    from   sys.objects
    where  object_id = object_id(N'[repository_secure].[data]')
           and type in (N'U'))
  drop table [repository_secure].[data]

go

set ansi_nulls on

go

set quoted_identifier on

go

if not exists
       (select *
        from   sys.objects
        where  object_id = object_id(N'[repository_secure].[data]')
               and type in (N'U'))
  begin
      create table [repository_secure].[data](
        [id]        [uniqueidentifier] not null,
        [entry] xml([utility].[stack_xsc]) not null,
        constraint [repository_secure.data.id.primary_key_clustered] primary key clustered ([id] asc))
  end

go

set arithabort on
set concat_null_yields_null on
set quoted_identifier on
set ansi_nulls on
set ansi_padding on
set ansi_warnings on
set numeric_roundabort off

go

if not exists
       (select *
        from   sys.indexes
        where  object_id = object_id(N'[repository_secure].[data]')
               and name = N'repository_secure.data.entry.xml_index')
  create primary xml index [repository_secure.data.entry.xml_index] on [repository_secure].[data] ( [entry] )with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on)

go

if not exists
       (select *
        from   sys.indexes
        where  object_id = object_id(N'[repository_secure].[data]')
               and name = N'repository_secure.data.entry.xml_index_property')
  create xml index [repository_secure.data.entry.xml_index_property] on [repository_secure].[data] ( [entry] ) using xml index [repository_secure.data.entry.xml_index] for property with (pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on)

go

if not exists (select *
               from   dbo.sysobjects
               where  id = object_id(N'[repository_secure].[repository_secure.data.id.default]')
                      and type = 'D')
  begin
      alter table [repository_secure].[data]
        add constraint [repository_secure.data.id.default] default (newsequentialid()) for [id]
  end

go


if exists
   (select *
    from   ::fn_listextendedproperty(N'license',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     N'COLUMN',
                                     N'id'))
  exec sys.sp_dropextendedproperty
    @name        =N'license',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'id'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'id'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     N'COLUMN',
                                     N'id'))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'id'

go

  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N''
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'
    , @level2type=N'COLUMN'
    , @level2name=N'id'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     N'COLUMN',
                                     N'entry'))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data',
    @level2type=N'COLUMN',
    @level2name=N'entry'

go
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'[entry] [xml](content [utility].[stack_xsc]) not null'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'
    , @level2type=N'COLUMN'
    , @level2name=N'entry'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'description',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     null,
                                     null))
  exec sys.sp_dropextendedproperty
    @name      =N'description',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data'

go
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'Stores for typed data.'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go

if exists
   (select *
    from   ::fn_listextendedproperty(N'revision_20140618',
                                     N'SCHEMA',
                                     N'repository_secure',
                                     N'TABLE',
                                     N'data',
                                     null,
                                     null))
  exec sys.sp_dropextendedproperty
    @name      =N'revision_20140618',
    @level0type=N'SCHEMA',
    @level0name=N'repository_secure',
    @level1type=N'TABLE',
    @level1name=N'data'

go

  exec sys.sp_addextendedproperty
    @name        =N'revision_20140618'
    , @value     =N'Katherine E. Lightsey - created.'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go 

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'repository_secure'
                                            , N'TABLE'
                                            , N'data'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'repository_secure'
    , @level1type=N'TABLE'
    , @level1name=N'data'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'repository_secure'
  , @level1type=N'TABLE'
  , @level1name=N'data'

go
