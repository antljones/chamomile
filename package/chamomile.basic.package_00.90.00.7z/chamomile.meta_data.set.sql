use [chamomile];

go

if schema_id(N'meta_data') is null
  execute (N'create schema meta_data');

go

if object_id(N'[meta_data].[set]') is not null
  drop procedure [meta_data].[set];

go

/*
	--
	-- License
	-------------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	-------------------------------------------------------------------------
	title:			
	filename:		chamomile.utility.set.sql

	--
	-- to view documentation
	-------------------------------------------------------------------------
	declare @schema   [sysname] = N'meta_data'
			, @object [sysname] = N'set';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create procedure [meta_data].[set]
  @name          [nvarchar](1000)
  , @value       [sysname]
  , @constraint  [nvarchar](1000) = null
  , @description [nvarchar](max)
  , @stack       xml([utility].[stack_xsc]) = null output
  , @delete      [bit] = 0
as
  begin
      declare @builder         [xml]
              , @existing      [xml]
              , @object_type   [sysname] = N'meta_data'
              , @error_message [nvarchar](max);

      set @existing = [utility].[get_stack](@name
                                            , N'meta_data');
      set @constraint = isnull(@constraint
                               , @existing.value(N'declare namespace chamomile="http://www.katherinelightsey.com/";
							   data (/chamomile:stack/object/@constraint)[1]'
                                                 , N'[nvarchar](1000)'));

      if @constraint is not null
         and patindex (N'|%' + @value + N'|%'
                       , @constraint) < 1
        begin
            set @error_message = N'value does not match constraint';

            raiserror(51000,@error_message,1);
        end
      else
        begin
            set @builder = isnull([utility].[get_stack](@name
                                                        , N'meta_data')
                                  , [utility].[get_object](N'[chamomile].[meta_data].[stack]'
                                                           , N'prototype'));
            --
            --------------------------------------------------------------------
            -- set @constraint = isnull(@constraint, 
            --
            --------------------------------------------------------------------
            set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
				replace value of (/chamomile:stack/object/@name)[1] with sql:variable("@name")');
            set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
				replace value of (/chamomile:stack/object/@value)[1] with sql:variable("@value")');

            if @constraint is not null
              set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
				replace value of (/chamomile:stack/object/@constraint)[1] with sql:variable("@constraint")');

            set @builder.modify('declare namespace chamomile="http://www.katherinelightsey.com/"; 
					replace value of (/chamomile:stack/object/description/text())[1] with sql:variable("@description")');
            set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
				replace value of (/chamomile:stack/object/@object_type)[1] with sql:variable("@object_type")');

            execute [repository_secure].[set]
              @stack=@builder output
        , @delete= @delete;

            set @stack=@builder;
        end
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'procedure'
                                            , N'set'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'procedure'
    , @level1name=N'set'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [meta_data].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'procedure'
  , @level1name=N'set'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set';

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml([utility].[stack_xsc]);
	execute [meta_data].[set]
	  @name          = N''[category].[class].[description_test_01]''
	  , @value       = N''value2''
	  , @constraint  = N''|value1|value2|''
	  , @description = N''description for test case.''
	  , @stack       =@stack output;
	select @stack;'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140611'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140611'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140611'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'PROCEDURE'
                                            , N'set'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'PROCEDURE'
    , @level1name=N'set'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'PROCEDURE'
  , @level1name=N'set'

go 
