use [chamomile];

go

if schema_id(N'utility') is null
  execute (N'create schema utility');

go

if object_id(N'[utility].[get_object_list]'
             , N'TF') is not null
  drop function [utility].[get_object_list];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Adapter method for [repository_secure].[get] that returns a list of objects.
	filename:		utility.get_object_list.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
			, @object [sysname] = N'get_object_list';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
		   
		   select [repository_secure].[get](N'chamomile.administration.query_performance', N'command');
		   select * from [utility].[get_object_list](N'chamomile.administration.design_pattern_command_demonstration', N'command');

		select * from [utility].[get_object_list] (N'[chamomile].[command].[stack]', N'prototype');
		select * from [utility].[get_object_list](N'chamomile.administration.query_performance' , N'command');
		select [repository_secure].[get](N'[chamomile].[administration].[query_performance]' , N'command');

		select * from repository_secure.data
*/
create function [utility].[get_object_list] (
  @object_fqn    [nvarchar](1000)
  , @object_type [sysname])
returns @object_list table (
  [object] [xml] )
as
  begin
      declare @builder xml = [repository_secure].[get](@object_fqn, @object_type);

      insert into @object_list
                  ([object])
        select t.c.query(N'.')
        from   @builder.nodes(N'declare namespace chamomile="http://www.katherinelightsey.com/";
	chamomile:stack/object[@name=sql:variable("@object_fqn")][@object_type=sql:variable("@object_type")]/*') as t(c)
        order  by t.c.value(N'../@timestamp'
                            , N'datetime') desc;

      return;
  end

go 

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'get_object_list'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_object_list'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_object_list'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'get_object_list'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_object_list'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_object_list'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'get_object_list'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_object_list'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_object_list'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'get_object_list'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_object_list'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_object_list'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'get_object_list'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_object_list'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_object_list'

go