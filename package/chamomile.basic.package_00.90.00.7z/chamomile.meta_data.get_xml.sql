use [chamomile];

go

if schema_id(N'meta_data') is null
  execute (N'create schema meta_data');

go

if object_id(N'[meta_data].[get_xml]'
             , N'FN') is not null
  drop function [meta_data].[get_xml];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Adapter method for [repository_secure].[get] which returns a prototype object.
	filename:		utility.get_stack.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'meta_data'
			, @object [sysname] = N'get_xml';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create function [meta_data].[get_xml] (
  @name [nvarchar](1000))
returns xml([utility].[stack_xsc])
as
  begin
      declare @return xml([utility].[stack_xsc]);

      set @return = (select [utility].[get_stack] (@name
                                                   , N'meta_data'));

      return @return;
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get_xml'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_xml'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_xml'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get_xml'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_xml'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_xml'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get_xml'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_xml'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'select [meta_data].[get_xml](N''chamomile.workflow.stack''
                             , N''prototype'');'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_xml'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get_xml'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_xml'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_xml'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get_xml'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get_xml'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get_xml'

go 
