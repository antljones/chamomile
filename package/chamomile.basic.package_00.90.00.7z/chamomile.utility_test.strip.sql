use [chamomile];

go

if schema_id(N'utility_test') is null
  execute (N'create schema utility_test');

go

if object_id(N'[utility_test].[strip]'
             , N'P') is not null
  drop procedure [utility_test].[strip];

go
/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Unit tests for [utility].[strip].
	filename:		utility_test.strip.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility_test'
			, @object [sysname] = N'strip';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create procedure [utility_test].[strip]
  @stack xml ([utility].[stack_xsc]) output
as
  begin
      declare @input              [nvarchar](max)
              , @filter           [sysname]
              , @filtered_output  [nvarchar](max)
              , @expected_output  [nvarchar](max)
              , @expected_result  [nvarchar](max)
              , @test_name        [sysname]
              , @test_description [nvarchar](max)
              , @message          [xml]
              , @sequence         [int]
              , @test             [xml]
              , @test_stack       [xml]
              , @count            [int]
              , @builder          [xml]
              , @test_setup       [xml]
              , @prefix           [sysname]
              , @sql              [nvarchar](max)
              , @parameters       [nvarchar](max)
              , @subject_fqn             [nvarchar](1000)
              , @object           [nvarchar](1000);

      set nocount on;
      set @subject_fqn = N'['
                  + convert([sysname], serverproperty(N'MachineName'))
                  + '].['
                  + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                  + '].['
                  + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                  + N'].[' + db_name() + '].['
                  + object_schema_name(@@procid) + '].['
                  + object_name(@@procid) + ']';
      set @object = N'[chamomile].[utility].[strip]';

      if ( @stack is null )
        begin
            set @builder = [utility].[get_prototype](N'[chamomile].[utility].[stack]');
            set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
						replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
            set @stack = @builder;
        end

      if @stack.exist(N'declare namespace chamomile="http://www.katherinelightsey.com/"; /chamomile:stack/result') = 0
        begin
            set @builder = N'<result result_type="test" />';
            set @stack.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/";  insert sql:variable("@builder") as last into (/chamomile:stack)[1]');
        end

      set @test_stack = [utility].[get_prototype](N'[chamomile].[test].[stack]');
      set @test_stack.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
      set @test_stack.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/object/@name)[1] with sql:variable("@object")')

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=1;
          set @test_name = N'Unchanged string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes all characters in the string.';
          set @expected_result = N'The input string is returned unchanged.';
          set @input = N'No changes are made to this string.';
          set @filter = N'a-zA-Z .';
          set @expected_output = N'No changes are made to this string.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=2;
          set @test_name = N'Unchanged string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes none of the characters in the string.';
          set @expected_result = N'The input string is returned unchanged.';
          set @input = N'No changes are made to this string.';
          set @filter = N'0-9';
          set @expected_output = N'No changes are made to this string.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=3;
          set @test_name = N'Subset of string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes only some of the alphanumeric characters in the string.';
          set @expected_result = N'The input string is returned without the excluded letters or numbers.';
          set @input = N'input 12345';
          set @filter = N'inpt135 ';
          set @expected_output = N'inpt 135';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=4;
          set @test_name = N'Subset of string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes only some of the alphanumeric characters in the string.';
          set @expected_result = N'The input string is returned without the filtered letters or numbers.';
          set @input = N'input 12345';
          set @filter = N'inpt135 ';
          set @expected_output = N'u24';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=5;
          set @test_name = N'Subset of string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes only some of the alphanumeric characters in the string.';
          set @expected_result = N'The input string is returned without the excluded letters or numbers.';
          set @input = N'this 9 str5ing sh3ould 65 o6nly be 455 letters99 and spaces with a period.';
          set @filter = N'a-zA-Z. ';
          set @expected_output = N'this  string should  only be  letters and spaces with a period.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=6;
          set @test_name = N'Subset of string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes only some of the alphanumeric characters in the string.';
          set @expected_result = N'The input string is returned without the filtered letters or numbers.';
          set @input = N'This string should not have alpha characters up to c and numeric characters 0, 1, 2, and 3, but will include 4, 5, 6, 7, 8, and 9.';
          set @filter = N'a-cA-C.0-3';
          set @expected_output = N'This string should not hve lph hrters up to  nd numeri hrters , , , nd , ut will inlude 4, 5, 6, 7, 8, nd 9';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=7;
          set @test_name = N'Null filter, @remove = 0';
          set @test_description = N'Pass in a string with a null filter.';
          set @expected_result = N'A zero length string';
          set @input = N'this 9 str5ing sh3ould 65 o6nly be 455 letters99 and spaces with a period.';
          set @filter = N'';
          set @expected_output = N'';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=8;
          set @test_name = N'Null filter, @remove = 1';
          set @test_description = N'Pass in a string with a null filter.';
          set @expected_result = N'No change to the string';
          set @input = N'this 9 str5ing sh3ould 65 no6t be 455 changed85. ';
          set @filter = N'';
          set @expected_output = N'this 9 str5ing sh3ould 65 no6t be 455 changed85. ';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=9;
          set @test_name = N'Superset of a string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'This should return a zero length string.';
          set @filter = N'0-9';
          set @expected_output = N'';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=10;
          set @test_name = N'Superset of a string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'This should return a zero length string.';
          set @filter = N'0-9a-zA-Z. ';
          set @expected_output = N'';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=11;
          set @test_name = N'Characters to remove are only at the end of the string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'This should return a string without the numbers and last letter of the alphabet on the endz9z1.83z';
          set @filter = N'a-yA-Y. ';
          set @expected_output = N'This should return a string without the numbers and last letter of the alphabet on the end.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=12;
          set @test_name = N'Characters to leave are only at the end of the string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'This should return a string without the numbers and last letter of the alphabet on the endz9z1.83z';
          set @filter = N'19z38';
          set @expected_output = N'This should return a string without the numbers and last letter of the alphabet on the end.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=13;
          set @test_name = N'Characters to remove are only at the beginning of the string, @remove = 0';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'z9z1.83zThis should return a string without the numbers and last letter of the alphabet at the beginning.';
          set @filter = N'a-yA-Y. ';
          set @expected_output = N'.This should return a string without the numbers and last letter of the alphabet at the beginning.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=14;
          set @test_name = N'Characters to remove are only at the beginning of the string, @remove = 1';
          set @test_description = N'Pass in a string with a filter that includes none of the passed in string characters.';
          set @expected_result = N'A zero length string';
          set @input = N'z9z1.83zThis should return a string without the numbers and last letter of the alphabet at the beginning.';
          set @filter = N'a-yA-Y. ';
          set @expected_output = N'.This should return a string without the numbers and last letter of the alphabet at the beginning.';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=15;
          set @test_name = N'Null string, @remove = 1';
          set @test_description = N'Pass in a null string with a remove filter.';
          set @expected_result = N'A zero length string';
          set @input = null;
          set @filter = N'a-yA-Y. ';
          set @expected_output = null;
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=16;
          set @test_name = N'Null string, @remove = 0';
          set @test_description = N'Pass in a null string with a leave filter.';
          set @expected_result = N'A zero length string';
          set @input = null;
          set @filter = N'a-yA-Y. ';
          set @expected_output = null;
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null, null ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=17;
          set @test_name = N'String includes tab ([char](9)], @remove = 1';
          set @test_description = N'Pass in a null string with a leave filter.';
          set @expected_result = N'The tab is removed from the string';
          set @input = N'Remove this tab' + char(9)
                       + ' from this string';
          set @filter = char(9);
          set @expected_output = N'Remove this tab from this string';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  1 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=18;
          set @test_name = N'String includes tab ([char](9)], @remove = 0';
          set @test_description = N'Pass in a string with whitespace characters.';
          set @expected_result = N'The whitespace characters are the only remaining characters.';
          set @input = N'Leave only this tab' + char(9)
                       + ' in this string';
          set @filter = char(9);
          set @expected_output = char(9);
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  0 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=19;
          set @test_name = N'Ignore prefix';
          set @test_description = N'Remove all but prefix';
          set @expected_result = N'Prefix remains as a prefix, but is removed elsewhere in the string.';
          set @input = N'+052 1234 +5678';
          set @filter = N'0-9';
          set @prefix = N'+';
          set @expected_output = N'+05212345678';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, @prefix,  0 ) );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @prefix [sysname], @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      ---------------------------------------------------------------------------------------------
      begin
          set @sequence=20;
          set @test_name = N'fully qualified names';
          set @test_description = N'Work with special characters.';
          set @expected_result = N'special characters remain.';
          set @input = N'[instance-01_name].[data base].[object]';
          set @filter = N' .a-zA-Z0-9\_-';
          set @prefix = null;
          set @expected_output = N'instance-01_name.data base.object';
          set @sql =N'set @filtered_output = ( select [utility].[strip]( @input, @filter, null,  0 )  );';
          set @parameters =N'@filter [sysname], @input [nvarchar](max), @filtered_output [nvarchar](max) output';
          --
          -------------------------------------------------------------------------------------
          set @test = @test_stack;
          set @test.modify(N'replace value of (/*/result/@sequence)[1] with sql:variable("@sequence")');
          set @test.modify(N'replace value of (/*/result/@name)[1] with sql:variable("@test_name")');
          set @test.modify(N'insert text {sql:variable("@test_description")} as last into (/*/result/description)[1]');
          set @test.modify(N'insert text {sql:variable("@sql")} as last into (/*/result/setup/sql)[1]');
          set @test.modify(N'insert text {sql:variable("@parameters")} as last into (/*/result/setup/parameters)[1]');
          set @test.modify(N'insert text {sql:variable("@input")} as last into (/*/result/setup/input)[1]');
          set @test.modify(N'insert text {sql:variable("@expected_result")} as last into (/*/result/setup/expected)[1]');
          set @test.modify(N'insert attribute filter {sql:variable("@filter")} as first into (/*/result/setup)[1]');

          --
          -------------------------------------------------------------------------------------
          begin try
              execute sp_executesql
                @sql               = @sql
                , @parameters      = @parameters
                , @filter          = @filter
                , @input           = @input
                , @filtered_output = @filtered_output output;

              set @test.modify(N'insert text {sql:variable("@filtered_output")} as last into (/*/result/setup/output)[1]');

              if ( @expected_output = @filtered_output )
                set @test.modify(N'replace value of (/*/result/@result)[1] with ("pass")');
          end try

          begin catch
              set @message = N'<application_message><sql>' + @sql
                             + '</sql><parameters>' + @parameters
                             + '</parameters>' + '<input value="' + @input
                             + '" />' + '<filter value="' + @filter + '" />'
                             + '<expected_output value="'
                             + @expected_output + '" />'
                             + '</application_message>';

              execute [utility].[handle_error]
                @stack          =@stack output
                , @procedure_id = @@procid
                , @message      = @message;
          end catch

          set @stack.modify(N'insert sql:variable("@test") as last into (/*/result)[1]');
      end

      --
      -- Total results
      ---------------------------------------------------------------------------------------------
      begin
          set @count = @stack.value(N'count (/*/*)'
                                    , 'int');
      --set @stack.modify(N'replace value of (/result/@test_count)[1] with sql:variable("@count")');
      --set @count = @stack.value(N'count (/*/test[@stack="pass"])', 'int');
      --set @stack.modify(N'replace value of (/result/@pass_count)[1] with sql:variable("@count")');
      end
  end;

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'Performs unit tests on [utilty].[strip].'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'
		declare @stack [xml];
		execute [utility_test].[strip] @stack=@stack output;
		select @stack;'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140217'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140217'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140217'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140220'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140220'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140220'
  , @value     =N'Katherine E. Lightsey - added tests for null input string.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , N'PARAMETER'
                                            , N'@stack'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'
    , @level2type=N'PARAMETER'
    , @level2name=N'@stack'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'<i>@stack [xml]</i> - test output.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'
  , @level2type=N'PARAMETER'
  , @level2name=N'@stack'

go 

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'utility_test'
                                            , N'PROCEDURE'
                                            , N'strip'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility_test'
    , @level1type=N'PROCEDURE'
    , @level1name=N'strip'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility_test'
  , @level1type=N'PROCEDURE'
  , @level1name=N'strip'

go