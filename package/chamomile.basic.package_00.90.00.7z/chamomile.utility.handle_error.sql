use [chamomile];

go

if schema_id(N'utility') is null
  execute(N'create schema utility');

go

if object_id(N'[utility].[handle_error]'
             , N'P') is not null
  drop procedure [utility].[handle_error];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Error handler.
	filename:		utility.handle_error.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
			, @object [sysname] = N'handle_error';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create procedure [utility].[handle_error]
  @stack          xml ([utility].[stack_xsc]) output
  , @procedure_id [int]
  , @message      [xml]
as
  begin
      declare @prototype         [xml]
              , @error           [xml]
              , @error_procedure [sysname]
              , @error_line      [int]
              , @error_number    [int]
              , @builder         [xml]
              , @error_message   [nvarchar](max)
              , @error_severity  [int]
              , @error_state     [int]
              , @subject_fqn     [nvarchar](1000)
              , @object_fqn      [nvarchar](1000);

      begin try
          if @stack is null
            begin
                set @builder = [utility].[get_object] (N'[chamomile].[error].[stack]'
                                                       , N'prototype');
                set @subject_fqn = N'['
                                   + convert([sysname], serverproperty(N'MachineName'))
                                   + '].['
                                   + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                                   + '].['
                                   + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                                   + N'].[' + db_name() + '].['
                                   + object_schema_name(@@procid) + '].['
                                   + object_name(@@procid) + ']';
                set @object_fqn = N'['
                                  + convert([sysname], serverproperty(N'MachineName'))
                                  + '].['
                                  + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                                  + '].['
                                  + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                                  + N'].[' + db_name() + '].['
                                  + object_schema_name(@procedure_id) + '].['
                                  + object_name(@procedure_id) + ']';
                set @builder.modify(N'replace value of (/*/subject/@name)[1] with sql:variable("@subject_fqn")');
                set @builder.modify(N'replace value of (/*/object/@name)[1] with sql:variable("@object_fqn")');
            end

          set @error_procedure = N'['
                                 + isnull(object_schema_name(@procedure_id), N'')
                                 + '].['
                                 + isnull(object_name(@procedure_id), N'')
                                 + N']';
          set @error_line = isnull(error_line()
                                   , N'');
          set @error_number = isnull(error_number()
                                     , N'');
          set @error_message = isnull(error_message()
                                      , N'');
          set @error_severity = isnull(error_severity()
                                       , N'');
          set @error_state = isnull(error_state()
                                    , N'');
          --
          ------------------------------------------------------------------------------------------------
          set @builder.modify(N'insert text {sql:variable("@error_message")} as last into (/*/result/error_message)[1]');
          set @builder.modify(N'insert sql:variable("@message") as last into  (/*/result)[1]');
          set @builder.modify(N'replace value of (/*/result/@error_procedure)[1] with sql:variable("@error_procedure")');
          set @builder.modify(N'replace value of (/*/result/@error_line)[1] with sql:variable("@error_line")');
          set @builder.modify(N'replace value of (/*/result/@error_number)[1] with sql:variable("@error_number")');
          set @builder.modify(N'replace value of (/*/result/@error_severity)[1] with sql:variable("@error_severity")');
          set @builder.modify(N'replace value of (/*/result/@error_state)[1] with sql:variable("@error_state")');
          set @stack = @builder;
      end try

      begin catch
          select @error                              as [@error]
                 , @builder                          as [@builder]
                 , @stack                            as [@stack]
                 , error_message()                   as [error_message]
                 , object_schema_name(@procedure_id) as [schema]
                 , error_procedure()                 as [error_procedure];
      end catch
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go

if exists (select *
           from   ::fn_listextendedproperty(N'todo'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'1. Add handling for nested error stacks.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @version [int] = (select cast([major] as [int]) from [utility].[get_sql_version]())
				 , @message [xml];

set @message = N''<message>
							<sql>'' + @sql + N''</sql>
						 <parameters>''
                         + @parameters + N''</parameters> 
						 <schema>'' + @schema
                         + N''</schema> 
						 <object>'' + @object
                         + N''</object>
						 <object_type>'' + @object_type
                         + N''</object_type></message>'';

          execute [utility].[handle_error]
            @stack          = @error_stack output
            , @procedure_id = @@procid
            , @message      = @message;

          if @version < 12
            begin
                set @text_message = N''raiserror (15600,-1,-1,''''''
                                    + cast(@error_stack as [nvarchar](max))
                                    + '''''');'';

                execute (@message);
            end
          else
            begin
                set @text_message = N''throw 51000, N''''''
                                    + cast(@error_stack as [nvarchar](max))
                                    + '''''', 1;'';

                execute (@text_message);
            end'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'PROCEDURE'
                                            , N'handle_error'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'PROCEDURE'
    , @level1name=N'handle_error'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'PROCEDURE'
  , @level1name=N'handle_error'

go 
