

	param([string]$serverinstance, [string]$database);
	BCP "execute [best_practices].[get]" queryout chamomile.basic.best_practices.html -t, -T -c -d $database -S $serverinstance;