use [chamomile]

go

if schema_id(N'meta_data_test') is null
  execute (N'create schema meta_data_test');

go

if exists (select *
           from   sys.objects
           where  object_id = object_id(N'[meta_data_test].[all]')
                  and type in ( N'P' ))
  drop procedure [meta_data_test].[all]

go

use [chamomile]

go

set ansi_nulls on

go

set quoted_identifier on

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Test method for [repository_secure].[get] and [repository_secure].[set]
	filename:		meta_data_test.all.sql

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'meta_data_test'
			, @object [sysname] = N'all';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
		   
	--
	-- execute_as
	-------------------------------------------------------------------------
	declare @stack xml([utility].[stack_xsc]);
	execute [meta_data_test].[all] @stack=@stack output;
	select @stack as [result_stack];
	
*/
create procedure [meta_data_test].[all]
  @stack xml([utility].[stack_xsc]) output
as
  begin
      set nocount on;
      set transaction isolation level serializable;

      declare @transaction            [sysname] = N'repository_test_all_'
                + cast(round(rand()*100000, -1) as [sysname])
                + N'_'
                + cast(datepart(millisecond, current_timestamp) as [sysname])
              , @message              [nvarchar](max)
              , @subject_fqn          [nvarchar](1000)
              , @object_fqn           [nvarchar](1000)
              , @test                 xml([utility].[stack_xsc])
              , @test_object          [xml]
              , @test_xml_meta_data   [xml]
              , @result_xml_meta_data xml([utility].[stack_xsc])
              , @count                [int]
              , @test_number          [int]
              , @test_name            [sysname]
              , @actual               [sysname]
              , @test_description     [nvarchar](max)
              , @expected             [nvarchar](max)
              , @stack_builder        [xml]
              , @builder              [xml]
              , @fail                 [xml]
              , @name                 [nvarchar](1000)
              , @value                [sysname]
              , @constraint           [nvarchar](max)
              , @description          [nvarchar](max);

      --
      -----------------------------------------------------------------------
      begin
          set @subject_fqn = N'['
                             + convert([sysname], serverproperty(N'MachineName'))
                             + '].['
                             + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                             + '].['
                             + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                             + N'].[' + db_name() + '].['
                             + object_schema_name(@@procid) + '].['
                             + object_name(@@procid) + ']';
          set @object_fqn = N'[chamomile].[repository_secure].[set]_[chamomile].[repository_secure].[get]';
          set @stack_builder = isnull(@stack
                                      , [utility].[get_object](N'[chamomile].[test].[stack]'
                                                               , N'prototype'));
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
						replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/object/@name)[1] with sql:variable("@object_fqn")');
          set @test_description = N'Test all repository accessor and mutator methods.';
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
			insert text {sql:variable("@test_description")} as last into (/chamomile:stack/result/description)[1]')
      end

      --
      -----------------------------------------------------------------------
      begin
          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=1;
              set @test_name = N'[meta_data_test].[all].[build_and_set_meta_data_stack]';
              set @test_description = N'Create and set a typed meta data stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              if @@trancount = 0
                begin transaction @transaction;
              else
                begin
                    set @message = N'Cannot run test due to existing @@trancount.';

                    raiserror(51000,-1,-1,51000);
                end

              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*100000, -1) as [nvarchar](1000))
                              + N'_'
                              + cast(datepart(millisecond, current_timestamp) as [sysname])
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@test output;

                  if(select [meta_data].[get](@name)) = @value
                    set @actual=N'pass';
                  else
                    begin
                        set @fail = (select @name                               as N'@name'
                                            , @value                            as N'@value'
                                            , @constraint                       as N'@constraint'
                                            , N'fail'                           as N'@result_type'
                                            , @description                      as N'@description'
                                            , (select [meta_data].[get](@name)) as N'@returned_value'
                                     for xml path(N'fail'), root(N'result'));
                        set @test.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/";
														insert sql:variable("@fail") as last into (/*)[1]');
                    end

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end try

              begin catch
                  select @test_number        as [@test_number]
                         , @test_name        as [@test_name]
                         , @test             as [@test]
                         , @name             as [@name]
                         , @value            as [@value]
                         , @constraint       as [@constraint]
                         , @description      as [@description]
                         , error_message()   as [error_message]
                         , error_procedure() as [error_procedure];

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=2;
              set @test_name = N'[meta_data_test].[all].[build_and_update_meta_data_stack]';
              set @test_description = N'Create and update a typed meta data stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              if @@trancount = 0
                begin transaction @transaction;
              else
                begin
                    set @message = N'Cannot run test due to existing @@trancount.';

                    raiserror(51000,-1,-1,51000);
                end

              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*10000, -1) as [nvarchar](1000))
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  set @value = N'test_value2';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  if(select [meta_data].[get](@name)) = @value
                    set @actual=N'pass';

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end try

              begin catch
                  select @test_number        as [@test_number]
                         , @test_name        as [@test_name]
                         , @test             as [@test]
                         , @name             as [@name]
                         , @value            as [@value]
                         , @constraint       as [@constraint]
                         , @description      as [@description]
                         , error_message()   as [error_message]
                         , error_procedure() as [error_procedure];

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end;

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=3;
              set @test_name = N'[meta_data_test].[all].[update_value_that_does_not_meet_constraint]';
              set @test_description = N'Attempt to create and update a value that does not meet the constraint.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              if @@trancount = 0
                begin transaction @transaction;
              else
                begin
                    set @message = N'Cannot run test due to existing @@trancount.';

                    raiserror(51000,-1,-1,51000);
                end

              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*10000, -1) as [nvarchar](1000))
                              + N']';
                  set @value = N'test_value';
                  set @constraint = N'|test_value_01|test_value_02|';
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end try

              begin catch
                  set @actual=N'pass';

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end;

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=4;
              set @test_name = N'[meta_data_test].[all].[build_meta_data_xml]';
              set @test_description = N'Build, store, and retrieve a meta_data xml stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              if @@trancount = 0
                begin transaction @transaction;
              else
                begin
                    set @message = N'Cannot run test due to existing @@trancount.';

                    raiserror(51000,-1,-1,51000);
                end

              begin try
                  set @name = N'[meta_data_test].[all].[build_meta_data_xml_'
                              + cast(round(rand()*100000, -1) as [nvarchar](1000))
                              + N'_'
                              + cast(datepart(millisecond, current_timestamp) as [sysname])
                              + N']';
                  set @test = [utility].[get_object](N'[chamomile].[meta_data].[xml_stack]'
                                                     , N'prototype');
                  set @builder = @test;
                  set @builder.modify(N'replace value of (/*/object/@name)[1] with sql:variable("@name")');
                  set @test_xml_meta_data = N'<valid_xml><any_valid_xml /></valid_xml>';
                  set @builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/";
					insert sql:variable("@test_xml_meta_data") as last into (/*/object)[1]');
                  set @test=@builder;

                  execute [meta_data].[set_xml]
                    @stack=@test output;

                  set @result_xml_meta_data = [meta_data].[get_xml] (@name);

                  select @result_xml_meta_data
                         , @test;

                  set @actual=N'pass';

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end try

              begin catch
                  select @test_xml_meta_data as [@test_xml_meta_data];

                  select @test_number        as [@test_number]
                         , @test_name        as [@test_name]
                         , @test             as [@test]
                         , @name             as [@name]
                         , @value            as [@value]
                         , @constraint       as [@constraint]
                         , @description      as [@description]
                         , error_message()   as [error_message]
                         , error_procedure() as [error_procedure];

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end;

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=5;
              set @test_name = N'[meta_data_test].[all].[get_list]';
              set @test_description = N'Get of list of meta data values.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              if @@trancount = 0
                begin transaction @transaction;
              else
                begin
                    set @message = N'Cannot run test due to existing @@trancount.';

                    raiserror(51000,-1,-1,51000);
                end

              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*100000, -1) as [nvarchar](1000))
                              + N'_'
                              + cast(datepart(millisecond, current_timestamp) as [sysname])
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@test output;

                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*100000, -1) as [nvarchar](1000))
                              + N'_'
                              + cast(datepart(millisecond, current_timestamp) as [sysname])
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@test output;

                  set @name = N'[category].[class].[description]';

                  select *
                  from   [meta_data].[get_list](@name) as [get list]

                  if(select [meta_data].[get](@name)) = @value
                    set @actual=N'pass';
                  else
                    begin
                        set @fail = (select @name                               as N'@name'
                                            , @value                            as N'@value'
                                            , @constraint                       as N'@constraint'
                                            , N'fail'                           as N'@result_type'
                                            , @description                      as N'@description'
                                            , (select [meta_data].[get](@name)) as N'@returned_value'
                                     for xml path(N'fail'), root(N'result'));
                        set @fail.modify(N'insert attribute result_type {("test")} as last into (/*)[1]');

                        set @test.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/";
														insert sql:variable("@fail") as last into (/*)[1]');

                        if exists(select *
                                  from   [sys].[dm_tran_active_transactions]
                                  where  [name] = @transaction)
                          rollback transaction @transaction;
                    end
              end try

              begin catch
                  select @test_number        as [@test_number]
                         , @test_name        as [@test_name]
                         , @test             as [@test]
                         , @name             as [@name]
                         , @value            as [@value]
                         , @constraint       as [@constraint]
                         , @description      as [@description]
                         , error_message()   as [error_message]
                         , error_procedure() as [error_procedure];

                  if exists(select *
                            from   [sys].[dm_tran_active_transactions]
                            where  [name] = @transaction)
                    rollback transaction @transaction;
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          --
          -- Total results
          ---------------------------------------------------------------------------------------------
          begin
              set @count = @stack_builder.value(N'count (/*/result/*)'
                                                , 'int') - 1; -- subtract 1 for <description />
              set @stack_builder.modify(N'replace value of (/*/result/@test_count)[1] with sql:variable("@count")');
              set @count = @stack_builder.value(N'count (/*/result/*[@expected=@actual])'
                                                , 'int');
              set @stack_builder.modify(N'replace value of (/*/result/@pass_count)[1] with sql:variable("@count")');
              set @count = @stack_builder.value(N'count (/*/result/*[@expected!=@actual])'
                                                , 'int');
              set @stack_builder.modify(N'replace value of (/*/result/@error_count)[1] with sql:variable("@count")');
          end

          set @stack=@stack_builder;
      end
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'todo'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<ol>
			<li>Add additional tests for boundary conditions.</li>
			<li>Complete xml comparison on test 4.</li>
			<li>Fix output evaluation for test 5.</li>
		</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @stack xml([utility].[stack_xsc]);
	execute [meta_data_test].[all] @stack=@stack output;
	select @stack as [result_stack];'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'meta_data_test'
                                            , N'procedure'
                                            , N'all'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data_test'
    , @level1type=N'procedure'
    , @level1name=N'all'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data_test'
  , @level1type=N'procedure'
  , @level1name=N'all'

go 
