use [chamomile];

go

if schema_id(N'documentation') is null
  execute (N'create schema documentation');

go

if object_id(N'[documentation].[get]'
             , N'P') is not null
  drop procedure [documentation].[get];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Accessor method for documentation of objects.
	filename:		chamomile.documentation.get.sql
	description:	Get all properties for objects that meet conditions.

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'documentation'
			, @object [sysname] = N'get';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create procedure [documentation].[get]
as
  begin
      declare @schema           [sysname]
              , @object         [sysname]
              , @output         [nvarchar](max)
              , @property_value [sysname]
              , @category       [sysname]
              , @timestamp      [datetime]
              , @property_name  [sysname];

      set @timestamp = current_timestamp;
      --
      -- head and style sheet
      ---------------------------------------------------------------------------------------------
      set @output = N'<!DOCTYPE html><head>
		<style type="text/css">
			body { 
				font-family:Arial,Helvetica,sans-serif;
				margin: 25px;
				padding: 10px;
			}
			h1 { 
				text-align: center; 
			}
			h2 {
				text-align: center; 
				text-indent:15px; 
				font-size:90%
			}
			h3 { 
				text-indent:30px; 
				text-decoration:underline;
				font-size:100%
			}
			h4 { 
				font-size:85%;
				font-family:Arial,Helvetica,sans-serif; 
				font-style:italic;
				word-wrap: break-word; 
				text-indent: 2em;
			}
			p { 
				margin-left: 3em; 
				text-indent: 4em 
				word-wrap: break-word; 
			}
			.definition { 
				margin-left: 3em; 
				text-indent: 4em 
				word-wrap: break-word; 
				font-style:italic;
			}
			.footer { 
				text-align: center;
				color:gray;
				font-size:90%;
				font-family:Arial,Helvetica,sans-serif; 
				margin-left: 3em; 
				text-indent: 4em;
				font-style:italic;
				word-wrap: break-word; 
			}
			summary { 
				font-size:100%;
				font-family:Arial,Helvetica,sans-serif; 
				font-style:italic;
				word-wrap: break-word; 
				text-indent: 3em;
			}
		</style></head><h1>Documentation: ['
                    + db_name() + ']</h1>';
      --
      ---------------------------------------------------------------------------------------------
      set @output = @output + N'<p class="footer">['
                    + object_schema_name(@@procid) + N'].['
                    + object_name(@@procid) + '] '
                    + convert([sysname], current_timestamp, 121)
                    + '</p>';
      set @category = N'Documentation';
      set @output = @output + N'<h4>' + @category + '</h4>' + N'<details class="summary">
				<summary>tables</summary><table border="1">
				<tr>
					<td>[category]</td>
					<td>[database].[schema].[major_object]</td>
					<td>[minor_object]</td>
					<td>[type_description]</td>
					<td>[object_type]</td>
					<td>[property]</td>
					<td>[value]</td>


			</tr>';

      with [get_tables]
           as (select N'table'                        as [category]
                      , [schemas].[name]              as [schema]
                      , [tables].[name]               as [major_object]
                      , null                          as [minor_object]
                      , [objects].[name]              as [type]
                      , N'table'                      as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[tables] as [tables]
                      join [sys].[objects] as [objects]
                        on [objects].[object_id] = [tables].[object_id]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [tables].[schema_id]
                      join [sys].[columns] as [columns]
                        on [columns].[object_id] = [tables].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [tables].[object_id]
                                and [extended_properties].[minor_id] = 0),
           [get_columns]
           as (select N'table'                        as [category]
                      , [schemas].[name]              as [schema]
                      , [tables].[name]               as [major_object]
                      , [object].[name]               as [minor_object]
                      , N'COLUMN'                     as [type]
                      , N'column'                     as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[tables] as [tables]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [tables].[schema_id]
                      join [sys].[columns] as [object]
                        on [object].[object_id] = [tables].[object_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = [object].[column_id]),
           [get_procedures]
           as (select N'procedure'                    as [category]
                      , [schemas].[name]              as [schema]
                      , [procedures].[name]           as [major_object]
                      , null                          as [minor_object]
                      , [objects].[name]              as [type]
                      , N'procedure'                  as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[procedures] as [procedures]
                      join [sys].[objects] as [objects]
                        on [objects].[object_id] = [procedures].[object_id]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [procedures].[schema_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [procedures].[object_id]
                                and [extended_properties].[minor_id] = 0),
           [get_parameters]
           as (select N'procedure'                    as [category]
                      , [schemas].[name]              as [schema]
                      , [procedures].[name]           as [major_object]
                      , [parameters].[name]           as [minor_object]
                      , case
                            when [types].[name] = N'nvarchar'
                                 and [parameters].[max_length] = -1
                                then
                              [types].[name] + N'(max)'
                            when [types].[name] = N'nvarchar'
                                 and [parameters].[max_length] > 0
                                then
                              [types].[name] + N'('
                              + cast([parameters].[max_length]/2 as [sysname])
                              + N')'
                            else
                              [types].[name]
                        end                           as [type]
                      , N'parameter'                  as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[procedures] as [procedures]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [procedures].[schema_id]
                      join [sys].[parameters] as [parameters]
                        on [parameters].[object_id] = [procedures].[object_id]
                      join [sys].[types] as [types]
                        on [types].[user_type_id] = [parameters].[user_type_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [parameters].[object_id]
                                and [extended_properties].[minor_id] = [parameters].[parameter_id]),
           [get_functions]
           as (select N'function'                     as [category]
                      , [schemas].[name]              as [schema]
                      , [object].[name]               as [major_object]
                      , null                          as [minor_object]
                      , [object].[type_desc]          as [type]
                      , N'function'                   as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[objects] as [object]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [object].[schema_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = 0
               where  [object].[type_desc] like N'%fun%'),
           [get_function_parameters]
           as (select N'function'                     as [category]
                      , [schemas].[name]              as [schema]
                      , [object].[name]               as [major_object]
                      , [parameters].[name]           as [minor_object]
                      , case
                            when [types].[name] = N'nvarchar'
                                 and [parameters].[max_length] = -1
                                then
                              [types].[name] + N'(max)'
                            when [types].[name] = N'nvarchar'
                                 and [parameters].[max_length] > 0
                                then
                              [types].[name] + N'('
                              + cast([parameters].[max_length]/2 as [sysname])
                              + N')'
                            else
                              [types].[name]
                        end                           as [type]
                      , N'parameter'                  as [object_type]
                      , [extended_properties].[name]  as [property]
                      , [extended_properties].[value] as [value]
               from   [sys].[objects] as [object]
                      join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [object].[schema_id]
                      join [sys].[parameters] as [parameters]
                        on [parameters].[object_id] = [object].[object_id]
                      join [sys].[types] as [types]
                        on [types].[user_type_id] = [parameters].[user_type_id]
                      left join [sys].[extended_properties] as [extended_properties]
                             on [extended_properties].[major_id] = [object].[object_id]
                                and [extended_properties].[minor_id] = [parameters].[parameter_id]
               where  [object].[type_desc] like N'%fun%'
                      and [parameters].[parameter_id] != 0),
           [union_all]
           as (select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] collate latin1_general_100_cs_as_ks_ws as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_tables]
               union
               select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_columns]
               union
               select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_procedures]
               union
               select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_parameters]
               union
               select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_functions]
               union
               select [category]
                      , [schema]
                      , [major_object]
                      , [minor_object]
                      , [type] as [type_description]
                      , [object_type]
                      , [property]
                      , [value]
               from   [get_function_parameters])
      select @output = coalesce (@output + N' ', N'')
                       --
                       + N'<tr>'
                       --
                       + N'<td>' + cast([category] as [sysname])
                       + N'</td>' + N'<td>[' + db_name() + N'].['
                       + cast([schema] as [sysname]) + N'].['
                       + cast([major_object] as [sysname])
                       + N']</td>' + N'<td>'
                       + cast(isnull([minor_object], N'') as [sysname])
                       + N'</td>' + N'<td>'
                       + cast([type_description] as [sysname])
                       + N'</td>' + N'<td>'
                       + cast([object_type] as [sysname])
                       + N'</td>' + N'<td>'
                       + cast(isnull([property], N'') as [sysname])
                       + N'</td>' + N'<td>'
                       + cast(isnull([value], N'') as [nvarchar](max))
                       + N'</td>'
                       --
                       + N'</tr>'
      from   [union_all]
      order  by [category]
                , [schema]
                , [major_object]
                , [minor_object]
                , [type_description]
                , [object_type]
                , [property];

      set @output = @output + N'</table></details>';
      set @output = @output + N'</html>';
      --
      -- footer
      ---------------------------------------------------------------------------------------------
      set @output = @output + N'<p class="footer">['
                    + object_schema_name(@@procid) + N'].['
                    + object_name(@@procid) + '] '
                    + convert([sysname], current_timestamp, 121)
                    + '</p>
		</body></html>';

      select @output;
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'todo'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'procedure'
                                            , N'get'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'todo - use minor id to pick up columns and parameters'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'procedure'
                                            , N'get'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'procedure'
    , @level1name=N'get'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'procedure'
  , @level1name=N'get'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'execute [documentation].[get];'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'documentation'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'documentation'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'documentation'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go 
