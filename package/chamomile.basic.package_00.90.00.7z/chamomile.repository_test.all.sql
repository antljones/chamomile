use [chamomile]

go

if schema_id(N'repository_test') is null
  execute (N'create schema repository_test');

go

if exists (select *
           from   sys.objects
           where  object_id = object_id(N'[repository_test].[all]')
                  and type in ( N'P' ))
  drop procedure [repository_test].[all]

go

use [chamomile]

go

set ansi_nulls on

go

set quoted_identifier on

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Test method for [repository_secure].[get] and [repository_secure].[set]
	filename:		repository_test.all.sql

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'repository'
			, @object [sysname] = N'get';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 

	--
	-- execute_as
	-------------------------------------------------------------------------
	declare @stack xml([utility].[stack_xsc]);
	execute [repository_test].[all] @stack=@stack output;
	select @stack; 
	
*/
create procedure [repository_test].[all]
  @stack xml([utility].[stack_xsc]) output
as
  begin
      set nocount on;
      set transaction isolation level serializable;

      declare @transaction        [sysname] = N'repository_test_all_'
                + cast(round(rand()*100000, -1) as [sysname])
                + N'_'
                + cast(datepart(millisecond, current_timestamp) as [sysname])
              , @message          [nvarchar](max)
              , @subject_fqn      [nvarchar](1000)
              , @object_fqn       [nvarchar](1000)
              , @test             xml([utility].[stack_xsc])
              , @test_object      [xml]
              , @count            [int]
              , @test_number      [int]
              , @test_name        [sysname]
              , @actual           [sysname]
              , @test_description [nvarchar](max)
              , @expected         [nvarchar](max)
              , @stack_builder    [xml]
              , @builder          [xml]
              , @name             [nvarchar](1000) = N''
              , @value            [sysname]=N''
              , @constraint       [nvarchar](max)
              , @description      [nvarchar](max);

      --
      -----------------------------------------------------------------------
      begin
          set @subject_fqn = N'['
                             + convert([sysname], serverproperty(N'MachineName'))
                             + '].['
                             + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                             + '].['
                             + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                             + N'].[' + db_name() + '].['
                             + object_schema_name(@@procid) + '].['
                             + object_name(@@procid) + ']';
          set @object_fqn = N'[chamomile].[repository_secure].[set]_[chamomile].[repository_secure].[get]';
          set @stack_builder = isnull(@stack
                                      , [utility].[get_object](N'[chamomile].[test].[stack]'
                                                               , N'prototype'));
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
						replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/subject/@name)[1] with sql:variable("@subject_fqn")');
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
		replace value of (/chamomile:stack/object/@name)[1] with sql:variable("@object_fqn")');
          set @test_description = N'Test all repository accessor and mutator methods.';
          set @stack_builder.modify(N'declare namespace chamomile="http://www.katherinelightsey.com/"; 
			insert text {sql:variable("@test_description")} as last into (/chamomile:stack/result/description)[1]')
      end

      --
      -----------------------------------------------------------------------
      begin
          if @@trancount = 0
            begin transaction @transaction;
          else
            begin
                set @message = N'Cannot run test due to existing @@trancount.';

                raiserror(51000, @message, 1);
            end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=1;
              set @test_name = N'[repository_test].[all].[build_meta_data_stack]';
              set @test_description = N'Create a typed meta data stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-25T14:21:23.463">
					  <subject name="[MCK790L8159].[MCK790L8159].[CHAMOMILE].[test].[repository_secure].[data.preload_script.sql]" unique="true" />
					  <object name="[chamomile].[test].[suffix]" object_type="meta_data" unique="true">
						<chamomile:meta_data xmlns:chamomile="http://www.katherinelightsey.com/" name="[category].[class].[type]" value="_test" constraint="|ab._- c|ab._- c|" unique="true">
						  <description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
						</chamomile:meta_data>
					  </object>
					</chamomile:stack>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=2;
              set @test_name = N'[repository_test].[all].[build_meta_data_object]';
              set @test_description = N'Create a typed meta data object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:meta_data xmlns:chamomile="http://www.katherinelightsey.com/" name="[category].[class].[type]" value="_test" constraint="|ab09._- c|ab.123_- c|" unique="true">
					  <description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
					</chamomile:meta_data>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=3;
              set @test_name = N'[repository_test].[all].[build_error]';
              set @test_description = N'Create a typed error object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-08T15:31:17.403">
					  <subject name="[SYLVIA].[SYLVIA].[INSTANCE_01].[chamomile].[utility_ut].[object_stack_xsc]" unique="true" />
					  <object object_type="error" unique="true">
						<valid_xml />
					  </object>
					  <result result_type="error" />
					</chamomile:stack>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=4;
              set @test_name = N'[repository_test].[all].[build_receiver]';
              set @test_description = N'Create a typed receiver object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:command xmlns:chamomile="http://www.katherinelightsey.com/" > 
						<receiver frequency="1" timestamp="2014-06-08T15:31:17.403" > 
							<parameters /> 
							<sql /> 
						</receiver> 
					</chamomile:command>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=5;
              set @test_name = N'[repository_test].[all].[build_workflow]';
              set @test_description = N'Create a typed workflow object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" > 
						<command name="name" /> 
					</chamomile:workflow>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=6;
              set @test_name = N'[repository_test].[all].[build_complex_workflow]';
              set @test_description = N'Create a typed complex workflow object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" > 
						<command name="name" /> 
						<command name="name" /> 
						<workflow name="name" /> 
						<workflow name="name" /> 
					</chamomile:workflow>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=7;
              set @test_name = N'[repository_test].[all].[build_simple_workflow]';
              set @test_description = N'Create a typed simple workflow object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" />';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=8;
              set @test_name = N'[repository_test].[all].[build_test]';
              set @test_description = N'Create a typed test object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:test xmlns:chamomile="http://www.katherinelightsey.com/" sequence="1" name="[category].[class].[type]" expected="fail" actual="fail" timestamp="2014-06-25T16:41:55.960">
						<description />
					</chamomile:test>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=9;
              set @test_name = N'[repository_test].[all].[build_test]';
              set @test_description = N'Create a typed test object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:test xmlns:chamomile="http://www.katherinelightsey.com/" sequence="1" name="[category].[class].[type]" expected="fail" actual="fail" timestamp="2014-06-25T16:41:55.960">
						<description />
					</chamomile:test>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=10;
              set @test_name = N'[repository_test].[all].[build_complex_test]';
              set @test_description = N'Create a typed complex test object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:test xmlns:chamomile="http://www.katherinelightsey.com/" sequence="1" name="[category].[class].[type]" expected="fail" actual="fail" timestamp="2014-06-25T16:41:55.960">
						<description>text field</description>
						<valid_xml />
					</chamomile:test>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=11;
              set @test_name = N'[repository_test].[all].[build_complex_test]';
              set @test_description = N'Create a typed complex test object.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @test = N'<chamomile:test xmlns:chamomile="http://www.katherinelightsey.com/" sequence="1" name="[category].[class].[type]" expected="fail" actual="fail" timestamp="2014-06-25T16:41:55.960">
						<description>text field</description>
						<valid_xml />
					</chamomile:test>';
                  set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=12;
              set @test_name = N'[repository_test].[all].[build_and_set_meta_data_stack]';
              set @test_description = N'Create and set a typed meta data stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*10000, -1) as [nvarchar](1000))
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  if(select [meta_data].[get](@name)) = @value
                    set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          begin
              set @test_number=13;
              set @test_name = N'[repository_test].[all].[build_and_update_meta_data_stack]';
              set @test_description = N'Create and update a typed meta data stack.';
              set @expected = N'pass';
              set @actual = N'fail';
              --
              -------------------------------------------------------------------------------------
              set @test_object = [utility].[get_object](N'[chamomile].[test].[object]'
                                                        , N'prototype');
              set @test_object.modify(N'replace value of (/*/@sequence)[1] with sql:variable("@test_number")');
              set @test_object.modify(N'replace value of (/*/@name)[1] with sql:variable("@test_name")');
              set @test_object.modify(N'insert text {sql:variable("@test_description")} as last into (/*/description)[1]')
              set @test_object.modify(N'replace value of (/*/@expected)[1] with sql:variable("@expected")');

              --
              -------------------------------------------------------------------------------------
              begin try
                  set @name = N'[category].[class].[description_'
                              + cast(round(rand()*10000, -1) as [nvarchar](1000))
                              + N']';
                  set @value = N'test_value';
                  set @constraint = null;
                  set @description = N'test';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  set @value = N'test_value2';

                  execute [meta_data].[set]
                    @name          = @name
                    , @value       = @value
                    , @constraint  = @constraint
                    , @description = @description
                    , @stack       =@stack output;

                  if(select [meta_data].[get](@name)) = @value
                    set @actual=N'pass';
              end try

              begin catch
                  select @test_number as [test_number]
                         , @test_name as [test_name]
                         , error_message();
              end catch

              set @test_object.modify(N'replace value of (/*/@actual)[1] with sql:variable("@actual")');
              set @builder=@test;
              set @test_object.modify(N'insert sql:variable("@builder") as last into (/*)[1]');
              set @stack_builder.modify(N'insert sql:variable("@test_object") as last into (/*/result)[1]');
          end

          --
          ---------------------------------------------------------------------------------------------
          if exists(select *
                    from   [sys].[dm_tran_active_transactions]
                    where  [name] = @transaction)
            rollback transaction @transaction;

          --
          -- Total results
          ---------------------------------------------------------------------------------------------
          begin
              set @count = @stack_builder.value(N'count (/*/result/*)'
                                                , 'int') - 1; -- subtract 1 for <description />
              set @stack_builder.modify(N'replace value of (/*/result/@test_count)[1] with sql:variable("@count")');
              set @count = @stack_builder.value(N'count (/*/result/*[@expected=@actual])'
                                                , 'int');
              set @stack_builder.modify(N'replace value of (/*/result/@pass_count)[1] with sql:variable("@count")');
              set @count = @stack_builder.value(N'count (/*/result/*[@expected!=@actual])'
                                                , 'int');
              set @stack_builder.modify(N'replace value of (/*/result/@error_count)[1] with sql:variable("@count")');
          end

          set @stack=@stack_builder;
      end
  end

go 
