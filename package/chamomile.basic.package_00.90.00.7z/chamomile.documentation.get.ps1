

	param([string]$serverinstance, [string]$database);
	BCP "execute [documentation].[get];" queryout chamomile.basic.documentation.html -t, -T -c -d $database -S $serverinstance;