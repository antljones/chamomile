use [chamomile];

go

if schema_id(N'utility') is null
  execute (N'create schema utility');

go

set nocount on;

go

if exists (select xml_collection_id
           from   sys.xml_schema_collections as xsc
           where  xsc.name = 'stack_xsc'
                  and xsc.schema_id = schema_id(N'utility'))
  drop xml schema collection [utility].[stack_xsc];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			XML Schema Collection used to type [chamomile] objects.
	filename:		utility.stack_xsc.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	select objtype
		   , objname
		   , name
		   , value
	from   fn_listextendedproperty (null
									, 'schema'
									, 'utility'
									, 'xml schema collection'
									, 'stack_xsc'
									, default
									, default);

*/
create xml schema collection [utility].[stack_xsc] as N'<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:chamomile="http://www.katherinelightsey.com/" targetNamespace="http://www.katherinelightsey.com/">

    <xsd:element name="stack" type="chamomile:stack_type" />
	<xsd:element name="command" type="chamomile:command_complex_type" />
	<xsd:element name="workflow" type="chamomile:workflow_complex_type" />
	<xsd:element name="meta_data" type="chamomile:meta_data_complex_type" />
	<xsd:element name="test" type="chamomile:test_complex_type" />

    <xsd:complexType name="stack_type">
      <xsd:complexContent>
        <xsd:restriction base="xsd:anyType">
          <xsd:sequence>
			<xsd:element name="subject" type="chamomile:subject_complex_type" />
            <xsd:element name="object" type="chamomile:object_complex_type" minOccurs="0" maxOccurs="unbounded" />
            <xsd:element name="meta_data" type="chamomile:object_complex_type" minOccurs="0" maxOccurs="unbounded" />
            <xsd:element name="result" type="chamomile:result_complex_type" minOccurs="0" maxOccurs="unbounded" />
          </xsd:sequence>
          <xsd:attribute name="timestamp" type="xsd:dateTime" use="required" />
		  <xsd:anyAttribute processContents="lax" />
        </xsd:restriction>
      </xsd:complexContent>
    </xsd:complexType>

	<xsd:complexType name="test_complex_type">
		<xsd:complexContent>
			<xsd:restriction base="xsd:anyType">
				<xsd:sequence>
					<xsd:element name="description" type="xsd:string" minOccurs="1" maxOccurs="1" />
					<xsd:any minOccurs="0" maxOccurs="unbounded" processContents="lax"/>
				</xsd:sequence>
				<xsd:attribute name="name" type="chamomile:fqn_3_pattern" use="required" />
				<xsd:attribute name="sequence" type="xsd:int" use="required" />
				<xsd:attribute name="expected" type="chamomile:pass_fail_type" default="fail" />
				<xsd:attribute name="actual" type="chamomile:pass_fail_type" use="required" />
          <xsd:attribute name="timestamp" type="xsd:dateTime" use="required" />
			</xsd:restriction>
		</xsd:complexContent>
	</xsd:complexType>

	<xsd:complexType name="meta_data_complex_type">
		<xsd:complexContent>
			<xsd:restriction base="xsd:anyType">
				<xsd:sequence>
					<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1" />
				</xsd:sequence>
				<xsd:attribute name="name" type="chamomile:fqn_3_pattern" use="required" />
				<xsd:attribute name="value" type="xsd:string" use="required" />
				<xsd:attribute name="constraint" type="chamomile:meta_data_constraint" />
				<xsd:attribute name="unique" type="chamomile:boolean_type" fixed="true" />
			</xsd:restriction>
		</xsd:complexContent>
	</xsd:complexType>
	
	<xsd:complexType name="subject_complex_type">
		<xsd:complexContent>
			<xsd:restriction base="xsd:anyType">
				<xsd:sequence>
					<xsd:any minOccurs="0" maxOccurs="unbounded" processContents="lax"/>
				</xsd:sequence>
				<xsd:attribute name="name" type="chamomile:fqn_pattern" use="required" />
				<xsd:anyAttribute processContents="lax" />
			</xsd:restriction>
		</xsd:complexContent>
	</xsd:complexType>

	<xsd:complexType name="object_complex_type">
		<xsd:complexContent>
			<xsd:restriction base="xsd:anyType">
				<xsd:sequence>
					<xsd:any minOccurs="0" maxOccurs="unbounded" processContents="lax"/>
				</xsd:sequence>
				<xsd:attribute name="object_type" type="chamomile:object_type" use="required" />
				<xsd:attribute name="unique" type="chamomile:boolean_type" default="true" />
				<xsd:anyAttribute processContents="lax" />
			</xsd:restriction>
		</xsd:complexContent>
	</xsd:complexType>

    <xsd:complexType name="receiver_complex_type" >
        <xsd:sequence>
            <xsd:element name="parameters" type="xsd:string" />
            <xsd:element name="sql" type="xsd:string" />
        </xsd:sequence>
		<xsd:attribute name="frequency" type="xsd:unsignedLong" use="required"/>
        <xsd:attribute name="timestamp" type="xsd:dateTime" use="required" />
    </xsd:complexType>

    <xsd:complexType name="command_complex_type" >
      <xsd:sequence>
            <xsd:element name="receiver" type="chamomile:receiver_complex_type" />
      </xsd:sequence>
    </xsd:complexType>
	
	<xsd:complexType name="workflow_complex_type">
      <xsd:sequence>
        <xsd:element name="command" form="unqualified" minOccurs="0" maxOccurs="unbounded" >
          <xsd:complexType>
            <xsd:attribute name="name" form="unqualified" type="xsd:string" />
          </xsd:complexType>
        </xsd:element>
        <xsd:element name="workflow" form="unqualified" minOccurs="0" maxOccurs="unbounded" >
          <xsd:complexType>
            <xsd:attribute name="name" form="unqualified" type="xsd:string" />
          </xsd:complexType>
        </xsd:element>
      </xsd:sequence>
      <xsd:attribute name="name" form="unqualified" type="xsd:string" />
    </xsd:complexType>

	<xsd:complexType name="result_complex_type">
		<xsd:complexContent>
			<xsd:restriction base="xsd:anyType">
				<xsd:sequence>
					<xsd:any minOccurs="0" maxOccurs="unbounded" processContents="lax"/>
				</xsd:sequence>
				<xsd:attribute name="result_type" type="chamomile:object_type" use="required" />
				<xsd:attribute name="unique" type="chamomile:boolean_type" default="true" />
				<xsd:anyAttribute processContents="lax" />
			</xsd:restriction>
		</xsd:complexContent>
	</xsd:complexType>

  <xsd:simpleType name="object_type">
    <xsd:restriction base="xsd:NMTOKEN">
      <xsd:enumeration value="error" />
      <xsd:enumeration value="result" />
      <xsd:enumeration value="test" />
      <xsd:enumeration value="command" />
      <xsd:enumeration value="workflow" />
      <xsd:enumeration value="documentation" />
      <xsd:enumeration value="meta_data" />
      <xsd:enumeration value="prototype" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="fqn_pattern">
    <xsd:restriction base="xsd:string">
      <xsd:pattern value="\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\]" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="fqn_3_pattern">
    <xsd:restriction base="xsd:string">
      <xsd:pattern value="\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\].\[[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}\]" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="sysname">
    <xsd:restriction base="xsd:string">
      <xsd:pattern value="[a-zA-Z]{1}[a-zA-Z0-9._-]{0,128}" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="meta_data_constraint">
    <xsd:restriction base="xsd:string">
      <xsd:pattern value="(\|{1}([a-zA-Z0-9 ._-])*)+\|{1}" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="boolean_type">
    <xsd:restriction base="xsd:NMTOKEN">
      <xsd:enumeration value="true" />
      <xsd:enumeration value="false" />
    </xsd:restriction>
  </xsd:simpleType>

  <xsd:simpleType name="pass_fail_type">
    <xsd:restriction base="xsd:NMTOKEN">
      <xsd:enumeration value="pass" />
      <xsd:enumeration value="fail" />
    </xsd:restriction>
  </xsd:simpleType>

</xsd:schema>';

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'xml schema collection'
                                            , N'stack_xsc'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'xml schema collection'
    , @level1name=N'stack_xsc'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'xml schema collection'
  , @level1name=N'stack_xsc'

go

if exists (select *
           from   fn_listextendedproperty(N'description'
                                          , N'SCHEMA'
                                          , N'utility'
                                          , N'xml schema collection'
                                          , N'stack_xsc'
                                          , default
                                          , default))
  exec sys.sp_dropextendedproperty
    @name         = N'description'
    , @level0type = N'SCHEMA'
    , @level0name = N'utility'
    , @level1type = N'xml schema collection'
    , @level1name = N'stack_xsc'
    , @level2type = default
    , @level2name = default;

go

exec sys.sp_addextendedproperty
  @name         = N'description'
  , @value      = N'Used as the validation type for building object stacks in the [utility] schema.'
  , @level0type = N'SCHEMA'
  , @level0name = N'utility'
  , @level1type = N'xml schema collection'
  , @level1name = N'stack_xsc'
  , @level2type = default
  , @level2name = default;

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'xml schema collection'
                                            , N'stack_xsc'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'xml schema collection'
    , @level1name=N'stack_xsc'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'xml schema collection'
  , @level1name=N'stack_xsc'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'xml schema collection'
                                            , N'stack_xsc'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'xml schema collection'
    , @level1name=N'stack_xsc'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'xml schema collection'
  , @level1name=N'stack_xsc'

go 
