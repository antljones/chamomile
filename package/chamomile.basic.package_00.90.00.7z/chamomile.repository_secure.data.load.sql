/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Preload data into [repository_secure].[data].
	filename:		C:\Users\KELIGHTSEY\Dropbox\public\chamomile.repository_secure.data.preload_script.sql
	prerequisites:	
	description:	
		
	--
	-- Notes
	----------------------------------------------------------------------
	
	--
	-- References
	----------------------------------------------------------------------
*/
use [chamomile];

go

set nocount on;

go

truncate table [repository_secure].[data];

go

declare @stack         [xml]
        , @subject_fqn [xml]
        , @object_fqn  [xml]
        , @object      [nvarchar](1000);

set @subject_fqn = N'['
                   + convert([sysname], serverproperty(N'MachineName'))
                   + '].['
                   + convert([sysname], serverproperty(N'ComputerNamePhysicalNetBIOS'))
                   + '].['
                   + isnull(convert([sysname], serverproperty(N'InstanceName')), N'default')
                   + N'].[' + db_name()
                   + N'].[repository_secure].[data.preload_script.sql]';
--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[utility].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="prototype" unique="true" />
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);
set @object_fqn = N'[chamomile].[utility].[result_stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="prototype" unique="true" />
	  <result result_type="result" />
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);


--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[meta_data].[xml_stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="meta_data" unique="true" >
		<description />
	  </object>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[meta_data].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="prototype" value="_test" constraint="" unique="true" >
		<description />
	  </object>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[test].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="test" unique="true" />
	  <result result_type="test" test_count="0" pass_count="0" error_count="0" >
		<description />
	  </result>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[test].[object]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:test xmlns:chamomile="http://www.katherinelightsey.com/" sequence="0" name="[category].[class].[type]" expected="fail" actual="fail" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	<description />
	</chamomile:test>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);


--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[error].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="error" unique="true" />
	  <result result_type="error" error_procedure="" error_number="" error_line="" error_severity="" error_state="" >
		<error_message />
	  </result>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[test].[suffix]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="meta_data" value="_test" constraint="" unique="true">
		<description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[test].[suffix_02]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="meta_data" value="_test_02" constraint="" unique="true">
		<description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);

--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[command].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="test" unique="true" >
		<chamomile:command xmlns:chamomile="http://www.katherinelightsey.com/" > 
            <receiver frequency="1" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
                <parameters /> 
                <sql /> 
            </receiver> 
        </chamomile:command>

	  </object>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);
--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[receiver].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="test" unique="true" >
            <chamomile:receiver xmlns:chamomile="http://www.katherinelightsey.com/" frequency="1" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
                <parameters /> 
                <sql /> 
            </chamomile:receiver> 

	  </object>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);


--
--------------------------------------------------------------------------
set @object_fqn = N'[chamomile].[workflow].[stack]';
set @stack = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
  <subject name="'
             + cast(@subject_fqn as [nvarchar](max))
             + '" unique="true" />
  <object name="'
             + cast(@object_fqn as [nvarchar](max))
             + '" object_type="prototype" unique="true">
    
	<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="'
             + convert([sysname], current_timestamp, 126)
             + '">
	  <subject name="[computer_physical_netbios].[machine].[instance].[database].[schema].[subject]" unique="false" />
	  <object name="[computer_physical_netbios].[machine].[instance].[database].[schema].[object]" object_type="prototype" unique="true" >

		<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" />

	  </object>
	</chamomile:stack>

  </object>
</chamomile:stack>';

insert into [repository_secure].[data]
            ([entry])
values      (@stack);



go 

-- select * from [repository_secure].[data]