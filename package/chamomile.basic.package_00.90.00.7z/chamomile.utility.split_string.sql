use [chamomile];

go

if exists (select *
           from   sys.objects
           where  object_id = object_id(N'[utility].[split_string]')
                  and type in ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  drop function [utility].[split_string]

go

set ansi_nulls on

go

set quoted_identifier on

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Splits a string based on a separator and returns a table of the segments.
	filename:		chamomile.utility.split_string.sql
		
	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'utility'
			, @object [sysname] = N'split_string';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create function [utility].[split_string] (
  @input       [nvarchar](max)
  , @separator [char](1))
returns table
as
    return (
      with tokens(p, a, b)
           as (select cast(1 as bigint)
                      , cast(1 as bigint)
                      , charindex(@separator
                                  , @input)
               union all
               select p + 1
                      , b + 1
                      , charindex(@separator
                                  , @input
                                  , b + 1)
               from   tokens
               where  b > 0)
      select p - 1              [index]
             , substring(@input
                         , a
                         , case
                               when b > 0
                                   then
                                 b - a
                               else
                                 len(@input)
                           end) as [node]
       from   tokens);

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'split_string'
                                            , N'PARAMETER'
                                            , N'@input'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'split_string'
    , @level2type=N'PARAMETER'
    , @level2name=N'@input'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@input nvarchar(max) - The string to split.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'split_string'
  , @level2type=N'PARAMETER'
  , @level2name=N'@input'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'split_string'
                                            , N'PARAMETER'
                                            , N'@separator'))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'split_string'
    , @level2type=N'PARAMETER'
    , @level2name=N'@separator'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'@separator char(1) - The character on which to split the string.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'split_string'
  , @level2type=N'PARAMETER'
  , @level2name=N'@separator'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'split_string'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'split_string'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'[utility].[split_string] splits a string based on a single character value and returns a table with the nodes. [utility].[split_string] is based on code I found at http://stackoverflow.com/questions/2647/split-string-in-sql. While I have taken it and refactored it to match the standards I use in Chamomile, credit should go to the original author for the design.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'split_string'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'split_string'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'split_string'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'<ol>
		<li>select [index],[node] from [utility].[split_string] (N''aa.aba.ac'', N''.'');</li>
		<li>select [index],[node] from [utility].[split_string] (N''254-372-4569, (817) 956-3259, +052 1234 5678'', N'','');</li>
		<li>select [index],[node] from [utility].[split_string] (N''12.0.2000.8'', N''.'');</li>
	</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'split_string'

go

if exists (select *
           from   ::fn_listextendedproperty(N'get_license'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'FUNCTION'
                                            , N'split_string'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'get_license'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'FUNCTION'
    , @level1name=N'split_string'

go

exec sys.sp_addextendedproperty
  @name        =N'get_license'
  , @value     =N'execute [documentation].[get_license];'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'FUNCTION'
  , @level1name=N'split_string'

go 

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'function'
                                            , N'split_string'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'split_string'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'split_string'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'utility'
                                            , N'function'
                                            , N'split_string'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'utility'
    , @level1type=N'function'
    , @level1name=N'split_string'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'utility'
  , @level1type=N'function'
  , @level1name=N'split_string'

go 
