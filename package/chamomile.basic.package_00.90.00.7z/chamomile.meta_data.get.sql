use [chamomile];

go

if schema_id(N'meta_data') is null
  execute (N'create schema meta_data');

go

if object_id(N'[meta_data].[get]'
             , N'FN') is not null
  drop function [meta_data].[get];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Adapter method for [repository].[get] that returns a meta data object.
	filename:		utility.get_meta_data.sql

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'meta_data'
			, @object [sysname] = N'get';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 
*/
create function [meta_data].[get] (
  @name [nvarchar](max))
returns [nvarchar](max)
as
  begin
      declare @return [nvarchar](max);

      set @return = (select [value]
                     from   [meta_data].[get_list] (@name)
                     where  [name] = @name);

      return @return;
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'description'
  , @value     =N'todo'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'execute_as'
  , @value     =N'declare @name [nvarchar](1000) = N''[chamomile].[test].[suffix]'';
	select [meta_data].[get] (@name);'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140618'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140618'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140618'
  , @value     =N'Katherine E. Lightsey - created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'meta_data'
                                            , N'FUNCTION'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'meta_data'
    , @level1type=N'FUNCTION'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'meta_data'
  , @level1type=N'FUNCTION'
  , @level1name=N'get'

go 
