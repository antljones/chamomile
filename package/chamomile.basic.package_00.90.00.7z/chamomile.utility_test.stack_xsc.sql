use [chamomile];
go

declare @stack xml([utility].[stack_xsc]) = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-25T14:21:23.463">
  <subject name="[MCK790L8159].[MCK790L8159].[CHAMOMILE].[test].[repository_secure].[data.preload_script.sql]" unique="true" />
  <object name="[chamomile].[test].[suffix]" object_type="meta_data" unique="true">
    <chamomile:meta_data xmlns:chamomile="http://www.katherinelightsey.com/" name="[category].[class].[type]" value="_test" constraint="|ab._- c|ab._- c|" unique="true">
      <description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
    </chamomile:meta_data>
  </object>
</chamomile:stack>';

go

declare @stack xml([utility].[stack_xsc]) = N'<chamomile:meta_data xmlns:chamomile="http://www.katherinelightsey.com/" name="[category].[class].[type]" value="_test" constraint="|ab09._- c|ab.123_- c|" unique="true">
      <description>Default suffix for schemas used for test objects. Used by [chamomile].[test].[run] to find tests.</description>
    </chamomile:meta_data>';

go

declare @stack xml([utility].[stack_xsc]) = N'<chamomile:stack xmlns:chamomile="http://www.katherinelightsey.com/" timestamp="2014-06-08T15:31:17.403">
  <subject name="[SYLVIA].[SYLVIA].[INSTANCE_01].[chamomile].[utility_ut].[object_stack_xsc]" unique="true" />
  <object object_type="error" unique="true">
    <valid_xml />
  </object>
  <result result_type="error" />
</chamomile:stack>';

go

declare @command xml([utility].[stack_xsc]) = N'
		<chamomile:command xmlns:chamomile="http://www.katherinelightsey.com/" > 
            <receiver frequency="1" timestamp="2014-06-08T15:31:17.403" > 
                <parameters /> 
                <sql /> 
            </receiver> 
        </chamomile:command>';

go

declare @workflow xml([utility].[stack_xsc]) = N'
		<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" > 
            <command name="name" /> 
        </chamomile:workflow>';

go

declare @workflow xml([utility].[stack_xsc]) = N'
		<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" > 
            <command name="name" /> 
            <command name="name" /> 
            <workflow name="name" /> 
            <workflow name="name" /> 
        </chamomile:workflow>';

go

declare @workflow xml([utility].[stack_xsc]) = N'
		<chamomile:workflow xmlns:chamomile="http://www.katherinelightsey.com/" />';

go 
