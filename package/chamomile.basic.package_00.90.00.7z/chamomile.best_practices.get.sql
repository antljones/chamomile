use [chamomile];

go

if schema_id(N'best_practices') is null
  execute (N'create schema best_practices');

go

if object_id(N'[best_practices].[get]'
             , N'P') is not null
  drop procedure [best_practices].[get];

go

/*
	--
	-- License
	----------------------------------------------------------------------
	Katherine E. Lightsey
	http://www.katherinelightsey.com
	
	This software is licensed as [chamomile] (http://www.katherinelightsey.com/#!license/cjlz) 
		and as open source under the GNU Affero GPL (http://www.gnu.org/licenses/agpl-3.0.html).

	--
	-- Description
	----------------------------------------------------------------------
	title:			Returns analysis of best practices on current database.
	filename:		chamomile.best_practices.get.sql

	--
	-- to view documentation
	-----------------------------------------------------------------------------------------------
	declare @schema   [sysname] = N'best_practices'
			, @object [sysname] = N'get';

	select [sch].[name]
		   , [obj].[name]
		   , [prop].[name]
		   , [prop].[value]
	from   [sys].[extended_properties] as [prop]
		   join [sys].[objects] as [obj]
			 on [obj].[object_id] = [prop].[major_id]
		   join [sys].[schemas] as [sch]
			 on [obj].[schema_id] = [sch].[schema_id]
	where  [sch].[name] = @schema
		   and [obj].[name] = @object; 

		  execute [best_practices].[get]
		
*/
create procedure [best_practices].[get]
as
  begin
      declare @count           [int]
              , @category      [sysname]
              , @output        [nvarchar](max)
              , @documentation [xml]
              , @timestamp     [datetime];

      --
      -- head and style sheet
      ---------------------------------------------------------------------------------------------
      set @output = N'<!DOCTYPE html><head>
		<style type="text/css">
			body { 
				font-family:Arial,Helvetica,sans-serif;
				margin: 25px;
				padding: 10px;
			}
			h1 { 
				text-align: center; 
			}
			h2 {
				text-align: center; 
				text-indent:15px; 
				font-size:90%
			}
			h3 { 
				text-indent:30px; 
				text-decoration:underline;
				font-size:100%
			}
			h4 { 
				font-size:85%;
				font-family:Arial,Helvetica,sans-serif; 
				font-style:italic;
				word-wrap: break-word; 
				text-indent: 2em;
			}
			p { 
				margin-left: 3em; 
				text-indent: 4em 
				word-wrap: break-word; 
			}
			.definition { 
				margin-left: 3em; 
				text-indent: 4em 
				word-wrap: break-word; 
				font-style:italic;
			}
			.footer { 
				text-align: center;
				color:gray;
				font-size:90%;
				font-family:Arial,Helvetica,sans-serif; 
				margin-left: 3em; 
				text-indent: 4em;
				font-style:italic;
				word-wrap: break-word; 
			}
			summary { 
				font-size:100%;
				font-family:Arial,Helvetica,sans-serif; 
				font-style:italic;
				word-wrap: break-word; 
				text-indent: 3em;
			}
		</style></head><h1>Best Practices Analysis</h1>'
                    + N'<h2>' + db_name() + '</h2><body>';
      --
      ---------------------------------------------------------------------------------------------
      set @output = @output + N'<p class="footer">['
                    + object_schema_name(@@procid) + N'].['
                    + object_name(@@procid) + '] '
                    + convert([sysname], current_timestamp, 121)
                    + '</p>';

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @output = @output
                        + '<details class="summary">
				<summary>Naming Violations</summary><ol>';

          --
          ---------------------------------------------------------------------------------------------------
          begin
              set @category = N'DEFAULT CONSTRAINT';
              set @output = @output + N'<h4>' + @category + '</h4>'
                            + N'<p><u>standard definition</u>: <div class="definition">"...where [default_constraints].[name] not like ( N''['' + [schemas].[name] + N''.'' + [tables].[name] + N''.'' + [columns].[name].default]"</div></p><details class="summary">
				<summary>Violations</summary><ol>';

              select @output = coalesce(@output + ' ', '')
                               + N'<li class="violation" >['
                               + [schemas].[name] + N'].['+ + [tables].[name]
                               + N'].[' + [columns].[name] + N'].['
                               + [default_constraints].[name] + N']</li>'
              from   [sys].[default_constraints] as [default_constraints]
                     join [sys].[schemas] as [schemas]
                       on [schemas].[schema_id] = [default_constraints].[schema_id]
                     join [sys].[tables] as [tables]
                       on [tables].[object_id] = [default_constraints].[parent_object_id]
                     join [sys].[columns] as [columns]
                       on [columns].[column_id] = [default_constraints].[parent_column_id]
                          and [columns].[object_id] = [default_constraints].[parent_object_id]
              where  [default_constraints].[name] not like lower(N'' + [schemas].[name] + N'.' + [tables].[name]
                                                                 + N'.' + [columns].[name] + N'.default');

              set @output = @output + N'</ol></details>';
          end

          --
          ---------------------------------------------------------------------------------------------------
          begin
              set @category = N'UNIQUE CONSTRAINT';
              set @output = @output + N'<h4>' + @category + '</h4>'
                            + N'<p><u>standard definition</u>: <div class="definition">"...where  [indexes].[is_unique_constraint] = 1 and [indexes].[name] not like ( N''UQ__'' + [schemas].[name] + N''_'' + [tables].[name] + N''_'' + [columns].[name] "</div></p><details class="summary">
				<summary>Violations</summary><ol>';

              select @output = coalesce(@output + ' ', '')
                               + N'<li class="violation" >['
                               + [schemas].[name] + N'].['+ + [tables].[name]
                               + N'].[' + [columns].[name] + N'].['
                               + [indexes].[name] + N']</li>'
              from   [sys].[indexes] as [indexes]
                     join [sys].[index_columns] as [index_columns]
                       on [indexes].[index_id] = [index_columns].[index_id]
                          and [indexes].[object_id] = [index_columns].[object_id]
                     join [sys].[tables] as [tables]
                       on [tables].[object_id] = [index_columns].[object_id]
                     join [sys].[schemas] as [schemas]
                       on [schemas].[schema_id] = [tables].[schema_id]
                     join [sys].[columns] as [columns]
                       on [columns].[column_id] = [index_columns].[column_id]
                          and [columns].[object_id] = [index_columns].[object_id]
              where  [indexes].[is_unique_constraint] = 1
                     and [indexes].[name] not like lower([schemas].[name] + N']' + [tables].[name] + N'.'
                                                         + [columns].[name] + N'.unique');

              set @output = @output + N'</ol></details>';
          end

          --
          ---------------------------------------------------------------------------------------------------
          begin
              set @category = N'PRIMARY KEY';
              set @output = @output + N'<h4>' + @category + '</h4>'
                            + N'<p><u>standard definition</u>: <div class="definition">"...where [indexes].[is_primary_key] = 1
                          and [indexes].[name] not like ( N''PK__'' + [schemas].[name] + N''_'' + [tables].[name] + N''_'' + [columns].[name] )"</div></p><details class="summary">
				<summary>Violations</summary><ol>';

              select @output = coalesce(@output + ' ', '')
                               + N'<li class="violation" >['
                               + [schemas].[name] + N'].['+ + [tables].[name]
                               + N'].[' + [columns].[name] + N'].['
                               + [indexes].[name] + N']</li>'
              from   [sys].[tables] as [tables]
                     join [sys].[schemas] as [schemas]
                       on [schemas].[schema_id] = [tables].[schema_id]
                     left join [sys].[indexes] as [indexes]
                            on [indexes].[object_id] = [tables].[object_id]
                     left join [sys].[index_columns] as [index_columns]
                            on [indexes].[index_id] = [index_columns].[index_id]
                               and [indexes].[object_id] = [index_columns].[object_id]
                     left join [sys].[columns] as [columns]
                            on [columns].[column_id] = [index_columns].[column_id]
                               and [columns].[object_id] = [index_columns].[object_id]
              where  [indexes].[is_primary_key] = 1
                     and [indexes].[name] not like lower([schemas].[name] + N'.' + [tables].[name] + N'.'
                                                         + [columns].[name]
                                                         + N'.primary_key_clustered');

              set @output = @output + N'</ol></details>';
          end

          --
          ---------------------------------------------------------------------------------------------------
          begin
              set @category = N'IDENTITY_COLUMN';
              set @output = @output + N'<h4>' + @category + '</h4>'
                            + N'<p><u>standard definition</u>: <div class="definition">"...where [columns].[name] not like ( [tables].[name] + N''ID'' )"</div></p><details class="summary">
				<summary>Violations</summary><ol>';

              select @output = coalesce(@output + ' ', '')
                               + N'<li class="violation" >['
                               + [schemas].[name] + N'].['+ + [tables].[name]
                               + N'].[' + [columns].[name] + N']</li>'
              from   [sys].[tables] as [tables]
                     left join [sys].[schemas] as [schemas]
                            on [schemas].[schema_id] = [tables].[schema_id]
                     left join [sys].[columns] as [columns]
                            on [tables].[object_id] = [columns].[object_id]
                               and [columns].[is_identity] = 1
              where  [columns].[name] != lower(N'id');

              set @output = @output + N'</ol></details>';
          end

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'PRIMARY_KEY - no_primary_key_violation';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">No primary key on table. All tables must have a primary key.</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + N'<li class="violation" >['
                           + [schemas].[name] + N'].['+ + [tables].[name]
                           + N'].[' + N']</li>'
          from   [sys].[tables] as [tables]
                 join [sys].[schemas] as [schemas]
                   on [schemas].[schema_id] = [tables].[schema_id]
                 left join [sys].[indexes] as [indexes]
                        on [indexes].[object_id] = [tables].[object_id]
                 left join [sys].[index_columns] as [index_columns]
                        on [indexes].[index_id] = [index_columns].[index_id]
                           and [indexes].[object_id] = [index_columns].[object_id]
                 left join [sys].[columns] as [columns]
                        on [columns].[column_id] = [index_columns].[column_id]
                           and [columns].[object_id] = [index_columns].[object_id]
          where  [indexes].[type_desc] = N'HEAP';

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'IDENTITY_COLUMN - no_identity_column_violation';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">No identity column on table. Tables typically have an identity column. Evaluate manually whether this table is an exception to this common rule. 
						<ol>
							<li>This will not pick up the use of newsequentialid as a default in place of identity.</li>
							<li>There are cases where a surrogate primary key such as identity() is not preferred. You need to evaluate those individually.
						</ol>
					</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + N'<li class="violation" >['
                           + [schemas].[name] + N'].['+ + [tables].[name]
                           + N'].[' + N']</li>'
          from   [sys].[tables] as [tables]
                 left join [sys].[schemas] as [schemas]
                        on [schemas].[schema_id] = [tables].[schema_id]
                 left join [sys].[columns] as [columns]
                        on [tables].[object_id] = [columns].[object_id]
                           and [columns].[is_identity] = 1
          group  by [schemas].[name]
                    , [tables].[name]
                    , [columns].[is_identity]
          having [columns].[is_identity] is null;

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'UNIQUE_CONSTRAINT - no_unique_constraint_violation';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">No unique constraint on table. OLTP tables typically require a unique constraint that is separate from the primary key. This is because the primary key is typically a surrogate key to minimize page fragmentation and does not define uniqueness of the data.
						<ol>
							<li>Tables containing only [xml] data cannot be constrained in this manner and must be constrained programmatically. See [repository_secure].[data] and [repository_secure].[set] for examples.</li>
						</ol>
						</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + isnull(N'<li class="violation" >[' + [schemas].[name] + N'].['+ + [tables].[name] + N']</li>', N'')
          from   [sys].[tables] as [tables]
                 join [sys].[schemas] as [schemas]
                   on [schemas].[schema_id] = [tables].[schema_id]
                 left join [sys].[indexes] as [indexes]
                        on [indexes].[object_id] = [tables].[object_id]
                           and [indexes].[is_unique_constraint] = 1
                 left join [sys].[index_columns] as [index_columns]
                        on [indexes].[index_id] = [index_columns].[index_id]
                           and [indexes].[object_id] = [index_columns].[object_id]
                 left join [sys].[columns] as [columns]
                        on [columns].[column_id] = [index_columns].[column_id]
                           and [columns].[object_id] = [index_columns].[object_id]
          where  [indexes].[name] is null;

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'PRIMARY_KEY - composite_primary_key_violation';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">Use of a composite primary key. Composite primary keys are often composite natural keys and lead to page fragmentation on inserts. OLTP tables should typically have a single surrogate primary key, with a unique constraint being used to define data uniqueness.</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + isnull(N'<li class="violation" >[' + [schemas].[name] + N'].['+ + [tables].[name] + N'].[' + [indexes].[name] + N']</li>', N'')
          from   [sys].[tables] as [tables]
                 join [sys].[schemas] as [schemas]
                   on [schemas].[schema_id] = [tables].[schema_id]
                 left join [sys].[indexes] as [indexes]
                        on [indexes].[object_id] = [tables].[object_id]
                 left join [sys].[index_columns] as [index_columns]
                        on [indexes].[index_id] = [index_columns].[index_id]
                           and [indexes].[object_id] = [index_columns].[object_id]
                 left join [sys].[columns] as [columns]
                        on [columns].[column_id] = [index_columns].[column_id]
                           and [columns].[object_id] = [index_columns].[object_id]
          where  [indexes].[is_primary_key] = 1
          group  by [schemas].[name]
                    , [tables].[name]
                    , [indexes].[name]
          having count(*) > 1;

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'Unused tables';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">Tables with a zero row count. Unused tables should be considered for deprecation.</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + isnull(N'<li class="violation" >[' + [schemas].[name] + N'].['+ + [tables].[name] + + N']</li>', N'')
          from   [sys].[tables] as [tables]
                 inner join [sys].[schemas] as [schemas]
                         on [schemas].[schema_id] = [tables].[schema_id]
                 inner join [sys].[indexes] as [indexes]
                         on [tables].[object_id] = [indexes].[object_id]
                 inner join [sys].[partitions] as [partitions]
                         on [indexes].[object_id] = [partitions].[object_id]
                            and [indexes].[index_id] = [partitions].[index_id]
                 inner join [sys].[allocation_units] as [allocation_units]
                         on [partitions].[partition_id] = [allocation_units].container_id
          where  [tables].[name] not like 'dt%'
                 and [tables].is_ms_shipped = 0
                 and [indexes].[object_id] > 255
                 and [partitions].[rows] = 0
          group  by [schemas].[name]
                    , [tables].[name]
                    , [partitions].[rows]
          order  by sum([allocation_units].total_pages) * 8;

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'Low row count tables';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">Tables with a row count of less than 5. Consider using a column constraint if the table is a meta data table. The additional complexity of joins to meta data tables may not be justified in this case.</div></p><details class="summary">
				<summary>Violations</summary><ol>';

          select @output = coalesce(@output + ' ', '')
                           + isnull(N'<li class="violation" >[' + [schemas].[name] + N'].['+ + [tables].[name] + + N']</li>', N'')
          from   [sys].[tables] as [tables]
                 inner join [sys].[schemas] as [schemas]
                         on [schemas].[schema_id] = [tables].[schema_id]
                 inner join [sys].[indexes] as [indexes]
                         on [tables].[object_id] = [indexes].[object_id]
                 inner join [sys].[partitions] as [partitions]
                         on [indexes].[object_id] = [partitions].[object_id]
                            and [indexes].[index_id] = [partitions].[index_id]
                 inner join [sys].[allocation_units] as [allocation_units]
                         on [partitions].[partition_id] = [allocation_units].container_id
          where  [tables].[name] not like 'dt%'
                 and [tables].is_ms_shipped = 0
                 and [indexes].[object_id] > 255
                 and [partitions].[rows] < 5
          group  by [schemas].[name]
                    , [tables].[name]
                    , [partitions].[rows]
          order  by sum([allocation_units].total_pages) * 8;

          set @output = @output + N'</ol></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'Unused queries';
          set @timestamp = current_timestamp;
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">Queries that have not been used for over 1 month. sys.dm_exec_procedure_stats  - I like to identify the average amount of resources used for a single execution of a stored procedure.   Calculating the average resources usage per execution allows you to more easily compare one stored procedure to another. To calculate these average resource usage numbers, I divide the total used number by the �execution_count� column.   Here is some code  where I used this technique to calculate average resources usage numbers for stored procedures that have metrics on my system.</div></p><details class="summary">
				<summary>Violations</summary><table border="1"><tr><td>database_id</td><td>cached_time</td><td>last_execution_time</td><td>execution_count</td><td>total_worker_time / execution_count</td><td>total_elapsed_time / execution_count</td><td>total_logical_reads / execution_count</td><td>total_logical_writes / execution_count</td><td>total_physical_reads / execution_count</td></tr>';

          with [builder]
               as (select top(10) [objects].[object_id]
                   from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                          join [sys].[databases] as [databases]
                            on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                          join [sys].[objects] as [objects]
                            on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
                   where  [databases].[name] = db_name()
                          and datediff(day
                                       , [last_execution_time]
                                       , @timestamp) > 90
                   order  by [last_execution_time] asc)
          select @output = coalesce(@output + ' ', '') + N'<tr><td>'
                           + [objects].[name] + N'</td><td>'
                           + convert([sysname], [cached_time])
                           + N'</td><td>'
                           + convert([sysname], [last_execution_time])
                           + N'</td><td>'
                           + convert([sysname], [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_worker_time] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_elapsed_time] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_logical_reads] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_logical_writes] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_physical_reads] / [execution_count])
                           + N'</td></tr>'
          from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                 join [builder] as [builder]
                   on [builder].[object_id] = [dm_exec_procedure_stats].[object_id]
                 join [sys].[databases] as [databases]
                   on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                 join [sys].[objects] as [objects]
                   on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
          where  [databases].[name] = db_name()
          order  by [last_execution_time] asc;

          set @output = @output + N'</table></details>';
      end

      --
      ---------------------------------------------------------------------------------------------------
      begin
          set @category = N'Top 10 worst performing queries';
          set @output = @output + N'<h4>' + @category + '</h4>'
                        + N'<p><u>standard definition</u>: <div class="definition">Top 10 worst performing queries. sys.dm_exec_procedure_stats  - I like to identify the average amount of resources used for a single execution of a stored procedure.   Calculating the average resources usage per execution allows you to more easily compare one stored procedure to another. To calculate these average resource usage numbers, I divide the total used number by the �execution_count� column.   Here is some code  where I used this technique to calculate average resources usage numbers for stored procedures that have metrics on my system.</div></p><details class="summary">
				<summary>Violations</summary><table border="1"><tr><td>database_id</td><td>cached_time</td><td>last_execution_time</td><td>execution_count</td><td>total_worker_time / execution_count</td><td>total_elapsed_time / execution_count</td><td>total_logical_reads / execution_count</td><td>total_logical_writes / execution_count</td><td>total_physical_reads / execution_count</td></tr>';

          with [builder]
               as (select top(10) [objects].[object_id]
                   from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                          join [sys].[databases] as [databases]
                            on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                          join [sys].[objects] as [objects]
                            on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
                   where  [databases].[name] = db_name()
                          and [objects].[object_id] != @@procid
                   order  by total_logical_reads / execution_count desc)
          select @output = coalesce(@output + ' ', '') + N'<tr><td>'
                           + [objects].[name] + N'</td><td>'
                           + convert([sysname], [cached_time])
                           + N'</td><td>'
                           + convert([sysname], [last_execution_time])
                           + N'</td><td>'
                           + convert([sysname], [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_worker_time] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_elapsed_time] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_logical_reads] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_logical_writes] / [execution_count])
                           + N'</td><td>'
                           + convert([sysname], [total_physical_reads] / [execution_count])
                           + N'</td></tr>'
          from   [sys].[dm_exec_procedure_stats] as [dm_exec_procedure_stats]
                 join [builder] as [builder]
                   on [builder].[object_id] = [dm_exec_procedure_stats].[object_id]
                 join [sys].[databases] as [databases]
                   on [databases].[database_id] = [dm_exec_procedure_stats].[database_id]
                 join [sys].[objects] as [objects]
                   on [objects].[object_id] = [dm_exec_procedure_stats].[object_id]
          where  [databases].[name] = db_name()
          order  by total_logical_reads / execution_count desc;

          set @output = @output + N'</table></details>';
      end

      --
      -- footer
      ---------------------------------------------------------------------------------------------
      set @output = @output + N'<p class="footer">['
                    + object_schema_name(@@procid) + N'].['
                    + object_name(@@procid) + '] '
                    + convert([sysname], current_timestamp, 121)
                    + '</p>
		</body></html>';

      select @output;
  end

go

if exists (select *
           from   ::fn_listextendedproperty(N'license'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'procedure'
                                            , N'get'
                                            , default
                                            , default))
  exec sys.sp_dropextendedproperty
    @name        =N'license'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'procedure'
    , @level1name=N'get'
    , @level2type=null
    , @level2name=null;

go

exec sys.sp_addextendedproperty
  @name        =N'license'
  , @value     =N'select [documentation].[get_license]();'
  , @level0type=N'SCHEMA'
  , @level0name=N'best_practices'
  , @level1type=N'procedure'
  , @level1name=N'get'
  , @level2type=null
  , @level2name=null;

go

if exists (select *
           from   ::fn_listextendedproperty(N'revision_20140207'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'revision_20140207'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'revision_20140207'
  , @value     =N'Katherine E. Lightsey - Created.'
  , @level0type=N'SCHEMA'
  , @level0name=N'best_practices'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'package_chamomile_basic'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'package_chamomile_basic'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'package_chamomile_basic'
  , @value     =N''
  , @level0type=N'SCHEMA'
  , @level0name=N'best_practices'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'execute_as'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'execute_as'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'description'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'description'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

if exists (select *
           from   ::fn_listextendedproperty(N'todo'
                                            , N'SCHEMA'
                                            , N'best_practices'
                                            , N'PROCEDURE'
                                            , N'get'
                                            , null
                                            , null))
  exec sys.sp_dropextendedproperty
    @name        =N'todo'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go

exec sys.sp_addextendedproperty
  @name        =N'todo'
  , @value     =N'<ol>
		<li>Check databases to ensure that no files are being stored on the c: drive.</li>
	</ol>'
  , @level0type=N'SCHEMA'
  , @level0name=N'best_practices'
  , @level1type=N'PROCEDURE'
  , @level1name=N'get'

go

if not exists (select *
               from   ::fn_listextendedproperty(N'description'
                                                , N'SCHEMA'
                                                , N'best_practices'
                                                , N'PROCEDURE'
                                                , N'get'
                                                , null
                                                , null))
  exec sys.sp_addextendedproperty
    @name        =N'description'
    , @value     =N'[best_practices].[get] analyzes the current database for violation of best practices. Best practice evalutions include:
		discrepancy
				1. naming_violation - The object does conform to standard naming convention.
				2. no_primary_key_violation - The table does not include a primary key.
				3. composite_primary_key_violation - The table uses a composite primary key. This typically indicateds that the key is a composite natural key. Recommended practice is to use a surrogate individual primary key on OLTP tables, only using a natural or composite natural primary key on OLAP tables.
				4. no_identity_column_violation - The table does not include an identity column. All OLTP tables should include an identity column of either type [int] or [bigint].
				5. no_unique_constraint_violation - The table does not include a unique index. All tables must include a unique index which defines the uniqueness of the table.

		object type
				1. DEFAULT_CONSTRAINT
				2. FOREIGN_KEY_CONSTRAINT - 
				3. PRIMARY_KEY_CONSTRAINT
				4. IDENTITY_COLUMN
				5. SQL_SCALAR_FUNCTION -
				6. SQL_STORED_PROCEDURE -
				7. SQL_TRIGGER -
				8. UNIQUE_CONSTRAINT -
				9. USER_TABLE - 
				'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get';

go

if not exists (select *
               from   ::fn_listextendedproperty(N'execute_as'
                                                , N'SCHEMA'
                                                , N'best_practices'
                                                , N'PROCEDURE'
                                                , N'get'
                                                , null
                                                , null))
  exec sys.sp_addextendedproperty
    @name        =N'execute_as'
    , @value     =N'execute [chamomile].[best_practices].[get];'
    , @level0type=N'SCHEMA'
    , @level0name=N'best_practices'
    , @level1type=N'PROCEDURE'
    , @level1name=N'get'

go 
